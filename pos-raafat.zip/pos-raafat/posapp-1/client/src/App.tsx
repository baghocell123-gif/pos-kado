import React, { useState, useEffect, useRef } from 'react'

// Type definitions
interface Product {
  id: string;
  name: string;
  price: number;
  quantity: number;
  barcode?: string;
  total: number;
}

interface Order {
  id: string;
  date: string;
  time: string;
  createdAt: string;
  total: number;
  items: Product[];
  status: 'pending' | 'completed' | 'cancelled';
  customerName: string;
  employeeName?: string;
  paymentMethod?: 'cash' | 'card';
  amountPaid?: number;
  change?: number;
}

// دوال التخزين المحلي
const loadFromLocalStorage = (key: string, defaultValue: any) => {
  try {
    const stored = localStorage.getItem(key)
    return stored ? JSON.parse(stored) : defaultValue
  } catch {
    return defaultValue
  }
}

const saveToLocalStorage = (key: string, value: any) => {
  try {
    localStorage.setItem(key, JSON.stringify(value))
  } catch (error) {
    console.error('Error saving to localStorage:', error)
  }
}

const removeFromLocalStorage = (key: string) => {
  try {
    localStorage.removeItem(key)
  } catch (error) {
    console.error('Error removing from localStorage:', error)
  }
}

function App() {
  // إعدادات العمليات - التبويبات الفرعية والإرجاعات
  const [operationsTab, setOperationsTab] = useState<'archives' | 'returns' | 'advanced-orders' | 'backup' | 'reports' | 'sync'>('archives')
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null)
  const [showReturnModal, setShowReturnModal] = useState(false)
  const [returnItems, setReturnItems] = useState<{[key: string]: number}>({})
  const [returnReason, setReturnReason] = useState('')
  
  // البحث عن الفواتير
  const [searchInvoiceNumber, setSearchInvoiceNumber] = useState('')
  const [searchResult, setSearchResult] = useState<Order | null>(null)
  const [searchError, setSearchError] = useState('')
  
  // سجل المرتجعات
  const [returns, setReturns] = useState(() => 
    loadFromLocalStorage('supermarket_returns', [])
  )
  
  // نظام الإدارة
  const [isAdmin, setIsAdmin] = useState(() => 
    loadFromLocalStorage('supermarket_admin_logged', false)
  )
  const [showAdminLogin, setShowAdminLogin] = useState(false)
  const [adminPassword, setAdminPassword] = useState('')
  const [showAdminPanel, setShowAdminPanel] = useState(false)
  const [newProductName, setNewProductName] = useState('')
  const [newProductPrice, setNewProductPrice] = useState('')
  const [newProductBarcode, setNewProductBarcode] = useState('')
  const [newProductQuantity, setNewProductQuantity] = useState('')
  const [editingProduct, setEditingProduct] = useState<any>(null)

  // إدارة المنتجات المحسنة للعدد الكبير
  const [productSearch, setProductSearch] = useState('')
  const [currentPage, setCurrentPage] = useState(1)
  const [itemsPerPage, setItemsPerPage] = useState(20)
  const [sortBy, setSortBy] = useState<'name' | 'price' | 'quantity' | 'barcode'>('name')
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc')
  const [showLowStock, setShowLowStock] = useState(false)
  const [priceFilter, setPriceFilter] = useState({ min: '', max: '' })
  const [quantityFilter, setQuantityFilter] = useState({ min: '', max: '' })
  const [productCategory, setProductCategory] = useState('all')
  const [showAdvancedProductManager, setShowAdvancedProductManager] = useState(false)

  // نظام المزامنة بين الأجهزة
  const [syncSettings, setSyncSettings] = useState(() => 
    loadFromLocalStorage('supermarket_sync_settings', {
      enabled: false,
      serverUrl: '',
      deviceName: 'الجهاز الرئيسي',
      syncToken: '', // مفتاح المزامنة الآمن
      autoSync: true,
      syncInterval: 30000, // 30 seconds
      lastSync: null
    })
  )
  const [syncStatus, setSyncStatus] = useState<'idle' | 'syncing' | 'error' | 'success'>('idle')
  const [syncMessage, setSyncMessage] = useState('')
  const [showSyncSettings, setShowSyncSettings] = useState(false)
  const [connectedDevices, setConnectedDevices] = useState<string[]>([])
  const [syncConflicts, setSyncConflicts] = useState<any[]>([])
  const [isUploading, setIsUploading] = useState(false)
  const [isDownloading, setIsDownloading] = useState(false)

  // إعدادات السوبر ماركت ونظام التفعيل
  const [storeSettings, setStoreSettings] = useState(() => {
    const settings = loadFromLocalStorage('supermarket_settings', {
      storeName: 'سوبر ماركت لبناني',
      licenseKey: '',
      licenseExpiry: '',
      isActivated: false,
      adminUsername: 'admin',
      currency: 'LBP' // الافتراضي الليرة اللبنانية
    });
    
    // تنظيف أي بيانات adminPassword قديمة من localStorage
    if ('adminPassword' in settings) {
      const { adminPassword, ...cleanSettings } = settings;
      localStorage.setItem('supermarket_settings', JSON.stringify(cleanSettings));
      return cleanSettings;
    }
    
    return settings;
  })

  // إعدادات التبويب النشط
  const [activeTab, setActiveTab] = useState<'cashier' | 'orders' | 'reports' | 'operations-settings' | 'admin' | 'products' | 'employee-settings' | 'license-manager'>('cashier')

  // قاعدة بيانات المنتجات مع التخزين المحلي
  const [products, setProducts] = useState(() => {
    const loadedProducts = loadFromLocalStorage('supermarket_products', [
      { barcode: '123456789', name: 'خبز أبيض', price: 15000, quantity: 50 },
      { barcode: '987654321', name: 'حليب كامل الدسم', price: 45000, quantity: 30 },
      { barcode: '456789123', name: 'أرز بسمتي', price: 120000, quantity: 20 },
      { barcode: '789123456', name: 'زيت زيتون', price: 80000, quantity: 15 },
      { barcode: '321654987', name: 'سكر أبيض', price: 25000, quantity: 40 },
      { barcode: '111222333', name: 'شاي أحمر', price: 35000, quantity: 25 },
      { barcode: '444555666', name: 'معكرونة', price: 18000, quantity: 35 },
      { barcode: '777888999', name: 'صابون', price: 12000, quantity: 60 },
    ])
    
    // توحيد البيانات: إضافة quantity للمنتجات القديمة
    const normalizedProducts = loadedProducts.map((product: any) => ({
      ...product,
      quantity: product.quantity !== undefined ? product.quantity : 0
    }))
    
    return normalizedProducts
  })

  // قاعدة بيانات الطلبات مع التخزين المحلي
  const [orders, setOrders] = useState(() => 
    loadFromLocalStorage('supermarket_orders', [])
  )

  // قاعدة بيانات حركات المخزون مع التخزين المحلي
  const [stockMovements, setStockMovements] = useState(() => 
    loadFromLocalStorage('supermarket_stock_movements', [])
  )

  // متغيرات الكاشيير وسلة الشراء
  const [cart, setCart] = useState<Product[]>([])
  const [barcode, setBarcode] = useState('')
  const [productName, setProductName] = useState('')
  const [productPrice, setProductPrice] = useState('')
  const [quantity, setQuantity] = useState('1')
  const [customerName, setCustomerName] = useState('')
  const [currentOrderId, setCurrentOrderId] = useState('')

  // متغيرات الدفع
  const [showPaymentModal, setShowPaymentModal] = useState(false)
  const [paymentType, setPaymentType] = useState<'cash' | 'card' | null>(null)
  const [amountPaid, setAmountPaid] = useState('')

  // متغيرات حركات المخزون
  const [newMovementProduct, setNewMovementProduct] = useState('')
  const [newMovementType, setNewMovementType] = useState<'incoming' | 'outgoing'>('incoming')
  const [newMovementQuantity, setNewMovementQuantity] = useState('')
  const [newMovementReason, setNewMovementReason] = useState('')
  const [newMovementNotes, setNewMovementNotes] = useState('')

  // متغيرات تسجيل دخول المدير العادي
  const [adminLoginUsername, setAdminLoginUsername] = useState('')
  
  // متغيرات تسجيل دخول الموظفين
  const [isEmployeeLoggedIn, setIsEmployeeLoggedIn] = useState(() => 
    loadFromLocalStorage('supermarket_employee_logged', false)
  )
  const [currentEmployee, setCurrentEmployee] = useState(() => 
    loadFromLocalStorage('supermarket_current_employee', null)
  )
  const [employeeUsername, setEmployeeUsername] = useState('')
  const [employeePassword, setEmployeePassword] = useState('')
  const [showEmployeeLogin, setShowEmployeeLogin] = useState(false)
  const [employeeLoginLoading, setEmployeeLoginLoading] = useState(false)
  
  // متغيرات تسجيل دخول مدير التراخيص (منفصل)
  const [isLicenseManager, setIsLicenseManager] = useState(() => 
    loadFromLocalStorage('supermarket_license_manager_logged', false)
  )
  const [licenseManagerUsername, setLicenseManagerUsername] = useState('')
  const [licenseManagerPassword, setLicenseManagerPassword] = useState('')
  const [showLicenseManagerLogin, setShowLicenseManagerLogin] = useState(false)
  
  // متغيرات إضافية مطلوبة لنظام إدارة التراخيص  
  const [newStoreName, setNewStoreName] = useState('')
  const [newLicenseKey, setNewLicenseKey] = useState('')
  const [newAdminUsername, setNewAdminUsername] = useState('')
  const [newAdminPassword, setNewAdminPassword] = useState('')
  const [showCustomerForm, setShowCustomerForm] = useState(false)
  const [showLicenseForm, setShowLicenseForm] = useState(false)

  // متغيرات إدارة الموظفين في لوحة المدير
  const [employees, setEmployees] = useState([])
  const [loadingEmployees, setLoadingEmployees] = useState(false)
  const [newEmployeeName, setNewEmployeeName] = useState('')
  const [newEmployeeUsername, setNewEmployeeUsername] = useState('')
  const [newEmployeePassword, setNewEmployeePassword] = useState('')
  const [newEmployeeNotes, setNewEmployeeNotes] = useState('')
  const [addingEmployee, setAddingEmployee] = useState(false)

  // مراجع HTML Elements
  const barcodeInputRef = useRef<HTMLInputElement>(null)

  // متغيرات إدارة الرخصة
  const [licenseManagementData, setLicenseManagementData] = useState({
    customers: [],
    licenseTypes: [],
    licenses: []
  })

  // إعدادات العملات
  const currencies = {
    LBP: { name: 'الليرة اللبنانية', symbol: 'ل.ل', locale: 'ar-LB' },
    SYP: { name: 'الليرة السورية', symbol: 'ل.س', locale: 'ar-SY' },
    USD: { name: 'الدولار الأمريكي', symbol: '$', locale: 'en-US' }
  }
  
  // دالة تنسيق الأسعار حسب العملة
  const formatPrice = (amount: number) => {
    const currency = currencies[storeSettings.currency as keyof typeof currencies] || currencies.LBP
    // تحديد عدد المنازل العشرية حسب العملة
    const fractionDigits = storeSettings.currency === 'USD' ? 2 : 0;
    const formattedAmount = amount.toLocaleString(currency.locale, { 
      minimumFractionDigits: fractionDigits,
      maximumFractionDigits: fractionDigits 
    })
    return `${formattedAmount} ${currency.symbol}`
  }

  // حفظ البيانات الموحدة فوراً عند التحميل الأول
  useEffect(() => {
    const hadMissingQuantity = products.some((product: any) => 
      loadFromLocalStorage('supermarket_products', []).find((p: any) => p.barcode === product.barcode && p.quantity === undefined)
    )
    if (hadMissingQuantity) {
      saveToLocalStorage('supermarket_products', products)
    }
  }, []) // تشغيل مرة واحدة فقط عند التحميل

  useEffect(() => {
    saveToLocalStorage('supermarket_orders', orders)
  }, [orders])

  useEffect(() => {
    saveToLocalStorage('supermarket_products', products)
  }, [products])

  useEffect(() => {
    saveToLocalStorage('supermarket_settings', storeSettings)
  }, [storeSettings])

  useEffect(() => {
    saveToLocalStorage('supermarket_admin_logged', isAdmin)
  }, [isAdmin])

  useEffect(() => {
    saveToLocalStorage('supermarket_stock_movements', stockMovements)
  }, [stockMovements])

  useEffect(() => {
    saveToLocalStorage('supermarket_returns', returns)
  }, [returns])

  useEffect(() => {
    saveToLocalStorage('supermarket_sync_settings', syncSettings)
  }, [syncSettings])

  // حفظ حالة تسجيل دخول الموظف
  useEffect(() => {
    saveToLocalStorage('supermarket_employee_logged', isEmployeeLoggedIn)
  }, [isEmployeeLoggedIn])

  useEffect(() => {
    saveToLocalStorage('supermarket_current_employee', currentEmployee)
  }, [currentEmployee])

  // جعل حقل الباركود نشط تلقائياً
  useEffect(() => {
    if (activeTab === 'cashier' && barcodeInputRef.current) {
      barcodeInputRef.current.focus()
    }
  }, [activeTab])

  // إضافة اختصارات F3 و F4
  useEffect(() => {
    const handleKeyPress = (event: KeyboardEvent) => {
      // F3 للدفع النقدي (فقط في صفحة الكاشيير وإذا لم تكن نافذة الدفع مفتوحة)
      if (event.key === 'F3' && activeTab === 'cashier' && !showPaymentModal) {
        event.preventDefault() // منع السلوك الافتراضي للمتصفح
        
        if (cart.length === 0) {
          alert('لا توجد منتجات في السلة')
          return
        }
        
        // تنفيذ نفس منطق زر الدفع النقدي
        setPaymentType('cash')
        setShowPaymentModal(true)
        setAmountPaid('')
      }
      
      // F4 لفتح الصندوق مباشرة (فقط في صفحة الكاشيير)
      if (event.key === 'F4' && activeTab === 'cashier') {
        event.preventDefault() // منع السلوك الافتراضي للمتصفح
        
        // فتح الصندوق مباشرة
        openCashDrawer()
        alert('🔓 تم فتح الصندوق')
      }
      
      // F2 للتركيز على خانة إدخال المنتجات (فقط في صفحة الكاشيير)
      if (event.key === 'F2' && activeTab === 'cashier' && !showPaymentModal) {
        event.preventDefault() // منع السلوك الافتراضي للمتصفح
        
        // التركيز على حقل إدخال الباركود
        if (barcodeInputRef.current) {
          barcodeInputRef.current.focus()
          barcodeInputRef.current.select() // تحديد النص الموجود إن وجد
        }
      }
      
      // Alt+P لإدخال منتجات جديدة (الانتقال إلى صفحة المنتجات)  
      if (event.altKey && event.key.toLowerCase() === 'p' && activeTab === 'cashier' && !showPaymentModal) {
        event.preventDefault() // منع السلوك الافتراضي للمتصفح
        
        // الانتقال إلى صفحة المنتجات
        setActiveTab('products')
      }
    }

    // إضافة المستمع فقط عندما نكون في صفحة الكاشيير
    if (activeTab === 'cashier') {
      document.addEventListener('keydown', handleKeyPress)
    }

    // تنظيف المستمع عند الخروج من الصفحة
    return () => {
      document.removeEventListener('keydown', handleKeyPress)
    }
  }, [activeTab, cart.length, showPaymentModal])

  // إضافة اختصار Enter لتأكيد الدفع في نافذة الدفع
  useEffect(() => {
    const handlePaymentKeyPress = (event: KeyboardEvent) => {
      // Enter لتأكيد الدفع (فقط عندما تكون نافذة الدفع مفتوحة)
      if (event.key === 'Enter' && showPaymentModal) {
        event.preventDefault() // منع السلوك الافتراضي للمتصفح
        
        // التحقق من إمكانية تأكيد الدفع (نفس شروط الزر)
        if (!paymentType || 
            (paymentType === 'cash' && (!amountPaid || parseFloat(amountPaid) < getTotalPrice()))) {
          return // لا تفعل شيئاً إذا لم تكن الشروط متوفرة
        }
        
        // تنفيذ عملية الدفع
        processPayment()
      }
    }

    // إضافة المستمع فقط عندما تكون نافذة الدفع مفتوحة
    if (showPaymentModal) {
      document.addEventListener('keydown', handlePaymentKeyPress)
    }

    // تنظيف المستمع عند إغلاق النافذة
    return () => {
      document.removeEventListener('keydown', handlePaymentKeyPress)
    }
  }, [showPaymentModal, paymentType, amountPaid, cart.length])

  const addToCart = () => {
    // التحقق من تسجيل دخول الموظف أولاً
    if (!isEmployeeLoggedIn) {
      alert('🔒 يجب تسجيل دخول موظف أولاً لاستخدام الكاشيير')
      return
    }
    
    // التحقق من صلاحية التفعيل قبل السماح بالعمليات
    if (!checkLicenseValidity()) {
      alert('⚠️ النظام غير مفعل أو منتهي الصلاحية!\nيرجى تفعيل النظام من لوحة الإدارة للمتابعة.')
      return
    }

    if (!barcode.trim()) {
      alert('الرجاء إدخال الباركود أو اسم المنتج')
      return
    }

    const qty = parseInt(quantity) || 1
    const searchTerm = barcode.trim()
    
    // البحث بالباركود أولاً
    let product = products.find((p: any) => p.barcode === searchTerm)
    
    // إذا لم نجد بالباركود، نبحث بالاسم
    if (!product) {
      product = products.find((p: any) => 
        p.name.toLowerCase().includes(searchTerm.toLowerCase())
      )
    }
    
    if (product) {
      addProductToCart(product.name, product.price, qty, product.barcode)
      // تنظيف حقل الإدخال بعد الإضافة الناجحة
      setBarcode('')
      // إعادة التركيز على حقل الإدخال
      setTimeout(() => {
        if (barcodeInputRef.current) {
          barcodeInputRef.current.focus()
        }
      }, 100)
    } else {
      alert('المنتج غير موجود في قاعدة البيانات')
    }
  }

  const addProductToCart = (name: string, price: number, qty: number, barcode?: string) => {
    // التحقق من تسجيل دخول الموظف أولاً
    if (!isEmployeeLoggedIn) {
      alert('🔒 يجب تسجيل دخول موظف أولاً لاستخدام الكاشيير')
      return
    }
    
    const existingProduct = cart.find(item => item.name === name)
    if (existingProduct) {
      setCart(cart.map(item => 
        item.name === name 
          ? { ...item, quantity: item.quantity + qty, total: (item.quantity + qty) * item.price }
          : item
      ))
    } else {
      const newProduct: Product = {
        id: Date.now().toString(),
        name,
        price,
        quantity: qty,
        barcode,
        total: price * qty
      }
      setCart([...cart, newProduct])
    }
    setBarcode('')
    setProductName('')
    setProductPrice('')
    setQuantity('1')
  }

  const removeFromCart = (id: string) => {
    setCart(cart.filter(item => item.id !== id))
  }

  const updateQuantity = (id: string, newQuantity: number) => {
    if (newQuantity <= 0) {
      removeFromCart(id)
    } else {
      setCart(cart.map(item => 
        item.id === id 
          ? { ...item, quantity: newQuantity, total: newQuantity * item.price }
          : item
      ))
    }
  }

  const updatePrice = (id: string, newPrice: number) => {
    if (newPrice > 0) {
      setCart(cart.map(item => 
        item.id === id 
          ? { ...item, price: newPrice, total: item.quantity * newPrice }
          : item
      ))
    }
  }

  const getTotalPrice = () => {
    return cart.reduce((total, item) => total + item.total, 0)
  }

  const clearCart = () => {
    setCart([])
    setCustomerName('')
    setCurrentOrderId('')
  }

  // دوال الإدارة
  const loginAdmin = async () => {
    console.log('🔐 محاولة تسجيل دخول المدير...', { username: adminLoginUsername, hasPassword: !!adminPassword })
    
    if (!adminLoginUsername || !adminPassword) {
      alert('يرجى إدخال اسم المستخدم وكلمة المرور')
      return
    }
    
    try {
      console.log('📤 إرسال طلب تسجيل الدخول...')
      // Use port 3000 in Replit environment for backend
      const backendUrl = window.location.hostname.includes('replit.dev') 
        ? `/api/admin/login` // In Replit, backend runs on same domain but port 3000
        : '/api/admin/login';
      
      console.log('🌐 URL Details:', {
        hostname: window.location.hostname,
        backendUrl,
        isReplit: window.location.hostname.includes('replit.dev')
      });
      
      const response = await fetch(backendUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          username: adminLoginUsername,
          password: adminPassword
        })
      })

      console.log('📥 استجابة الخادم:', response.status, response.statusText)

      if (response.ok) {
        console.log('✅ تم تسجيل الدخول بنجاح!')
        // حفظ بيانات الإدارة بشكل مؤقت لاستخدامها في API calls
        sessionStorage.setItem('adminAuth', btoa(`${adminLoginUsername}:${adminPassword}`))
        setIsAdmin(true)
        setShowAdminLogin(false)
        setAdminPassword('')
        setAdminLoginUsername('')
        alert('تم تسجيل الدخول بنجاح كمدير!')
      } else {
        console.log('❌ فشل تسجيل الدخول:', response.status)
        const errorData = await response.json()
        console.log('تفاصيل الخطأ:', errorData)
        alert('اسم المستخدم أو كلمة المرور غير صحيحة')
      }
    } catch (error) {
      console.error('❌ خطأ في تسجيل الدخول:', error)
      alert('خطأ في تسجيل الدخول')
    }
  }

  const logoutAdmin = () => {
    // مسح بيانات المصادقة
    sessionStorage.removeItem('adminAuth')
    setIsAdmin(false)
    setShowAdminPanel(false)
    alert('تم تسجيل الخروج من المدير العادي بنجاح')
  }

  // دوال تسجيل دخول/خروج الموظفين
  const loginEmployee = async () => {
    console.log('👤 محاولة تسجيل دخول الموظف...', { username: employeeUsername })
    
    if (!employeeUsername || !employeePassword) {
      alert('يرجى إدخال اسم المستخدم وكلمة المرور')
      return
    }

    setEmployeeLoginLoading(true)
    
    try {
      // استخدام نفس نمط المدير للURL
      const backendUrl = window.location.hostname.includes('replit.dev') 
        ? `/api/employees/login` // في Replit، الخادم يعمل على نفس النطاق
        : '/api/employees/login';
      
      const response = await fetch(backendUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          username: employeeUsername,
          password: employeePassword
        })
      })

      const data = await response.json()

      if (response.ok && data.success) {
        console.log('✅ تسجيل دخول الموظف بنجاح!', data.employee)
        
        // حفظ معلومات الموظف
        const employeeInfo = {
          id: data.employee.id,
          name: data.employee.name,
          username: data.employee.username,
          loginTime: new Date().toISOString()
        }
        
        setIsEmployeeLoggedIn(true)
        setCurrentEmployee(employeeInfo)
        setShowEmployeeLogin(false)
        setEmployeePassword('')
        setEmployeeUsername('')
        
        // رسالة ترحيب
        alert(`مرحباً ${data.employee.name}! تم تسجيل الدخول بنجاح`)
      } else {
        console.error('❌ فشل تسجيل دخول الموظف:', data.error)
        alert(`خطأ: ${data.error || 'فشل في تسجيل الدخول'}`)
      }
    } catch (error) {
      console.error('❌ خطأ في تسجيل دخول الموظف:', error)
      alert('خطأ في الاتصال بالخادم')
    } finally {
      setEmployeeLoginLoading(false)
    }
  }

  const logoutEmployee = async () => {
    console.log('🚪 تسجيل خروج الموظف...', currentEmployee?.name)
    
    try {
      // إشعار الخادم بتسجيل الخروج
      const backendUrl = window.location.hostname.includes('replit.dev') 
        ? `/api/employees/logout` // في Replit، الخادم يعمل على نفس النطاق
        : '/api/employees/logout';
      
      await fetch(backendUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          employeeId: currentEmployee?.id
        })
      })
      
      console.log('✅ تم تسجيل خروج الموظف من الخادم')
    } catch (error) {
      console.error('❌ خطأ في تسجيل خروج الموظف من الخادم:', error)
    }
    
    // تنظيف الحالة المحلية
    setIsEmployeeLoggedIn(false)
    setCurrentEmployee(null)
    setEmployeePassword('')
    setEmployeeUsername('')
    
    alert('تم تسجيل الخروج بنجاح')
  }

  // دوال إدارة الموظفين للمدير
  const fetchEmployees = async () => {
    setLoadingEmployees(true)
    try {
      const adminAuth = sessionStorage.getItem('adminAuth')
      if (!adminAuth) {
        alert('يجب تسجيل دخول المدير أولاً')
        return
      }

      const response = await fetch('/api/admin/employees', {
        headers: {
          'Authorization': 'Basic ' + adminAuth
        }
      })

      if (response.ok) {
        const data = await response.json()
        setEmployees(data.employees || [])
      } else {
        const errorData = await response.json()
        console.error('فشل في تحميل الموظفين:', errorData)
        alert('فشل في تحميل قائمة الموظفين')
      }
    } catch (error) {
      console.error('خطأ في تحميل الموظفين:', error)
      alert('خطأ في الاتصال بالخادم')
    } finally {
      setLoadingEmployees(false)
    }
  }

  const addEmployee = async () => {
    if (!newEmployeeName.trim() || !newEmployeeUsername.trim() || !newEmployeePassword.trim()) {
      alert('يرجى ملء الحقول المطلوبة: الاسم، اسم المستخدم، وكلمة المرور')
      return
    }

    if (newEmployeePassword.length < 4) {
      alert('كلمة المرور يجب أن تكون 4 أحرف على الأقل')
      return
    }

    setAddingEmployee(true)
    try {
      const adminAuth = sessionStorage.getItem('adminAuth')
      if (!adminAuth) {
        alert('يجب تسجيل دخول المدير أولاً')
        return
      }

      const response = await fetch('/api/admin/employees', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Basic ' + adminAuth
        },
        body: JSON.stringify({
          name: newEmployeeName.trim(),
          username: newEmployeeUsername.trim(),
          password: newEmployeePassword,
          isActive: true,
          notes: newEmployeeNotes.trim() || null
        })
      })

      const data = await response.json()

      if (response.ok) {
        alert(`تم إضافة الموظف ${data.employee.name} بنجاح!`)
        // تنظيف النموذج
        setNewEmployeeName('')
        setNewEmployeeUsername('')
        setNewEmployeePassword('')
        setNewEmployeeNotes('')
        // إعادة تحميل قائمة الموظفين
        fetchEmployees()
      } else {
        alert(`خطأ في إضافة الموظف: ${data.error}`)
      }
    } catch (error) {
      console.error('خطأ في إضافة موظف:', error)
      alert('خطأ في الاتصال بالخادم')
    } finally {
      setAddingEmployee(false)
    }
  }

  const deleteEmployee = async (employeeId: number, employeeName: string) => {
    const confirmDelete = window.confirm(
      `هل أنت متأكد من حذف الموظف "${employeeName}"؟\n\nهذا الإجراء لا يمكن التراجع عنه.`
    )

    if (!confirmDelete) return

    try {
      const adminAuth = sessionStorage.getItem('adminAuth')
      if (!adminAuth) {
        alert('يجب تسجيل دخول المدير أولاً')
        return
      }

      const response = await fetch(`/api/admin/employees/${employeeId}`, {
        method: 'DELETE',
        headers: {
          'Authorization': 'Basic ' + adminAuth
        }
      })

      const data = await response.json()

      if (response.ok) {
        alert(`تم حذف الموظف ${employeeName} بنجاح!`)
        // إعادة تحميل قائمة الموظفين
        fetchEmployees()
      } else {
        alert(`خطأ في حذف الموظف: ${data.error}`)
      }
    } catch (error) {
      console.error('خطأ في حذف موظف:', error)
      alert('خطأ في الاتصال بالخادم')
    }
  }

  // تحميل الموظفين عند تسجيل دخول المدير
  useEffect(() => {
    if (isAdmin) {
      fetchEmployees()
    }
  }, [isAdmin])

  // دوال تسجيل دخول مدير التراخيص (منفصل)
  const loginLicenseManager = async () => {
    console.log('🔐 محاولة تسجيل دخول مدير التراخيص...', { username: licenseManagerUsername, hasPassword: !!licenseManagerPassword })
    
    if (!licenseManagerUsername || !licenseManagerPassword) {
      alert('يرجى إدخال اسم المستخدم وكلمة المرور لمدير التراخيص')
      return
    }
    
    try {
      console.log('📤 إرسال طلب تسجيل دخول مدير التراخيص...')
      
      // Use port 3000 in Replit environment for backend  
      const backendUrl = window.location.hostname.includes('replit.dev') 
        ? `/api/license-manager/login` // In Replit, backend runs on same domain but port 3000
        : '/api/license-manager/login';
      
      console.log('🌐 License Manager URL Details:', {
        hostname: window.location.hostname,
        backendUrl,
        isReplit: window.location.hostname.includes('replit.dev')
      });
      
      const response = await fetch(backendUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          username: licenseManagerUsername,
          password: licenseManagerPassword
        })
      })

      console.log('📥 استجابة الخادم:', response.status, response.statusText)

      if (response.ok) {
        console.log('✅ تم تسجيل دخول مدير التراخيص بنجاح!')
        // حفظ بيانات مدير التراخيص بشكل منفصل
        sessionStorage.setItem('licenseManagerAuth', btoa(`${licenseManagerUsername}:${licenseManagerPassword}`))
        setIsLicenseManager(true)
        saveToLocalStorage('supermarket_license_manager_logged', true) // حفظ في localStorage للاستمرارية
        setShowLicenseManagerLogin(false)
        setLicenseManagerPassword('')
        setLicenseManagerUsername('')
        alert('تم تسجيل الدخول بنجاح كمدير تراخيص!')
      } else {
        console.log('❌ فشل تسجيل دخول مدير التراخيص:', response.status)
        alert('اسم المستخدم أو كلمة المرور غير صحيحة لمدير التراخيص')
      }
    } catch (error) {
      console.error('❌ خطأ في تسجيل دخول مدير التراخيص:', error)
      alert('خطأ في الاتصال بالخادم. تعذر تسجيل الدخول كمدير تراخيص. يرجى المحاولة لاحقاً.')
    }
  }

  const logoutLicenseManager = () => {
    // مسح بيانات مصادقة مدير التراخيص
    sessionStorage.removeItem('licenseManagerAuth')
    removeFromLocalStorage('supermarket_license_manager_logged') // مسح من localStorage
    setIsLicenseManager(false)
    setShowLicenseManagerLogin(false)
    alert('تم تسجيل الخروج من إدارة التراخيص بنجاح')
  }

  const addProduct = () => {
    // التحقق من صلاحية التفعيل للإدارة
    if (!checkLicenseValidity()) {
      alert('⚠️ النظام غير مفعل أو منتهي الصلاحية!\nيرجى تفعيل النظام من لوحة الإدارة للمتابعة.')
      return
    }

    if (!newProductName || !newProductPrice || !newProductBarcode || !newProductQuantity) {
      alert('يرجى ملء جميع الحقول')
      return
    }
    
    // التحقق من عدم تكرار الباركود
    if (products.find((p: any) => p.barcode === newProductBarcode)) {
      alert('الباركود موجود مسبقاً!')
      return
    }
    
    // التحقق من صحة الكمية
    const quantity = parseInt(newProductQuantity)
    if (isNaN(quantity) || quantity < 0) {
      alert('يرجى إدخال كمية صحيحة (رقم صحيح أكبر من أو يساوي صفر)')
      return
    }
    
    const newProduct = {
      barcode: newProductBarcode,
      name: newProductName,
      price: parseFloat(newProductPrice),
      quantity: quantity
    }
    
    // إضافة المنتج إلى القائمة
    setProducts([...products, newProduct])
    
    setNewProductName('')
    setNewProductPrice('')
    setNewProductBarcode('')
    setNewProductQuantity('')
    alert('تم إضافة المنتج بنجاح!')
  }

  const deleteProduct = (barcode: string) => {
    if (window.confirm('هل أنت متأكد من حذف هذا المنتج؟')) {
      setProducts(products.filter((p: any) => p.barcode !== barcode))
      alert('تم حذف المنتج بنجاح')
    }
  }

  // دوال إدارة المنتجات المحسنة
  const getFilteredAndSortedProducts = () => {
    let filteredProducts = [...products]

    // البحث النصي
    if (productSearch.trim()) {
      filteredProducts = filteredProducts.filter(product =>
        product.name.toLowerCase().includes(productSearch.toLowerCase()) ||
        product.barcode.includes(productSearch)
      )
    }

    // فلتر المنتجات منخفضة المخزون
    if (showLowStock) {
      filteredProducts = filteredProducts.filter(product => product.quantity <= 10)
    }

    // فلتر السعر
    if (priceFilter.min) {
      filteredProducts = filteredProducts.filter(product => product.price >= parseFloat(priceFilter.min))
    }
    if (priceFilter.max) {
      filteredProducts = filteredProducts.filter(product => product.price <= parseFloat(priceFilter.max))
    }

    // فلتر الكمية
    if (quantityFilter.min) {
      filteredProducts = filteredProducts.filter(product => product.quantity >= parseInt(quantityFilter.min))
    }
    if (quantityFilter.max) {
      filteredProducts = filteredProducts.filter(product => product.quantity <= parseInt(quantityFilter.max))
    }

    // ترتيب المنتجات
    filteredProducts.sort((a, b) => {
      let aValue, bValue
      switch (sortBy) {
        case 'name':
          aValue = a.name.toLowerCase()
          bValue = b.name.toLowerCase()
          break
        case 'price':
          aValue = a.price
          bValue = b.price
          break
        case 'quantity':
          aValue = a.quantity
          bValue = b.quantity
          break
        case 'barcode':
          aValue = a.barcode
          bValue = b.barcode
          break
        default:
          aValue = a.name
          bValue = b.name
      }

      if (sortOrder === 'asc') {
        return aValue > bValue ? 1 : -1
      } else {
        return aValue < bValue ? 1 : -1
      }
    })

    return filteredProducts
  }

  const getPaginatedProducts = () => {
    const filtered = getFilteredAndSortedProducts()
    const startIndex = (currentPage - 1) * itemsPerPage
    const endIndex = startIndex + itemsPerPage
    return {
      products: filtered.slice(startIndex, endIndex),
      totalProducts: filtered.length,
      totalPages: Math.ceil(filtered.length / itemsPerPage),
      hasNext: endIndex < filtered.length,
      hasPrev: currentPage > 1
    }
  }

  const getProductStats = () => {
    const total = products.length
    const lowStock = products.filter(p => p.quantity <= 10).length
    const outOfStock = products.filter(p => p.quantity === 0).length
    const totalValue = products.reduce((sum, p) => sum + (p.price * p.quantity), 0)
    
    return { total, lowStock, outOfStock, totalValue }
  }

  const resetFilters = () => {
    setProductSearch('')
    setCurrentPage(1)
    setShowLowStock(false)
    setPriceFilter({ min: '', max: '' })
    setQuantityFilter({ min: '', max: '' })
    setSortBy('name')
    setSortOrder('asc')
  }

  // دوال نظام المزامنة بين الأجهزة
  const syncWithServer = async (direction: 'upload' | 'download' | 'both' = 'both') => {
    if (!syncSettings.enabled || !syncSettings.serverUrl) {
      setSyncMessage('يجب تفعيل المزامنة وتحديد عنوان الخادم أولاً')
      setSyncStatus('error')
      return false
    }

    setSyncStatus('syncing')
    setSyncMessage('جارٍ المزامنة مع الخادم...')

    // التحقق من وجود مفتاح المزامنة
    if (!syncSettings.syncToken) {
      setSyncMessage('يجب إدخال مفتاح المزامنة في الإعدادات أولاً')
      setSyncStatus('error')
      return false
    }

    try {
      const baseUrl = syncSettings.serverUrl.replace(/\/$/, '')
      
      if (direction === 'upload' || direction === 'both') {
        // تنظيف البيانات الحساسة من إعدادات المتجر
        const { adminPassword, licenseKey, ...safeStoreSettings } = storeSettings
        
        // رفع البيانات للخادم (بدون بيانات حساسة)
        const uploadData = {
          deviceName: syncSettings.deviceName,
          timestamp: new Date().toISOString(),
          products,
          orders,
          storeSettings: safeStoreSettings,
          stockMovements,
          returns
        }

        const uploadResponse = await fetch(`${baseUrl}/api/sync/upload`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-Sync-Token': syncSettings.syncToken,
          },
          body: JSON.stringify(uploadData)
        })

        if (!uploadResponse.ok) {
          throw new Error(`خطأ في رفع البيانات: ${uploadResponse.status}`)
        }
      }

      if (direction === 'download' || direction === 'both') {
        // تنزيل البيانات من الخادم
        const downloadResponse = await fetch(`${baseUrl}/api/sync/download?deviceName=${encodeURIComponent(syncSettings.deviceName)}`, {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
            'X-Sync-Token': syncSettings.syncToken,
          }
        })

        if (!downloadResponse.ok) {
          throw new Error(`خطأ في تنزيل البيانات: ${downloadResponse.status}`)
        }

        const serverData = await downloadResponse.json()
        
        // فحص التعارض قبل التطبيق
        const conflicts = detectConflicts(serverData)
        if (conflicts.length > 0) {
          setSyncConflicts(conflicts)
          setSyncMessage(`تم العثور على ${conflicts.length} تعارض في البيانات`)
          setSyncStatus('error')
          return false
        }

        // تطبيق البيانات الجديدة (مع الحفاظ على البيانات الحساسة المحلية)
        if (serverData.products) setProducts(serverData.products)
        if (serverData.orders) setOrders(serverData.orders)
        if (serverData.storeSettings) {
          // دمج الإعدادات مع الحفاظ على البيانات الحساسة المحلية
          setStoreSettings(prev => ({
            ...serverData.storeSettings,
            adminPassword: prev.adminPassword, // الحفاظ على كلمة المرور المحلية
            licenseKey: prev.licenseKey, // الحفاظ على مفتاح الترخيص المحلي
          }))
        }
        if (serverData.stockMovements) setStockMovements(serverData.stockMovements)
        if (serverData.returns) setReturns(serverData.returns)
      }

      // تحديث آخر وقت مزامنة
      setSyncSettings(prev => ({
        ...prev,
        lastSync: new Date().toISOString()
      }))

      setSyncStatus('success')
      setSyncMessage('تمت المزامنة بنجاح!')
      
      // إزالة رسالة النجاح بعد 3 ثوان
      setTimeout(() => {
        setSyncStatus('idle')
        setSyncMessage('')
      }, 3000)

      return true
    } catch (error) {
      console.error('خطأ في المزامنة:', error)
      setSyncStatus('error')
      setSyncMessage(`خطأ في المزامنة: ${error.message}`)
      return false
    }
  }

  const detectConflicts = (serverData: any) => {
    const conflicts: any[] = []

    // فحص تعارض المنتجات
    if (serverData.products) {
      serverData.products.forEach((serverProduct: any) => {
        const localProduct = products.find(p => p.barcode === serverProduct.barcode)
        if (localProduct && (
          localProduct.name !== serverProduct.name ||
          localProduct.price !== serverProduct.price ||
          localProduct.quantity !== serverProduct.quantity
        )) {
          conflicts.push({
            type: 'product',
            barcode: serverProduct.barcode,
            local: localProduct,
            server: serverProduct
          })
        }
      })
    }

    // فحص تعارض الإعدادات (فقط الإعدادات الموجودة فعلاً)
    if (serverData.storeSettings) {
      const settingsKeys = ['storeName', 'currency'] // فقط الإعدادات الموجودة في storeSettings
      settingsKeys.forEach(key => {
        if (storeSettings[key] && serverData.storeSettings[key] && 
            storeSettings[key] !== serverData.storeSettings[key]) {
          conflicts.push({
            type: 'settings',
            key,
            local: storeSettings[key],
            server: serverData.storeSettings[key]
          })
        }
      })
    }

    return conflicts
  }

  // دوال المزامنة اليدوية
  const handleManualUpload = async () => {
    setIsUploading(true)
    await syncWithServer('upload')
    setIsUploading(false)
  }

  const handleManualDownload = async () => {
    setIsDownloading(true)
    await syncWithServer('download')
    setIsDownloading(false)
  }

  const getConnectedDevices = async () => {
    if (!syncSettings.enabled || !syncSettings.serverUrl || !syncSettings.syncToken) return

    try {
      const baseUrl = syncSettings.serverUrl.replace(/\/$/, '')
      
      const response = await fetch(`${baseUrl}/api/sync/devices`, {
        headers: {
          'X-Sync-Token': syncSettings.syncToken,
        }
      })
      
      if (response.ok) {
        const devices = await response.json()
        setConnectedDevices(devices.map((d: any) => d.name))
      } else {
        console.error('خطأ في جلب الأجهزة:', response.status)
      }
    } catch (error) {
      console.error('خطأ في جلب الأجهزة المتصلة:', error)
    }
  }

  const resolveConflict = (conflict: any, resolution: 'local' | 'server') => {
    if (conflict.type === 'product') {
      if (resolution === 'server') {
        // استخدام بيانات الخادم
        setProducts(prev => prev.map(p => 
          p.barcode === conflict.barcode ? conflict.server : p
        ))
      }
      // إذا كان local، لا نحتاج لعمل شيء لأن البيانات المحلية موجودة بالفعل
    } else if (conflict.type === 'settings') {
      if (resolution === 'server') {
        setStoreSettings(prev => ({
          ...prev,
          [conflict.key]: conflict.server
        }))
      }
    }

    // إزالة التعارض من القائمة
    setSyncConflicts(prev => prev.filter(c => c !== conflict))
  }

  // المزامنة التلقائية
  useEffect(() => {
    if (!syncSettings.enabled || !syncSettings.autoSync) return

    const interval = setInterval(() => {
      if (syncStatus === 'idle') {
        syncWithServer('both')
      }
    }, syncSettings.syncInterval)

    return () => clearInterval(interval)
  }, [syncSettings.enabled, syncSettings.autoSync, syncSettings.syncInterval, syncStatus])

  // جلب الأجهزة المتصلة عند تفعيل المزامنة
  useEffect(() => {
    if (syncSettings.enabled) {
      getConnectedDevices()
      const interval = setInterval(getConnectedDevices, 10000) // كل 10 ثوان
      return () => clearInterval(interval)
    }
  }, [syncSettings.enabled])

  // دوال إدارة التراخيص التجارية
  const fetchLicenseData = async () => {
    try {
      // تحديد نوع المصادقة حسب المستخدم المسجل دخوله
      const adminAuth = sessionStorage.getItem('adminAuth');
      const licenseManagerAuth = sessionStorage.getItem('licenseManagerAuth');
      
      let authHeaders: any = null;
      let apiBasePath = '';
      
      if (isLicenseManager && licenseManagerAuth) {
        // مدير التراخيص
        authHeaders = {
          'Authorization': 'Basic ' + licenseManagerAuth
        };
        apiBasePath = '/api/license-manager';
      } else if (isAdmin && adminAuth) {
        // المدير العادي
        authHeaders = {
          'Authorization': 'Basic ' + adminAuth
        };
        apiBasePath = '/api/admin';
      } else {
        console.error('المستخدم غير مسجل دخول');
        return;
      }

      // جلب الإحصائيات
      const statsResponse = await fetch(`${apiBasePath}/stats`, { headers: authHeaders });
      const statsData = statsResponse.ok ? await statsResponse.json() : { stats: { totalLicenses: 0, activeLicenses: 0, expiredLicenses: 0, totalCustomers: 0, totalRevenue: 0, monthlyRevenue: 0 } };
      
      // جلب العملاء
      const customersResponse = await fetch(`${apiBasePath}/customers`, { headers: authHeaders });
      const customersData = customersResponse.ok ? await customersResponse.json() : { customers: [] };
      
      // جلب أنواع التراخيص
      const licenseTypesResponse = await fetch(`${apiBasePath}/license-types`, { headers: authHeaders });
      const licenseTypesData = licenseTypesResponse.ok ? await licenseTypesResponse.json() : { licenseTypes: [] };
      
      // جلب جميع التراخيص
      const licensesResponse = await fetch(`${apiBasePath}/licenses`, { headers: authHeaders });
      const licensesData = licensesResponse.ok ? await licensesResponse.json() : { licenses: [] };
      
      setLicenseManagementData({
        stats: statsData.stats || statsData,
        customers: customersData.customers || customersData,
        licenseTypes: licenseTypesData.licenseTypes || licenseTypesData,
        licenses: licensesData.licenses || licensesData
      });
    } catch (error) {
      console.error('خطأ في جلب بيانات التراخيص:', error);
    }
  };

  const createNewCustomer = async (customerData: any) => {
    try {
      const adminAuth = sessionStorage.getItem('adminAuth');
      if (!adminAuth) {
        alert('يجب تسجيل الدخول كمدير أولاً');
        return false;
      }

      const response = await fetch('/api/admin/customers', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Basic ' + adminAuth
        },
        body: JSON.stringify(customerData)
      });
      
      if (response.ok) {
        await fetchLicenseData();
        return true;
      } else {
        const errorData = await response.json();
        console.error('خطأ من الخادم:', errorData);
        alert(errorData.error || 'حدث خطأ في إضافة العميل');
      }
    } catch (error) {
      console.error('خطأ في إنشاء العميل:', error);
      alert('خطأ في الاتصال بالخادم');
    }
    return false;
  };

  const generateLicense = async (customerId: number, licenseTypeId: number) => {
    try {
      const adminAuth = sessionStorage.getItem('adminAuth');
      if (!adminAuth) {
        alert('يجب تسجيل الدخول كمدير أولاً');
        return false;
      }

      const response = await fetch('/api/admin/licenses', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Basic ' + adminAuth
        },
        body: JSON.stringify({ customerId, licenseTypeId })
      });
      
      if (response.ok) {
        await fetchLicenseData();
        const result = await response.json();
        alert(`تم إنتاج الترخيص بنجاح!\nمفتاح الترخيص: ${result.license.licenseKey}`);
        return true;
      } else {
        const errorData = await response.json();
        console.error('خطأ من الخادم:', errorData);
        alert(errorData.error || 'حدث خطأ في إنتاج الترخيص');
      }
    } catch (error) {
      console.error('خطأ في توليد الترخيص:', error);
      alert('خطأ في الاتصال بالخادم');
    }
    return false;
  };

  // دوال مخصصة لمدير التراخيص
  const createNewCustomerForLicenseManager = async (customerData: any) => {
    try {
      const licenseManagerAuth = sessionStorage.getItem('licenseManagerAuth');
      if (!licenseManagerAuth) {
        alert('يجب تسجيل الدخول كمدير تراخيص أولاً');
        return false;
      }

      const response = await fetch('/api/license-manager/customers', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Basic ' + licenseManagerAuth
        },
        body: JSON.stringify(customerData)
      });
      
      if (response.ok) {
        await fetchLicenseData();
        return true;
      } else {
        const errorData = await response.json();
        console.error('خطأ من الخادم:', errorData);
        alert(errorData.error || 'حدث خطأ في إضافة العميل');
      }
    } catch (error) {
      console.error('خطأ في إنشاء العميل:', error);
      alert('خطأ في الاتصال بالخادم');
    }
    return false;
  };

  // حذف عميل
  const deleteCustomer = async (customerId: number, customerName: string) => {
    // تأكيد الحذف
    if (!confirm(`هل أنت متأكد من حذف العميل "${customerName}"؟\nهذا الإجراء لا يمكن التراجع عنه!`)) {
      return false;
    }

    try {
      // تحديد نوع المدير وإستدعاء الدالة المناسبة
      const adminAuth = sessionStorage.getItem('adminAuth');
      const licenseManagerAuth = sessionStorage.getItem('licenseManagerAuth');
      
      let apiEndpoint = '';
      let authHeader = '';
      
      if (licenseManagerAuth) {
        apiEndpoint = `/api/license-manager/customers/${customerId}`;
        authHeader = 'Basic ' + licenseManagerAuth;
      } else if (adminAuth) {
        apiEndpoint = `/api/admin/customers/${customerId}`;
        authHeader = 'Basic ' + adminAuth;
      } else {
        alert('يجب تسجيل الدخول أولاً');
        return false;
      }

      const response = await fetch(apiEndpoint, {
        method: 'DELETE',
        headers: {
          'Authorization': authHeader
        }
      });
      
      if (response.ok) {
        await fetchLicenseData();
        alert('تم حذف العميل بنجاح!');
        return true;
      } else {
        const errorData = await response.json();
        console.error('خطأ من الخادم:', errorData);
        alert(errorData.error || 'حدث خطأ في حذف العميل');
      }
    } catch (error) {
      console.error('خطأ في حذف العميل:', error);
      alert('خطأ في الاتصال بالخادم');
    }
    return false;
  };

  const generateLicenseForManager = async (customerId: string, licenseType: string) => {
    try {
      const licenseManagerAuth = sessionStorage.getItem('licenseManagerAuth');
      if (!licenseManagerAuth) {
        alert('يجب تسجيل الدخول كمدير تراخيص أولاً');
        return false;
      }

      // تحديد معرف نوع الترخيص بناءً على النوع المحدد
      let licenseTypeId = 1; // افتراضي
      switch(licenseType) {
        case 'basic': licenseTypeId = 1; break;
        case 'premium': licenseTypeId = 2; break;
        case 'enterprise': licenseTypeId = 3; break;
      }

      const response = await fetch('/api/license-manager/licenses', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Basic ' + licenseManagerAuth
        },
        body: JSON.stringify({ customerId, licenseTypeId, licenseType })
      });
      
      if (response.ok) {
        const result = await response.json();
        await fetchLicenseData();
        alert(`تم إنتاج الترخيص بنجاح!\nمفتاح الترخيص: ${result.license?.licenseKey || result.licenseKey || 'غير متاح'}`);
        return true;
      } else {
        const errorData = await response.json();
        console.error('خطأ من الخادم:', errorData);
        alert(errorData.error || 'حدث خطأ في إنتاج الترخيص');
      }
    } catch (error) {
      console.error('خطأ في توليد الترخيص:', error);
      alert('خطأ في الاتصال بالخادم');
    }
    return false;
  };

  // دالة تحديث بيانات التراخيص عند تسجيل دخول مدير التراخيص (منفصل)
  useEffect(() => {
    if (isLicenseManager) {
      fetchLicenseData();
      // تغيير التبويب تلقائياً إلى إدارة التراخيص
      setActiveTab('license-manager');
    }
  }, [isLicenseManager]);

  // حفظ حالة مدير التراخيص في التخزين المحلي
  useEffect(() => {
    saveToLocalStorage('supermarket_license_manager_logged', isLicenseManager)
  }, [isLicenseManager])

  // تنظيف بيانات التراخيص عند تسجيل خروج الأدمن
  useEffect(() => {
    if (!isAdmin) {
      setLicenseManagementData({
        customers: [],
        licenses: [],
        licenseTypes: [],
        stats: { totalLicenses: 0, activeLicenses: 0, expiredLicenses: 0, totalCustomers: 0, totalRevenue: 0 }
      });
    }
  }, [isAdmin]);

  // دوال إدارة إعدادات المتجر والتفعيل
  const updateStoreName = () => {
    if (!newStoreName.trim()) {
      alert('يرجى إدخال اسم المتجر')
      return
    }
    
    setStoreSettings({
      ...storeSettings,
      storeName: newStoreName.trim()
    })
    alert('تم تحديث اسم المتجر بنجاح!')
  }

  const activateLicense = async () => {
    if (!newLicenseKey.trim()) {
      alert('يرجى إدخال كود التفعيل')
      return
    }

    try {
      // توليد Device ID بسيط للنظام
      const deviceId = localStorage.getItem('device-id') || 
        'POS-' + Date.now() + '-' + Math.random().toString(36).substr(2, 9);
      localStorage.setItem('device-id', deviceId);

      // استدعاء API التحقق من كود التفعيل
      const response = await fetch('/api/validate-activation-code', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          licenseKey: newLicenseKey.trim().toUpperCase(),
          deviceId: deviceId,
          storeName: storeSettings.storeName || 'متجر نقاط البيع'
        }),
      });

      const result = await response.json();

      if (!result.valid) {
        alert(`كود التفعيل غير صحيح:\n${result.error}`);
        return;
      }

      // إذا كان الكود صحيحاً، حفظ معلومات الترخيص
      const license = result.license;
      const customer = result.customer;
      const licenseType = result.licenseType;

      setStoreSettings({
        ...storeSettings,
        licenseKey: license.key,
        licenseExpiry: license.expiryDate,
        isActivated: true,
        // حفظ معلومات إضافية عن الترخيص
        licenseInfo: {
          customerId: customer?.id,
          customerName: customer?.companyName,
          contactPerson: customer?.contactPerson,
          licenseType: licenseType?.name,
          licenseDescription: licenseType?.description,
          deviceId: deviceId,
          activatedAt: result.activationInfo.activatedAt,
          remainingDays: license.remainingDays
        }
      });

      setNewLicenseKey('');

      // رسالة تفعيل تفصيلية
      const expiryDate = new Date(license.expiryDate).toLocaleDateString('ar-LB');
      const licenseTypeName = licenseType?.name || 'عادي';
      const customerName = customer?.companyName || 'غير محدد';
      
      alert(`✅ تم تفعيل النظام بنجاح!

🏢 العميل: ${customerName}
📝 نوع الترخيص: ${licenseTypeName}
📅 صالح حتى: ${expiryDate}
⏰ المدة المتبقية: ${license.remainingDays} يوم

شكراً لاختياركم نظام نقاط البيع الخاص بنا! 🎉`);

    } catch (error) {
      console.error('خطأ في التحقق من كود التفعيل:', error);
      alert('حدث خطأ أثناء التحقق من كود التفعيل. يرجى المحاولة مرة أخرى.');
    }
  }

  // دوال إدارة تسجيل دخول الإدارة
  const updateAdminUsername = () => {
    if (!newAdminUsername.trim()) {
      alert('يرجى إدخال اسم المستخدم')
      return
    }
    
    setStoreSettings({
      ...storeSettings,
      adminUsername: newAdminUsername.trim()
    })
    alert('تم تحديث اسم المستخدم بنجاح!')
  }

  const updateAdminPassword = () => {
    if (!newAdminPassword.trim()) {
      alert('يرجى إدخال كلمة المرور الجديدة')
      return
    }
    
    if (newAdminPassword.length < 6) {
      alert('كلمة المرور يجب أن تكون 6 أحرف على الأقل')
      return
    }
    
    setStoreSettings({
      ...storeSettings,
      adminPassword: newAdminPassword.trim()
    })
    setNewAdminPassword('')
    alert('تم تحديث كلمة المرور بنجاح!')
  }

  // دالة تحديث العملة
  const updateCurrency = (newCurrency: string) => {
    setStoreSettings({
      ...storeSettings,
      currency: newCurrency
    })
    alert(`تم تغيير العملة إلى ${currencies[newCurrency as keyof typeof currencies]?.name}`)
  }

  // دوال إدارة الصادر والوارد والمخزون
  const addStockMovement = () => {
    // التحقق من صلاحية التفعيل
    if (!checkLicenseValidity()) {
      alert('⚠️ النظام غير مفعل أو منتهي الصلاحية!\nيرجى تفعيل النظام من لوحة الإدارة للمتابعة.')
      return
    }

    if (!newMovementProduct.trim() || !newMovementQuantity.trim() || !newMovementReason.trim()) {
      alert('يرجى ملء جميع الحقول المطلوبة')
      return
    }

    const quantity = parseInt(newMovementQuantity)
    if (isNaN(quantity) || quantity <= 0) {
      alert('يرجى إدخال كمية صحيحة (رقم أكبر من صفر)')
      return
    }

    const newMovement = {
      id: Date.now().toString(),
      date: new Date().toLocaleDateString('ar-LB'),
      time: new Date().toLocaleTimeString('ar-LB'),
      type: newMovementType,
      productName: newMovementProduct.trim(),
      quantity: quantity,
      reason: newMovementReason.trim(),
      notes: newMovementNotes.trim(),
      user: 'المدير' // يمكن تطويرها لاحقاً لإضافة أسماء مستخدمين مختلفة
    }

    setStockMovements([newMovement, ...stockMovements])
    
    // مسح الحقول
    setNewMovementProduct('')
    setNewMovementQuantity('')
    setNewMovementReason('')
    setNewMovementNotes('')
    
    const movementTypeText = newMovementType === 'incoming' ? 'وارد' : 'صادر'
    alert(`تم تسجيل حركة ${movementTypeText} بنجاح!`)
  }

  const deleteStockMovement = (movementId: string) => {
    if (window.confirm('هل أنت متأكد من حذف هذه الحركة؟')) {
      setStockMovements(stockMovements.filter((movement: any) => movement.id !== movementId))
      alert('تم حذف الحركة بنجاح')
    }
  }

  // حساب إجمالي الوارد والصادر
  const getTotalIncoming = () => {
    return stockMovements
      .filter((movement: any) => movement.type === 'incoming')
      .reduce((total: number, movement: any) => total + movement.quantity, 0)
  }

  const getTotalOutgoing = () => {
    return stockMovements
      .filter((movement: any) => movement.type === 'outgoing')
      .reduce((total: number, movement: any) => total + movement.quantity, 0)
  }

  const getNetStock = () => {
    return getTotalIncoming() - getTotalOutgoing()
  }

  const checkLicenseValidity = () => {
    if (!storeSettings.isActivated || !storeSettings.licenseExpiry) {
      return false
    }
    
    const expiryDate = new Date(storeSettings.licenseExpiry)
    const today = new Date()
    
    return today < expiryDate
  }

  const getLicenseStatusText = () => {
    if (!storeSettings.isActivated) {
      return 'غير مفعل'
    }
    
    if (!checkLicenseValidity()) {
      return 'منتهي الصلاحية'
    }
    
    const expiryDate = new Date(storeSettings.licenseExpiry)
    return `مفعل حتى ${expiryDate.toLocaleDateString('ar-LB')}`
  }

  const deleteOrder = (orderId: string) => {
    if (window.confirm('هل أنت متأكد من حذف هذا الطلب نهائياً؟')) {
      setOrders(orders.filter(order => order.id !== orderId))
      alert('تم حذف الطلب بنجاح')
    }
  }

  // دالة لإضافة بيانات تجريبية لاختبار اسم الموظف
  const addSampleDataWithEmployee = () => {
    if (!currentEmployee) {
      alert('⚠️ يجب تسجيل دخول موظف أولاً')
      return
    }

    const sampleOrders = [
      {
        id: Date.now().toString() + '1',
        date: new Date().toLocaleDateString('ar-LB'),
        time: new Date().toLocaleTimeString('ar-LB'),
        createdAt: new Date().toISOString(),
        total: 45000,
        items: [
          { id: '1', name: 'خبز عربي', price: 5000, quantity: 2, barcode: '123456', total: 10000 },
          { id: '2', name: 'حليب طازج', price: 15000, quantity: 1, barcode: '789012', total: 15000 },
          { id: '3', name: 'جبنة بيضاء', price: 20000, quantity: 1, barcode: '345678', total: 20000 }
        ],
        status: 'completed' as const,
        customerName: 'أحمد محمد',
        employeeName: `${currentEmployee.name} (${currentEmployee.username})`,
        paymentMethod: 'cash' as const
      },
      {
        id: Date.now().toString() + '2',
        date: new Date().toLocaleDateString('ar-LB'),
        time: new Date().toLocaleTimeString('ar-LB'),
        createdAt: new Date().toISOString(),
        total: 32000,
        items: [
          { id: '4', name: 'زيت الطبخ', price: 25000, quantity: 1, barcode: '567890', total: 25000 },
          { id: '5', name: 'سكر أبيض', price: 7000, quantity: 1, barcode: '234567', total: 7000 }
        ],
        status: 'completed' as const,
        customerName: 'فاطمة علي',
        employeeName: `${currentEmployee.name} (${currentEmployee.username})`,
        paymentMethod: 'card' as const
      },
      {
        id: Date.now().toString() + '3',
        date: new Date().toLocaleDateString('ar-LB'),
        time: new Date().toLocaleTimeString('ar-LB'),
        createdAt: new Date().toISOString(),
        total: 18000,
        items: [
          { id: '6', name: 'شاي أحمر', price: 12000, quantity: 1, barcode: '890123', total: 12000 },
          { id: '7', name: 'معكرونة', price: 6000, quantity: 1, barcode: '456789', total: 6000 }
        ],
        status: 'pending' as const,
        customerName: 'محمد حسن',
        employeeName: `${currentEmployee.name} (${currentEmployee.username})`,
        paymentMethod: 'cash' as const
      }
    ]

    setOrders(prev => [...sampleOrders, ...prev])
    alert(`✅ تم إضافة ${sampleOrders.length} فواتير تجريبية مع اسم الكاشيير: ${currentEmployee.name}`)
  }

  // دالة البحث عن فاتورة برقمها
  const searchForInvoice = () => {
    if (!searchInvoiceNumber.trim()) {
      setSearchError('⚠️ يرجى إدخال رقم الفاتورة أولاً')
      setSearchResult(null)
      return
    }

    const foundOrder = orders.find(order => order.id === searchInvoiceNumber.trim())
    
    if (foundOrder) {
      setSearchResult(foundOrder)
      setSearchError('')
      alert(`✅ تم العثور على الفاتورة رقم: ${searchInvoiceNumber}`)
    } else {
      setSearchResult(null)
      setSearchError(`❌ لم يتم العثور على فاتورة برقم: ${searchInvoiceNumber}`)
      alert(`❌ لم يتم العثور على فاتورة برقم: ${searchInvoiceNumber}`)
    }
  }

  // دالة لمسح نتائج البحث
  const clearSearchResults = () => {
    setSearchInvoiceNumber('')
    setSearchResult(null)
    setSearchError('')
  }

  const saveOrder = () => {
    // التحقق من صلاحية التفعيل
    if (!checkLicenseValidity()) {
      alert('⚠️ النظام غير مفعل أو منتهي الصلاحية!\nيرجى تفعيل النظام من لوحة الإدارة للمتابعة.')
      return
    }

    if (cart.length === 0) {
      alert('السلة فارغة')
      return
    }

    const newOrder: Order = {
      id: currentOrderId || Date.now().toString(),
      date: new Date().toLocaleDateString('ar-LB'),
      time: new Date().toLocaleTimeString('ar-LB'),
      createdAt: new Date().toISOString(),
      total: getTotalPrice(),
      items: [...cart],
      status: 'pending',
      customerName: customerName || 'عميل',
      employeeName: currentEmployee ? `${currentEmployee.name} (${currentEmployee.username})` : 'غير محدد'
    }

    if (currentOrderId) {
      // تحديث طلب موجود
      setOrders(orders.map(order => 
        order.id === currentOrderId ? newOrder : order
      ))
    } else {
      // إضافة طلب جديد
      setOrders([...orders, newOrder])
    }
    
    clearCart()
    alert('تم حفظ الطلب بنجاح')
  }

  const completeOrder = (orderId: string) => {
    setOrders(orders.map(order => 
      order.id === orderId ? { ...order, status: 'completed' } : order
    ))
  }

  const cancelOrder = (orderId: string) => {
    setOrders(orders.map(order => 
      order.id === orderId ? { ...order, status: 'cancelled' } : order
    ))
  }

  // دالة لفتح الصندوق
  const openCashDrawer = () => {
    // فتح الصندوق - يمكن إرسال إشارة للطابعة الحرارية لفتح الصندوق
    // ESC/POS command: ESC p m t1 t2 (0x1B 0x70 0x00 0x19 0x19)
    console.log('🔓 فتح الصندوق...')
    
    // يمكن إضافة كود هنا لإرسال أمر فتح الصندوق للطابعة
    // أو التحكم في الصندوق عبر منفذ تسلسلي أو USB
  }

  // دالة backup للبيانات
  const exportAllData = () => {
    const allData = {
      exportDate: new Date().toISOString(),
      exportTime: new Date().toLocaleString('ar-LB'),
      storeName: storeSettings.storeName,
      data: {
        orders: loadFromLocalStorage('supermarket_orders', []),
        products: loadFromLocalStorage('supermarket_products', []),
        settings: loadFromLocalStorage('supermarket_settings', {}),
        stockMovements: loadFromLocalStorage('supermarket_stock_movements', []),
        returns: loadFromLocalStorage('supermarket_returns', [])
      }
    }

    const dataStr = JSON.stringify(allData, null, 2)
    const dataBlob = new Blob([dataStr], { type: 'application/json' })
    const url = URL.createObjectURL(dataBlob)
    
    const link = document.createElement('a')
    link.href = url
    link.download = `supermarket_backup_${new Date().toISOString().split('T')[0]}.json`
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
    URL.revokeObjectURL(url)
    
    alert('تم تصدير البيانات بنجاح!')
  }

  // دالة حساب المبيعات السنوية - محسّنة للتعامل مع التواريخ العربية
  const calculateAnnualSales = () => {
    const currentYear = new Date().getFullYear()
    const completedOrders = orders.filter(order => order.status === 'completed')
    
    const yearlyTotal = completedOrders
      .filter(order => {
        try {
          // إذا كان هناك createdAt، استخدمه
          if (order.createdAt) {
            const orderDate = new Date(order.createdAt)
            return orderDate.getFullYear() === currentYear
          }
          
          // إذا لم يكن هناك createdAt، حاول تحليل التاريخ المحلي
          // أو استخدم السنة الحالية إذا فشل التحليل
          const orderDate = new Date(order.date)
          if (isNaN(orderDate.getTime())) {
            // إذا فشل التحليل، افترض أنه من السنة الحالية
            return true
          }
          return orderDate.getFullYear() === currentYear
        } catch {
          // في حالة الخطأ، افترض أنه من السنة الحالية
          return true
        }
      })
      .reduce((total, order) => total + order.total, 0)
    
    return yearlyTotal
  }

  // دالة مسح كافة المبيعات وتصفير سجل العمليات
  const clearAllSalesData = () => {
    const confirmation = window.confirm(
      '⚠️ تحذير: هذا الإجراء سيقوم بحذف جميع البيانات التالية نهائياً:\n\n' +
      '• جميع الطلبات والمبيعات المكتملة\n' +
      '• جميع الإيصالات المطبوعة\n' +
      '• جميع عمليات الإرجاع والاسترداد\n' +
      '• سجل حركات المخزون\n\n' +
      'هل أنت متأكد من أنك تريد المتابعة؟\n' +
      'لا يمكن التراجع عن هذا الإجراء!'
    )

    if (!confirmation) {
      return
    }

    // تأكيد إضافي لضمان عدم الحذف بالخطأ
    const finalConfirmation = window.confirm(
      '🔴 تأكيد نهائي:\n\n' +
      'سيتم حذف جميع بيانات المبيعات والعمليات نهائياً.\n' +
      'هذا الإجراء لا يمكن التراجع عنه!\n\n' +
      'اكتب "نعم" في الحقل التالي للتأكيد:'
    )

    if (!finalConfirmation) {
      return
    }

    const textConfirmation = prompt('أكتب "نعم" للتأكيد النهائي:')
    if (textConfirmation !== 'نعم') {
      alert('تم إلغاء العملية.')
      return
    }

    try {
      // حذف جميع البيانات المتعلقة بالمبيعات
      localStorage.removeItem('supermarket_orders')
      localStorage.removeItem('supermarket_receipts')  
      localStorage.removeItem('supermarket_returns')
      localStorage.removeItem('supermarket_stock_movements')
      
      // إعادة تعيين المتغيرات المحلية
      setOrders([])
      setCurrentOrderId('')
      setReturns([])
      setStockMovements([])
      
      alert('✅ تم مسح جميع بيانات المبيعات وتصفير سجل العمليات بنجاح!\n\nتم حذف:\n• جميع الطلبات والمبيعات\n• جميع الإيصالات\n• جميع عمليات الإرجاع\n• سجل حركات المخزون')
      
      // إعادة تحديث الصفحة للتأكد من تطبيق التغييرات
      window.location.reload()
      
    } catch (error) {
      console.error('خطأ في مسح البيانات:', error)
      alert('❌ حدث خطأ أثناء مسح البيانات. يرجى المحاولة مرة أخرى.')
    }
  }

  const processPayment = () => {
    // التحقق من صلاحية التفعيل
    if (!checkLicenseValidity()) {
      alert('⚠️ النظام غير مفعل أو منتهي الصلاحية!\nيرجى تفعيل النظام من لوحة الإدارة للمتابعة.')
      setShowPaymentModal(false)
      return
    }

    if (cart.length === 0) {
      alert('لا توجد منتجات في السلة')
      return
    }

    if (!paymentType) {
      alert('يرجى اختيار طريقة الدفع')
      return
    }

    const total = getTotalPrice()
    const paid = parseFloat(amountPaid) || 0
    
    if (paymentType === 'cash' && paid < total) {
      alert('المبلغ المدفوع أقل من المجموع المطلوب')
      return
    }

    if (paymentType === 'card' && total <= 0) {
      alert('مبلغ غير صحيح للدفع بالبطاقة')
      return
    }
    
    // إنشاء طلب مكتمل
    const completedOrder: Order = {
      id: currentOrderId || Date.now().toString(),
      date: new Date().toLocaleDateString('ar-LB'),
      time: new Date().toLocaleTimeString('ar-LB'),
      createdAt: new Date().toISOString(),
      total: total,
      items: [...cart],
      status: 'completed',
      customerName: customerName || 'عميل',
      employeeName: currentEmployee ? `${currentEmployee.name} (${currentEmployee.username})` : 'غير محدد',
      paymentMethod: paymentType,
      amountPaid: paymentType === 'cash' ? paid : total,
      change: paymentType === 'cash' ? (paid - total) : 0
    }

    // حفظ الطلب
    if (currentOrderId) {
      setOrders(orders.map(order => 
        order.id === currentOrderId ? completedOrder : order
      ))
    } else {
      setOrders([...orders, completedOrder])
    }
    
    // مسح السلة وإغلاق نافذة الدفع
    clearCart()
    setShowPaymentModal(false)
    setAmountPaid('')
    setPaymentType(null)
    
    // فتح الصندوق في كلا الحالتين
    openCashDrawer()
    
    // عرض مربع حوار للسؤال عن الطباعة
    const shouldPrint = confirm(
      `✅ تم الدفع بنجاح!\n\n` +
      `${paymentType === 'cash' && paid > total ? 
        `💰 الباقي للزبون: ${formatPrice(paid - total)}\n\n` : 
        ''
      }` +
      `🔓 تم فتح الصندوق\n\n` +
      `هل تريد طباعة الفاتورة؟`
    )
    
    if (shouldPrint) {
      printReceipt(completedOrder)
    }
    
    // رسالة تأكيد أخيرة
    if (paymentType === 'cash' && paid > total) {
      alert(`💰 لا تنس إعطاء الباقي للزبون: ${formatPrice(paid - total)}`)
    }
  }

  // وظيفة معالجة الإرجاع ورد المصاري
  const processReturn = () => {
    if (!selectedOrder) return
    
    // التحقق من وجود أصناف للإرجاع
    const hasItemsToReturn = Object.values(returnItems).some(qty => qty > 0)
    if (!hasItemsToReturn) {
      alert('يرجى تحديد الأصناف المراد إرجاعها')
      return
    }

    // التحقق من صحة كميات الإرجاع ومنع الإرجاع الزائد
    const invalidReturns = []
    for (const item of selectedOrder.items) {
      const requestedReturnQty = returnItems[item.barcode] || 0
      if (requestedReturnQty > 0) {
        // حساب الكمية المرجعة مسبقاً لهذا الصنف من هذه الفاتورة
        const alreadyReturned = returns.reduce((total, returnRecord) => {
          if (returnRecord.originalOrderId === selectedOrder.id) {
            const returnedItem = returnRecord.returnedItems.find(ri => ri.barcode === item.barcode)
            return total + (returnedItem ? returnedItem.returnedQuantity : 0)
          }
          return total
        }, 0)
        
        const maxReturnableQty = item.quantity - alreadyReturned
        if (requestedReturnQty > maxReturnableQty) {
          invalidReturns.push({
            name: item.name,
            requested: requestedReturnQty,
            available: maxReturnableQty,
            alreadyReturned: alreadyReturned
          })
        }
      }
    }

    // إذا كان هناك إرجاعات غير صحيحة، اعرض رسالة خطأ
    if (invalidReturns.length > 0) {
      const errorMessage = invalidReturns.map(item => 
        `${item.name}: طلبت إرجاع ${item.requested} لكن المتاح للإرجاع ${item.available} فقط` +
        (item.alreadyReturned > 0 ? ` (تم إرجاع ${item.alreadyReturned} مسبقاً)` : '')
      ).join('\n')
      
      alert('⚠️ خطأ في كميات الإرجاع:\n\n' + errorMessage + '\n\nيرجى تصحيح الكميات والمحاولة مرة أخرى.')
      return
    }

    // حساب إجمالي المبلغ المرجع
    const totalReturnAmount = selectedOrder.items.reduce((total, item) => {
      const returnQty = returnItems[item.barcode] || 0
      return total + (returnQty * item.price)
    }, 0)

    // إنشاء سجل الإرجاع
    const returnRecord = {
      id: Date.now().toString(),
      originalOrderId: selectedOrder.id,
      originalOrderDate: selectedOrder.date,
      returnDate: new Date().toLocaleDateString('ar-LB'),
      returnTime: new Date().toLocaleTimeString('ar-LB'),
      customerName: selectedOrder.customerName,
      returnedItems: selectedOrder.items.filter(item => 
        returnItems[item.barcode] && returnItems[item.barcode] > 0
      ).map(item => ({
        ...item,
        returnedQuantity: returnItems[item.barcode],
        returnAmount: returnItems[item.barcode] * item.price
      })),
      totalReturnAmount: totalReturnAmount,
      reason: returnReason,
      processedBy: currentEmployee ? `${currentEmployee.name} (${currentEmployee.username})` : 'غير محدد'
    }

    // إضافة السجل إلى قائمة المرتجعات
    setReturns(prev => [returnRecord, ...prev])

    // تحديث المخزون (إضافة الكميات المرجعة)
    const returnedItems = selectedOrder.items.filter(item => 
      returnItems[item.barcode] && returnItems[item.barcode] > 0
    )

    returnedItems.forEach(item => {
      const returnedQty = returnItems[item.barcode]
      
      // تحديث كمية المنتج في المخزون
      setProducts(prev => prev.map(product => 
        product.barcode === item.barcode 
          ? { ...product, quantity: (product.quantity || 0) + returnedQty }
          : product
      ))

      // إضافة حركة مخزون للإرجاع
      const stockMovement = {
        id: Date.now().toString() + Math.random(),
        productName: item.name,
        productBarcode: item.barcode,
        type: 'incoming' as const,
        quantity: returnedQty,
        reason: `إرجاع من فاتورة ${selectedOrder.id}`,
        notes: returnReason || 'إرجاع من العميل',
        date: new Date().toLocaleDateString('ar-LB'),
        time: new Date().toLocaleTimeString('ar-LB')
      }
      
      setStockMovements(prev => [stockMovement, ...prev])
    })

    // فتح الصندوق لرد المصاري
    openCashDrawer()

    // عرض رسالة تأكيد مع خيار الطباعة
    const shouldPrint = confirm(
      `✅ تم تسجيل الإرجاع بنجاح!\n\n` +
      `💰 المبلغ المرجع للزبون: ${formatPrice(totalReturnAmount)}\n\n` +
      `🔓 تم فتح الصندوق لرد المصاري\n\n` +
      `هل تريد طباعة فاتورة الإرجاع؟`
    )

    if (shouldPrint) {
      printReturnReceipt(returnRecord)
    }

    // إغلاق نافذة الإرجاع وإعادة تعيين البيانات
    setShowReturnModal(false)
    setSelectedOrder(null)
    setReturnItems({})
    setReturnReason('')

    // رسالة تأكيد أخيرة
    alert(`💰 لا تنس إعطاء المبلغ المرجع للزبون: ${formatPrice(totalReturnAmount)}`)
  }

  const printReceipt = (order?: Order) => {
    const orderToPrint = order || {
      id: Date.now().toString(),
      date: new Date().toLocaleDateString('ar-LB'),
      total: getTotalPrice(),
      items: cart,
      status: 'completed' as const,
      customerName: customerName || 'عميل',
      paymentMethod: 'cash' as const,
      employeeName: currentEmployee ? `${currentEmployee.name} (${currentEmployee.username})` : 'غير محدد'
    }

    // تنسيق النص للطابعة الحرارية - عرض 40 حرف
    const centerText = (text: string, width = 40) => {
      const padding = Math.max(0, Math.floor((width - text.length) / 2))
      return ' '.repeat(padding) + text
    }

    const leftRightText = (left: string, right: string, width = 40) => {
      const totalSpace = width - left.length - right.length
      return left + ' '.repeat(Math.max(1, totalSpace)) + right
    }

    const line = (char = '-', width = 40) => {
      return char.repeat(width)
    }

    const receiptWindow = window.open('', '_blank')
    const receiptHTML = `
      <!DOCTYPE html>
      <html dir="rtl">
      <head>
        <title>فاتورة حرارية</title>
        <meta charset="UTF-8">
        <style>
          @media print {
            @page { 
              size: 80mm auto; 
              margin: 0mm;
            }
            body { 
              font-family: 'Courier New', monospace;
              font-size: 12px;
              line-height: 1.2;
              margin: 0;
              padding: 2mm;
              background: white;
              color: black;
              width: 80mm;
              max-width: 80mm;
            }
            .no-print { display: none; }
          }
          
          body { 
            font-family: 'Courier New', monospace;
            font-size: 12px;
            line-height: 1.2;
            margin: 0;
            padding: 10px;
            background: white;
            color: black;
            width: 80mm;
            max-width: 80mm;
            direction: rtl;
          }
          
          .receipt {
            width: 100%;
            white-space: pre-line;
          }
          
          .center { 
            text-align: center; 
            font-weight: bold;
          }
          
          .bold { 
            font-weight: bold; 
          }
          
          .line { 
            font-family: monospace;
            white-space: pre;
          }
          
          .item-line {
            font-family: 'Courier New', monospace;
            white-space: pre;
            font-size: 11px;
            margin: 2px 0;
          }
        </style>
      </head>
      <body>
        <div class="receipt">
          <div class="center">
${centerText('🛒 ' + storeSettings.storeName)}
${centerText('==========')}
          </div>
          
          <div class="center">
${centerText('فاتورة رقم: ' + orderToPrint.id)}
          </div>
          
          <div class="line">
${line('=')}
${leftRightText('التاريخ:', orderToPrint.date)}
${leftRightText('الوقت:', new Date().toLocaleTimeString('ar-LB', { hour12: false }))}
${leftRightText('العميل:', orderToPrint.customerName)}
${leftRightText('الكاشير:', orderToPrint.employeeName || 'غير محدد')}
${leftRightText('الدفع:', orderToPrint.paymentMethod === 'cash' ? 'نقدي' : 'بطاقة')}
${line('=')}
          </div>
          
          <div class="bold center">
المنتجات
          </div>
          
          <div class="line">
${line('-')}
          </div>
          
          ${orderToPrint.items.map(item => {
            const itemName = item.name.length > 20 ? item.name.substring(0, 20) + '...' : item.name
            const price = formatPrice(item.price)
            const total = formatPrice(item.total)
            return `<div class="item-line">${itemName}
${leftRightText(`${item.quantity} x ${price}`, total)}</div>`
          }).join('')}
          
          <div class="line">
${line('-')}
${leftRightText('عدد الأصناف:', orderToPrint.items.reduce((sum, item) => sum + item.quantity, 0).toString())}
${line('=')}
          </div>
          
          <div class="bold">
${leftRightText('المجموع الكلي:', formatPrice(orderToPrint.total))}
          </div>
          
          ${orderToPrint.paymentMethod === 'cash' && orderToPrint.amountPaid ? `
          <div class="line">
${leftRightText('المبلغ المدفوع:', formatPrice(orderToPrint.amountPaid))}
${leftRightText('الباقي:', formatPrice(orderToPrint.change || 0))}
          </div>
          ` : ''}
          
          <div class="line">
${line('=')}
          </div>
          
          <div class="center">
${centerText('شكراً لتسوقكم معنا')}
${centerText('نتمنى لكم يوماً سعيداً')}
${centerText('مع أطيب التمنيات')}
          </div>
          
          <div class="line">
${line('=')}
          </div>
        </div>
        
        <div class="no-print" style="margin-top: 20px; text-align: center;">
          <button onclick="window.print()" style="
            background-color: #2c5aa0; 
            color: white; 
            border: none; 
            padding: 10px 20px; 
            font-size: 16px; 
            border-radius: 5px;
            cursor: pointer;
            margin: 5px;
          ">
            🖨️ طباعة الفاتورة
          </button>
          <button onclick="window.close()" style="
            background-color: #e74c3c; 
            color: white; 
            border: none; 
            padding: 10px 20px; 
            font-size: 16px; 
            border-radius: 5px;
            cursor: pointer;
            margin: 5px;
          ">
            ❌ إغلاق
          </button>
        </div>
        
        <script>
          // طباعة تلقائية عند تحميل النافذة
          window.onload = function() {
            setTimeout(function() {
              window.print();
            }, 500);
          }
        </script>
      </body>
      </html>
    `
    if (receiptWindow) {
      receiptWindow.document.write(receiptHTML)
      receiptWindow.document.close()
    }
  }

  // وظيفة طباعة فاتورة الإرجاع
  const printReturnReceipt = (returnRecord: any) => {
    // تنسيق النص للطابعة الحرارية - عرض 40 حرف
    const centerText = (text: string, width = 40) => {
      const padding = Math.max(0, Math.floor((width - text.length) / 2))
      return ' '.repeat(padding) + text
    }

    const leftRightText = (left: string, right: string, width = 40) => {
      const totalSpace = width - left.length - right.length
      return left + ' '.repeat(Math.max(1, totalSpace)) + right
    }

    const line = (char = '-', width = 40) => {
      return char.repeat(width)
    }

    const receiptWindow = window.open('', '_blank')
    const receiptHTML = `
      <!DOCTYPE html>
      <html dir="rtl">
      <head>
        <title>فاتورة إرجاع حرارية</title>
        <meta charset="UTF-8">
        <style>
          @media print {
            @page { 
              size: 80mm auto; 
              margin: 0mm;
            }
            body { 
              margin: 0;
              font-family: "Courier New", monospace;
              font-size: 12px;
              line-height: 1.2;
            }
          }
          @media screen {
            body {
              font-family: "Courier New", monospace;
              max-width: 300px;
              margin: 20px auto;
              padding: 20px;
              border: 1px solid #ccc;
              background: #f9f9f9;
            }
          }
          .line {
            margin: 2px 0;
            white-space: pre-wrap;
            font-family: "Courier New", monospace;
          }
        </style>
      </head>
      <body>
        <div class="line">${centerText('🔄 فاتورة إرجاع 🔄')}</div>
        <div class="line">${centerText(storeSettings.storeName)}</div>
        <div class="line">${line('=')}</div>
        <div class="line">${leftRightText('رقم الإرجاع:', returnRecord.id)}</div>
        <div class="line">${leftRightText('الفاتورة الأصلية:', returnRecord.originalOrderId)}</div>
        <div class="line">${leftRightText('تاريخ الإرجاع:', returnRecord.returnDate)}</div>
        <div class="line">${leftRightText('وقت الإرجاع:', returnRecord.returnTime)}</div>
        <div class="line">${leftRightText('العميل:', returnRecord.customerName)}</div>
        <div class="line">${line('-')}</div>
        
        ${returnRecord.returnedItems.map((item: any) => `
          <div class="line">${item.name}</div>
          <div class="line">${leftRightText(`${item.returnedQuantity} × ${formatPrice(item.price)}`, formatPrice(item.returnAmount))}</div>
        `).join('')}
        
        <div class="line">${line('=')}</div>
        <div class="line">${leftRightText('إجمالي المبلغ المرجع:', formatPrice(returnRecord.totalReturnAmount))}</div>
        <div class="line">${line('=')}</div>
        
        ${returnRecord.reason ? `
          <div class="line">${centerText('سبب الإرجاع:')}</div>
          <div class="line">${centerText(returnRecord.reason)}</div>
          <div class="line">${line('-')}</div>
        ` : ''}
        
        <div class="line">${leftRightText('تم المعالجة بواسطة:', returnRecord.processedBy)}</div>
        <div class="line">${line('-')}</div>
        <div class="line">${centerText('شكراً لثقتكم بنا')}</div>
        <div class="line">${centerText('تم الإرجاع بنجاح')}</div>
        <div class="line">${line('=')}</div>
      </body>
      </html>
    `

    if (receiptWindow) {
      receiptWindow.document.write(receiptHTML)
      receiptWindow.document.close()
      
      // طباعة تلقائية
      receiptWindow.onload = () => {
        receiptWindow.print()
      }
    }
  }

  const loadOrder = (orderId: string) => {
    const order = orders.find(o => o.id === orderId)
    if (order) {
      setCart(order.items)
      setCurrentOrderId(order.id)
      setCustomerName(order.customerName)
    }
  }

  return (
    <div style={{ 
      fontFamily: 'Arial, sans-serif',
      direction: 'rtl',
      backgroundColor: '#f0f0f0',
      minHeight: '100vh',
      padding: 0,
      margin: 0
    }}>
      {/* شريط الأدوات العلوي */}
      <div style={{
        backgroundColor: '#2c5aa0',
        padding: '4px 10px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
        minHeight: '55px'
      }}>
        <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
          <div style={{ color: 'white', fontSize: '14px', fontWeight: 'bold' }}>
            🛒 نظام كاشيير {storeSettings.storeName}
          </div>
          
          {/* أزرار تسجيل الدخول */}
          <div style={{ display: 'flex', gap: '4px', alignItems: 'center' }}>
            {!isAdmin && (
              <button
                onClick={() => setShowAdminLogin(true)}
                style={{
                  backgroundColor: '#3498db',
                  color: 'white',
                  border: 'none',
                  padding: '2px 6px',
                  borderRadius: '6px',
                  cursor: 'pointer',
                  fontSize: '10px',
                  fontWeight: 'bold'
                }}
              >
                🔐 دخول مدير
              </button>
            )}
          </div>
          
          {/* فاصل بصري */}
          <div style={{ 
            width: '2px', 
            height: '15px', 
            backgroundColor: 'rgba(255,255,255,0.3)', 
            margin: '0 2px' 
          }}></div>
          
          {/* أزرار مدير التراخيص (منفصلة) */}
          <div style={{ display: 'flex', gap: '4px', alignItems: 'center' }}>
            {!isLicenseManager && (
              <button
                onClick={() => setShowLicenseManagerLogin(true)}
                style={{
                  backgroundColor: '#e67e22',
                  color: 'white',
                  border: 'none',
                  padding: '2px 6px',
                  borderRadius: '6px',
                  cursor: 'pointer',
                  fontSize: '10px',
                  fontWeight: 'bold'
                }}
              >
                🔑 دخول مدير تراخيص
              </button>
            )}
          </div>
          
          {/* فاصل بصري آخر */}
          <div style={{ 
            width: '2px', 
            height: '15px', 
            backgroundColor: 'rgba(255,255,255,0.3)', 
            margin: '0 2px' 
          }}></div>
          
          {/* قسم تسجيل دخول الموظفين */}
          <div style={{ display: 'flex', gap: '4px', alignItems: 'center' }}>
            {isEmployeeLoggedIn && currentEmployee ? (
              // عرض معلومات الموظف المسجل وزر الخروج
              <div style={{ display: 'flex', gap: '4px', alignItems: 'center' }}>
                <span style={{ 
                  color: '#27ae60', 
                  fontWeight: 'bold', 
                  fontSize: '10px',
                  backgroundColor: 'rgba(39,174,96,0.2)',
                  padding: '2px 6px',
                  borderRadius: '4px'
                }}>
                  👤 {currentEmployee.name}
                </span>
                <button
                  onClick={logoutEmployee}
                  style={{
                    backgroundColor: '#e74c3c',
                    color: 'white',
                    border: 'none',
                    padding: '6px 12px',
                    borderRadius: '4px',
                    cursor: 'pointer',
                    fontSize: '10px',
                    fontWeight: 'bold'
                  }}
                >
                  خروج
                </button>
              </div>
            ) : (
              // نموذج تسجيل دخول الموظف
              <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
                <input
                  type="text"
                  placeholder="اسم المستخدم"
                  value={employeeUsername}
                  onChange={(e) => setEmployeeUsername(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault()
                      const passwordInput = e.currentTarget.nextElementSibling as HTMLInputElement
                      passwordInput?.focus()
                    }
                  }}
                  style={{
                    padding: '6px 10px',
                    borderRadius: '4px',
                    border: 'none',
                    fontSize: '10px',
                    width: '120px',
                    textAlign: 'right'
                  }}
                />
                <input
                  type="password"
                  placeholder="كلمة المرور"
                  value={employeePassword}
                  onChange={(e) => setEmployeePassword(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault()
                      loginEmployee()
                    }
                  }}
                  style={{
                    padding: '6px 10px',
                    borderRadius: '4px',
                    border: 'none',
                    fontSize: '10px',
                    width: '120px',
                    textAlign: 'right'
                  }}
                />
                <button
                  onClick={loginEmployee}
                  disabled={employeeLoginLoading}
                  style={{
                    backgroundColor: employeeLoginLoading ? '#7f8c8d' : '#27ae60',
                    color: 'white',
                    border: 'none',
                    padding: '6px 12px',
                    borderRadius: '4px',
                    cursor: employeeLoginLoading ? 'default' : 'pointer',
                    fontSize: '10px',
                    fontWeight: 'bold',
                    minWidth: '60px'
                  }}
                >
                  {employeeLoginLoading ? '...' : 'دخول'}
                </button>
              </div>
            )}
          </div>
        </div>
        
        <div style={{ display: 'flex', gap: '15px' }}>
          <button
            onClick={() => setActiveTab('cashier')}
            className="tab-button"
            style={{
              padding: '8px 12px',
              backgroundColor: activeTab === 'cashier' ? '#4CAF50' : 'transparent',
              color: 'white',
              border: '1px solid white',
              borderRadius: '6px',
              cursor: 'pointer',
              fontSize: '18px',
              fontWeight: 'bold',
              minHeight: '35px',
              minWidth: '90px'
            }}
          >
            📊 الكاشيير
          </button>
          <button
            onClick={() => setActiveTab('orders')}
            className="tab-button"
            style={{
              padding: '8px 12px',
              backgroundColor: activeTab === 'orders' ? '#4CAF50' : 'transparent',
              color: 'white',
              border: '1px solid white',
              borderRadius: '6px',
              cursor: 'pointer',
              fontSize: '18px',
              fontWeight: 'bold',
              minHeight: '35px',
              minWidth: '90px'
            }}
          >
            📋 الأوامر
          </button>
          <button
            onClick={() => setActiveTab('reports')}
            className="tab-button"
            style={{
              padding: '8px 12px',
              backgroundColor: activeTab === 'reports' ? '#4CAF50' : 'transparent',
              color: 'white',
              border: '1px solid white',
              borderRadius: '6px',
              cursor: 'pointer',
              fontSize: '18px',
              fontWeight: 'bold',
              minHeight: '35px',
              minWidth: '90px'
            }}
          >
            📈 التقارير
          </button>
          <button
            onClick={() => setActiveTab('operations-settings')}
            className="tab-button"
            style={{
              padding: '8px 12px',
              backgroundColor: activeTab === 'operations-settings' ? '#4CAF50' : 'transparent',
              color: 'white',
              border: '1px solid white',
              borderRadius: '6px',
              cursor: 'pointer',
              fontSize: '18px',
              fontWeight: 'bold',
              minHeight: '50px',
              minWidth: '140px'
            }}
          >
            🔧 إعدادات العمليات
          </button>
          <button
            onClick={() => setActiveTab('customer-settings')}
            className="tab-button"
            style={{
              padding: '8px 12px',
              backgroundColor: activeTab === 'customer-settings' ? '#4CAF50' : 'transparent',
              color: 'white',
              border: '1px solid white',
              borderRadius: '6px',
              cursor: 'pointer',
              fontSize: '18px',
              fontWeight: 'bold',
              minHeight: '50px',
              minWidth: '140px'
            }}
          >
            👥 إعدادات العملاء
          </button>
          <button
            onClick={() => setActiveTab('employee-settings')}
            className="tab-button"
            style={{
              padding: '8px 12px',
              backgroundColor: activeTab === 'employee-settings' ? '#4CAF50' : 'transparent',
              color: 'white',
              border: '1px solid white',
              borderRadius: '6px',
              cursor: 'pointer',
              fontSize: '18px',
              fontWeight: 'bold',
              minHeight: '50px',
              minWidth: '140px'
            }}
          >
            👨‍💼 إعدادات الموظفين
          </button>
          {isLicenseManager && (
            <>
              <button
                onClick={() => setActiveTab('license-manager')}
                style={{
                  padding: '2px 6px',
                  backgroundColor: activeTab === 'license-manager' ? '#4CAF50' : 'transparent',
                  color: 'white',
                  border: '2px solid #9b59b6',
                  borderRadius: '4px',
                  cursor: 'pointer'
                }}
              >
                🔑 تراخيص
              </button>
            </>
          )}
        </div>

        <div style={{ color: 'white', fontSize: '7px', whiteSpace: 'nowrap' }}>
          {new Date().toLocaleDateString('ar-LB', { day: '2-digit', month: '2-digit' })}{new Date().toLocaleTimeString('ar-LB', { hour: '2-digit', minute: '2-digit' })}
        </div>
      </div>

      {/* الشريط الثاني */}
      <div style={{
        backgroundColor: '#4a7bc8',
        padding: '4px 10px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
        minHeight: '120px'
      }}>
        <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
          {isAdmin && (
            <span style={{ 
              color: '#e74c3c', 
              fontWeight: 'bold', 
              fontSize: '18px',
              padding: '8px 12px',
              marginLeft: '10px',
              minHeight: '35px',
              minWidth: '90px',
              display: 'inline-flex',
              alignItems: 'center',
              justifyContent: 'center'
            }}>⚙️ مدير</span>
          )}
          {isLicenseManager && (
            <span style={{ 
              color: '#e74c3c', 
              fontWeight: 'bold', 
              fontSize: '18px', 
              marginLeft: '6px', 
              backgroundColor: 'rgba(231,76,60,0.2)', 
              padding: '8px 12px', 
              borderRadius: '3px',
              minHeight: '50px',
              minWidth: '140px',
              display: 'inline-flex',
              alignItems: 'center',
              justifyContent: 'center'
            }}>🔑 مدير تراخيص</span>
          )}
          <div style={{ 
            color: checkLicenseValidity() ? '#27ae60' : '#e74c3c',
            fontWeight: 'bold', 
            fontSize: '18px',
            backgroundColor: 'rgba(255,255,255,0.2)',
            padding: '8px 12px',
            borderRadius: '4px',
            marginLeft: '10px',
            minHeight: '50px',
            minWidth: '140px',
            display: 'inline-flex',
            alignItems: 'center',
            justifyContent: 'center'
          }}>
            {checkLicenseValidity() ? '✅ مفعل' : '⚠️ غير مفعل'}
          </div>
          
          {/* العناصر المنقولة من الشريط العلوي */}
          {isAdmin && (
            <>
              <button
                onClick={logoutAdmin}
                style={{
                  backgroundColor: '#e74c3c',
                  color: 'white',
                  border: 'none',
                  padding: '8px 12px',
                  borderRadius: '6px',
                  cursor: 'pointer',
                  fontSize: '18px',
                  fontWeight: 'bold',
                  minHeight: '35px',
                  minWidth: '90px'
                }}
              >
                🚪 خروج مدير
              </button>
              <button
                onClick={() => setActiveTab('admin')}
                style={{
                  padding: '8px 12px',
                  backgroundColor: activeTab === 'admin' ? '#4CAF50' : 'transparent',
                  color: 'white',
                  border: '2px solid #e74c3c',
                  borderRadius: '4px',
                  cursor: 'pointer',
                  fontSize: '18px',
                  fontWeight: 'bold',
                  minHeight: '35px',
                  minWidth: '90px'
                }}
              >
                ⚙️ الإدارة
              </button>
            </>
          )}
          {isLicenseManager && (
            <button
              onClick={logoutLicenseManager}
              style={{
                backgroundColor: '#c0392b',
                color: 'white',
                border: 'none',
                padding: '8px 12px',
                borderRadius: '6px',
                cursor: 'pointer',
                fontSize: '18px',
                fontWeight: 'bold',
                minHeight: '35px',
                minWidth: '90px'
              }}
            >
              🚪 خروج مدير تراخيص
            </button>
          )}
        </div>
        <div style={{ 
          color: 'white', 
          fontSize: '18px', 
          fontWeight: 'bold',
          padding: '8px 12px',
          minHeight: '50px',
          minWidth: '140px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center'
        }}>
          معلومات إضافية
        </div>
      </div>

      {/* المحتوى الرئيسي */}
      <div style={{ padding: '10px' }}>
        {activeTab === 'cashier' && (
          <div style={{ display: 'flex', gap: '10px', height: 'calc(100vh - 140px)', maxHeight: 'calc(100vh - 140px)', overflow: 'hidden' }}>
            {/* الجانب الأيمن - إدخال المنتجات */}
            <div style={{
              flex: '1',
              backgroundColor: '#4a90e2',
              borderRadius: '4px',
              padding: '12px',
              color: 'white',
              overflowY: 'auto'
            }}>
              <h2 style={{ margin: '0 0 20px 0', color: 'white', textAlign: 'center' }}>
                🛍️ إضافة المنتجات
              </h2>

              {/* حقل البحث الموحد */}
              <div style={{ marginBottom: '20px' }}>
                <label style={{ display: 'block', marginBottom: '10px', fontWeight: 'bold', textAlign: 'center' }}>
                  ادخل الباركود أو اسم المنتج:
                </label>
                {isEmployeeLoggedIn ? (
                  <input 
                    ref={barcodeInputRef}
                    type="text"
                    value={barcode}
                    onChange={(e) => setBarcode(e.target.value)}
                    style={{
                      width: '100%',
                      padding: '15px',
                      fontSize: '18px',
                      border: '3px solid #fff',
                      borderRadius: '4px',
                      textAlign: 'center',
                      fontWeight: 'bold'
                    }}
                    placeholder="مسح الباركود أو كتابة اسم المنتج"
                    onKeyPress={(e) => e.key === 'Enter' && addToCart()}
                    autoFocus
                  />
                ) : (
                  <div style={{
                    width: '100%',
                    padding: '15px',
                    fontSize: '16px',
                    border: '3px dashed rgba(255,255,255,0.5)',
                    borderRadius: '4px',
                    textAlign: 'center',
                    fontWeight: 'bold',
                    backgroundColor: 'rgba(255,255,255,0.1)',
                    color: 'rgba(255,255,255,0.7)'
                  }}>
                    🔒 يجب تسجيل دخول موظف أولاً لاستخدام الكاشيير
                  </div>
                )}
              </div>

              {/* المنتجات السريعة */}
              <div style={{ marginTop: '20px' }}>
                <h3 style={{ color: 'white', marginBottom: '10px' }}>المنتجات السريعة:</h3>
                {isEmployeeLoggedIn ? (
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '8px' }}>
                    {products.slice(0, 6).map((product: any) => (
                      <button
                        key={product.barcode}
                        onClick={() => addProductToCart(product.name, product.price, 1, product.barcode)}
                        style={{
                          padding: '10px',
                          fontSize: '10px',
                          backgroundColor: 'rgba(255,255,255,0.2)',
                          color: 'white',
                          border: '1px solid white',
                          borderRadius: '4px',
                          cursor: 'pointer'
                        }}
                      >
                        {product.name}<br/>{formatPrice(product.price)}
                      </button>
                    ))}
                  </div>
                ) : (
                  <div style={{
                    display: 'grid',
                    gridTemplateColumns: 'repeat(2, 1fr)',
                    gap: '8px'
                  }}>
                    {Array.from({ length: 6 }).map((_, index) => (
                      <div
                        key={index}
                        style={{
                          padding: '10px',
                          fontSize: '10px',
                          backgroundColor: 'rgba(255,255,255,0.1)',
                          color: 'rgba(255,255,255,0.5)',
                          border: '1px dashed rgba(255,255,255,0.5)',
                          borderRadius: '4px',
                          textAlign: 'center',
                          cursor: 'not-allowed'
                        }}
                      >
                        {index === 2 ? '🔒 يجب تسجيل\nدخول موظف' : '---'}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* الجانب الأيسر - الفاتورة */}
            <div style={{
              flex: '2',
              backgroundColor: 'white',
              borderRadius: '4px',
              padding: '12px',
              display: 'flex',
              flexDirection: 'column',
              overflowY: 'auto'
            }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
                <h2 style={{ color: '#2c5aa0', margin: 0 }}>📄 فاتورة البيع</h2>
                <div style={{ display: 'flex', gap: '10px' }}>
                  <button 
                    onClick={saveOrder}
                    style={{
                      padding: '10px 20px',
                      backgroundColor: '#f39c12',
                      color: 'white',
                      border: 'none',
                      borderRadius: '4px',
                      cursor: 'pointer',
                      fontWeight: 'bold'
                    }}
                  >
                    💾 حفظ كطلب
                  </button>
                </div>
              </div>

              {/* جدول المنتجات */}
              <div style={{ 
                flex: 1, 
                border: '2px solid #2c5aa0', 
                borderRadius: '6px',
                overflow: 'hidden'
              }}>
                {/* رأس الجدول */}
                <div style={{
                  backgroundColor: '#2c5aa0',
                  color: 'white',
                  padding: '10px',
                  display: 'grid',
                  gridTemplateColumns: '3fr 1fr 1fr 1fr 1fr 80px',
                  gap: '10px',
                  fontWeight: 'bold',
                  fontSize: '14px'
                }}>
                  <div>اسم المنتج</div>
                  <div style={{ textAlign: 'center' }}>السعر</div>
                  <div style={{ textAlign: 'center' }}>الكمية</div>
                  <div style={{ textAlign: 'center' }}>المجموع</div>
                  <div style={{ textAlign: 'center' }}>الباركود</div>
                  <div style={{ textAlign: 'center' }}>حذف</div>
                </div>

                {/* محتوى الجدول */}
                <div style={{ 
                  maxHeight: '400px', 
                  overflowY: 'auto',
                  backgroundColor: 'white'
                }}>
                  {cart.length === 0 ? (
                    <div style={{ 
                      padding: '40px', 
                      textAlign: 'center', 
                      color: '#666',
                      fontSize: '18px'
                    }}>
                      لا توجد منتجات في السلة
                    </div>
                  ) : (
                    cart.map(item => (
                      <div 
                        key={item.id} 
                        style={{
                          display: 'grid',
                          gridTemplateColumns: '3fr 1fr 1fr 1fr 1fr 80px',
                          gap: '10px',
                          padding: '12px 10px',
                          borderBottom: '1px solid #eee',
                          alignItems: 'center',
                          fontSize: '14px'
                        }}
                      >
                        <div style={{ fontWeight: 'bold' }}>{item.name}</div>
                        <div style={{ textAlign: 'center' }}>
                          <input 
                            type="number"
                            defaultValue={item.price}
                            onBlur={(e) => {
                              const newPrice = parseFloat(e.target.value)
                              if (!isNaN(newPrice) && newPrice > 0) {
                                updatePrice(item.id, newPrice)
                              } else {
                                e.target.value = item.price.toString()
                              }
                            }}
                            onKeyPress={(e) => {
                              if (e.key === 'Enter') {
                                const newPrice = parseFloat((e.target as HTMLInputElement).value)
                                if (!isNaN(newPrice) && newPrice > 0) {
                                  updatePrice(item.id, newPrice)
                                } else {
                                  (e.target as HTMLInputElement).value = item.price.toString()
                                }
                              }
                            }}
                            style={{
                              width: '80px',
                              padding: '4px',
                              textAlign: 'center',
                              border: '1px solid #ddd',
                              borderRadius: '4px',
                              fontSize: '12px'
                            }}
                          />
                        </div>
                        <div style={{ textAlign: 'center', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '5px' }}>
                          <button 
                            onClick={() => updateQuantity(item.id, item.quantity - 1)}
                            style={{
                              backgroundColor: '#e74c3c',
                              color: 'white',
                              border: 'none',
                              width: '25px',
                              height: '25px',
                              borderRadius: '50%',
                              cursor: 'pointer',
                              fontSize: '12px'
                            }}
                          >
                            -
                          </button>
                          <span style={{ minWidth: '30px', textAlign: 'center', fontWeight: 'bold' }}>
                            {item.quantity}
                          </span>
                          <button 
                            onClick={() => updateQuantity(item.id, item.quantity + 1)}
                            style={{
                              backgroundColor: '#27ae60',
                              color: 'white',
                              border: 'none',
                              width: '25px',
                              height: '25px',
                              borderRadius: '50%',
                              cursor: 'pointer',
                              fontSize: '12px'
                            }}
                          >
                            +
                          </button>
                        </div>
                        <div style={{ textAlign: 'center', fontWeight: 'bold', color: '#2c5aa0' }}>
                          {formatPrice(item.total)}
                        </div>
                        <div style={{ textAlign: 'center', fontSize: '12px', color: '#666' }}>
                          {item.barcode || '-'}
                        </div>
                        <div style={{ textAlign: 'center' }}>
                          <button 
                            onClick={() => removeFromCart(item.id)}
                            style={{
                              backgroundColor: '#e74c3c',
                              color: 'white',
                              border: 'none',
                              padding: '5px 8px',
                              borderRadius: '4px',
                              cursor: 'pointer',
                              fontSize: '12px'
                            }}
                          >
                            🗑️
                          </button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>

              {/* المجموع النهائي */}
              <div style={{
                marginTop: '20px',
                backgroundColor: '#2c5aa0',
                color: 'white',
                padding: '12px',
                borderRadius: '6px',
                textAlign: 'center'
              }}>
                <div style={{ fontSize: '24px', fontWeight: 'bold', marginBottom: '15px' }}>
                  المجموع الكلي: {formatPrice(getTotalPrice())}
                </div>
                <div style={{ display: 'flex', gap: '15px', justifyContent: 'center' }}>
                  <div style={{ position: 'relative' }}>
                    <button 
                      onClick={() => {
                        if (cart.length === 0) {
                          alert('لا توجد منتجات في السلة')
                          return
                        }
                        setPaymentType('cash')
                        setShowPaymentModal(true)
                        setAmountPaid('')
                      }}
                      disabled={cart.length === 0}
                      style={{
                        backgroundColor: cart.length === 0 ? '#95a5a6' : '#27ae60',
                        color: 'white',
                        border: 'none',
                        padding: '8px 12px',
                        fontSize: '16px',
                        borderRadius: '6px',
                        cursor: cart.length === 0 ? 'not-allowed' : 'pointer',
                        fontWeight: 'bold'
                      }}
                    >
                      💵 دفع نقدي
                    </button>
                    <div style={{
                      fontSize: '10px',
                      color: '#666',
                      textAlign: 'center',
                      marginTop: '2px',
                      opacity: cart.length === 0 ? 0.5 : 1
                    }}>
                      (F3)
                    </div>
                  </div>
                  <button 
                    onClick={() => {
                      if (cart.length === 0) {
                        alert('لا توجد منتجات في السلة')
                        return
                      }
                      setPaymentType('card')
                      setShowPaymentModal(true)
                      setAmountPaid('')
                    }}
                    disabled={cart.length === 0}
                    style={{
                      backgroundColor: cart.length === 0 ? '#95a5a6' : '#3498db',
                      color: 'white',
                      border: 'none',
                      padding: '8px 12px',
                      fontSize: '16px',
                      borderRadius: '6px',
                      cursor: cart.length === 0 ? 'not-allowed' : 'pointer',
                      fontWeight: 'bold'
                    }}
                  >
                    💳 دفع بالبطاقة
                  </button>
                  <button 
                    onClick={() => printReceipt()}
                    disabled={cart.length === 0}
                    style={{
                      backgroundColor: cart.length === 0 ? '#95a5a6' : '#9b59b6',
                      color: 'white',
                      border: 'none',
                      padding: '8px 12px',
                      fontSize: '16px',
                      borderRadius: '6px',
                      cursor: cart.length === 0 ? 'not-allowed' : 'pointer',
                      fontWeight: 'bold'
                    }}
                  >
                    🖨️ طباعة
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'orders' && (
          <div style={{
            backgroundColor: 'white',
            borderRadius: '4px',
            padding: '12px',
            maxHeight: 'calc(100vh - 150px)',
            overflowY: 'auto'
          }}>
            <h2 style={{ color: '#2c5aa0', marginBottom: '10px', fontSize: '18px' }}>📋 إدارة الأوامر</h2>
            
            <div style={{ 
              border: '2px solid #2c5aa0', 
              borderRadius: '6px',
              overflow: 'hidden'
            }}>
              <div style={{
                backgroundColor: '#2c5aa0',
                color: 'white',
                padding: '10px',
                display: 'grid',
                gridTemplateColumns: '1fr 1fr 1fr 1fr 1.5fr 2fr',
                gap: '10px',
                fontWeight: 'bold'
              }}>
                <div>رقم الطلب</div>
                <div>التاريخ</div>
                <div>المجموع</div>
                <div>الحالة</div>
                <div>الموظف</div>
                <div>العمليات</div>
              </div>
              
              {orders.length === 0 ? (
                <div style={{ padding: '40px', textAlign: 'center', color: '#666' }}>
                  لا توجد أوامر محفوظة
                </div>
              ) : (
                orders.map(order => (
                  <div 
                    key={order.id}
                    style={{
                      display: 'grid',
                      gridTemplateColumns: '1fr 1fr 1fr 1fr 1.5fr 2fr',
                      gap: '10px',
                      padding: '15px 10px',
                      borderBottom: '1px solid #eee',
                      alignItems: 'center'
                    }}
                  >
                    <div style={{ fontWeight: 'bold' }}>{order.id}</div>
                    <div>{order.date}</div>
                    <div>{formatPrice(order.total)}</div>
                    <div>
                      <span style={{
                        padding: '2px 6px',
                        borderRadius: '4px',
                        fontSize: '10px',
                        backgroundColor: 
                          order.status === 'completed' ? '#27ae60' :
                          order.status === 'cancelled' ? '#e74c3c' : '#f39c12',
                        color: 'white'
                      }}>
                        {order.status === 'completed' ? 'مكتمل' :
                         order.status === 'cancelled' ? 'ملغي' : 'معلق'}
                      </span>
                    </div>
                    <div style={{ 
                      fontSize: '12px',
                      color: '#2c5aa0',
                      fontWeight: 'bold'
                    }}>
                      👤 {(order as any).employeeName || 'غير محدد'}
                    </div>
                    <div style={{ display: 'flex', gap: '5px' }}>
                      <button
                        onClick={() => loadOrder(order.id)}
                        style={{
                          padding: '5px 10px',
                          backgroundColor: '#3498db',
                          color: 'white',
                          border: 'none',
                          borderRadius: '4px',
                          cursor: 'pointer',
                          fontSize: '12px'
                        }}
                      >
                        تحميل
                      </button>
                      {order.status === 'pending' && (
                        <>
                          <button
                            onClick={() => completeOrder(order.id)}
                            style={{
                              padding: '5px 10px',
                              backgroundColor: '#27ae60',
                              color: 'white',
                              border: 'none',
                              borderRadius: '4px',
                              cursor: 'pointer',
                              fontSize: '12px'
                            }}
                          >
                            إكمال
                          </button>
                          <button
                            onClick={() => cancelOrder(order.id)}
                            style={{
                              padding: '5px 10px',
                              backgroundColor: '#e74c3c',
                              color: 'white',
                              border: 'none',
                              borderRadius: '4px',
                              cursor: 'pointer',
                              fontSize: '12px'
                            }}
                          >
                            إلغاء
                          </button>
                        </>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {activeTab === 'reports' && (
          <div style={{
            backgroundColor: 'white',
            borderRadius: '4px',
            padding: '12px',
            maxHeight: 'calc(100vh - 150px)',
            overflowY: 'auto'
          }}>
            <h2 style={{ color: '#2c5aa0', marginBottom: '10px', fontSize: '18px' }}>📈 التقارير والإحصائيات</h2>
            
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '10px', marginBottom: '15px' }}>
              <div style={{
                backgroundColor: '#27ae60',
                color: 'white',
                padding: '12px',
                borderRadius: '6px',
                textAlign: 'center'
              }}>
                <div style={{ fontSize: '24px', fontWeight: 'bold' }}>
                  {orders.filter(o => o.status === 'completed').length}
                </div>
                <div>الأوامر المكتملة</div>
              </div>
              
              <div style={{
                backgroundColor: '#f39c12',
                color: 'white',
                padding: '12px',
                borderRadius: '6px',
                textAlign: 'center'
              }}>
                <div style={{ fontSize: '24px', fontWeight: 'bold' }}>
                  {orders.filter(o => o.status === 'pending').length}
                </div>
                <div>الأوامر المعلقة</div>
              </div>
              
              <div style={{
                backgroundColor: '#e74c3c',
                color: 'white',
                padding: '12px',
                borderRadius: '6px',
                textAlign: 'center'
              }}>
                <div style={{ fontSize: '24px', fontWeight: 'bold' }}>
                  {orders.filter(o => o.status === 'cancelled').length}
                </div>
                <div>الأوامر الملغاة</div>
              </div>
              
              <div style={{
                backgroundColor: '#3498db',
                color: 'white',
                padding: '12px',
                borderRadius: '6px',
                textAlign: 'center'
              }}>
                <div style={{ fontSize: '20px', fontWeight: 'bold' }}>
                  {formatPrice(orders.filter(o => o.status === 'completed').reduce((total, order) => total + order.total, 0))}
                </div>
                <div>إجمالي المبيعات ({currencies[storeSettings.currency as keyof typeof currencies]?.symbol || 'ل.ل'})</div>
              </div>
            </div>
            
            <div style={{
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              gap: '10px',
              marginBottom: '20px'
            }}>
              <div style={{
                backgroundColor: '#f8f9fa',
                padding: '12px',
                borderRadius: '6px',
                border: '1px solid #ddd'
              }}>
                <h3 style={{ color: '#2c5aa0', marginBottom: '15px' }}>المبيعات اليومية</h3>
                <div style={{ fontSize: '18px', fontWeight: 'bold' }}>
                  {formatPrice(orders.filter(o => 
                    o.status === 'completed' && 
                    o.date === new Date().toLocaleDateString('ar-LB')
                  ).reduce((total, order) => total + order.total, 0))}
                </div>
                <div style={{ color: '#666', fontSize: '14px' }}>
                  {orders.filter(o => 
                    o.status === 'completed' && 
                    o.date === new Date().toLocaleDateString('ar-LB')
                  ).length} فاتورة اليوم
                </div>
              </div>
              
              <div style={{
                backgroundColor: '#f8f9fa',
                padding: '12px',
                borderRadius: '6px',
                border: '1px solid #ddd'
              }}>
                <h3 style={{ color: '#2c5aa0', marginBottom: '15px' }}>متوسط قيمة الفاتورة</h3>
                <div style={{ fontSize: '18px', fontWeight: 'bold' }}>
                  {orders.filter(o => o.status === 'completed').length > 0 ? formatPrice(
                    orders.filter(o => o.status === 'completed').reduce((total, order) => total + order.total, 0) / 
                    orders.filter(o => o.status === 'completed').length
                  ) : formatPrice(0)}
                </div>
                <div style={{ color: '#666', fontSize: '14px' }}>
                  من مجموع {orders.filter(o => o.status === 'completed').length} فاتورة
                </div>
              </div>
            </div>
          </div>
        )}
        
        {/* نافذة الدفع */}
        {showPaymentModal && (
          <div style={{
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: 'rgba(0,0,0,0.5)',
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            zIndex: 1000
          }}>
            <div style={{
              backgroundColor: 'white',
              padding: '30px',
              borderRadius: '12px',
              boxShadow: '0 10px 30px rgba(0,0,0,0.3)',
              maxWidth: '500px',
              width: '90%',
              textAlign: 'center'
            }}>
              <h2 style={{ color: '#2c5aa0', marginBottom: '20px' }}>
                {paymentType === 'cash' ? '💵 دفع نقدي' : '💳 دفع بالبطاقة'}
              </h2>
              
              <div style={{ 
                backgroundColor: '#f8f9fa', 
                padding: '12px', 
                borderRadius: '4px', 
                marginBottom: '20px' 
              }}>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px', fontSize: '16px' }}>
                  <div>
                    <strong>العميل:</strong> {customerName || 'عميل'}
                  </div>
                  <div>
                    <strong>عدد الأصناف:</strong> {cart.reduce((total, item) => total + item.quantity, 0)}
                  </div>
                </div>
                <div style={{ marginTop: '15px', fontSize: '20px', fontWeight: 'bold', color: '#2c5aa0' }}>
                  المجموع المطلوب: {formatPrice(getTotalPrice())}
                </div>
              </div>

              {paymentType === 'cash' && (
                <div style={{ marginBottom: '20px' }}>
                  <label style={{ display: 'block', marginBottom: '8px', fontWeight: 'bold', fontSize: '16px' }}>
                    المبلغ المدفوع:
                  </label>
                  <input 
                    type="number"
                    value={amountPaid}
                    onChange={(e) => setAmountPaid(e.target.value)}
                    placeholder="ادخل المبلغ المدفوع"
                    style={{
                      width: '100%',
                      padding: '15px',
                      fontSize: '18px',
                      border: `2px solid ${amountPaid && parseFloat(amountPaid) < getTotalPrice() ? '#e74c3c' : '#ddd'}`,
                      borderRadius: '6px',
                      textAlign: 'center',
                      backgroundColor: amountPaid && parseFloat(amountPaid) < getTotalPrice() ? '#ffeaa7' : 'white'
                    }}
                    autoFocus
                  />
                  
                  {/* عرض حالة الدفع والباقي */}
                  {amountPaid && (
                    <div style={{ marginTop: '15px' }}>
                      <div style={{
                        display: 'grid',
                        gridTemplateColumns: '1fr 1fr',
                        gap: '15px',
                        marginBottom: '10px'
                      }}>
                        <div style={{
                          padding: '10px',
                          borderRadius: '6px',
                          backgroundColor: '#e8f4f8',
                          textAlign: 'center'
                        }}>
                          <div style={{ fontSize: '14px', color: '#666', marginBottom: '5px' }}>المطلوب</div>
                          <div style={{ fontWeight: 'bold', fontSize: '16px', color: '#2c5aa0' }}>
                            {formatPrice(getTotalPrice())}
                          </div>
                        </div>
                        <div style={{
                          padding: '10px',
                          borderRadius: '6px',
                          backgroundColor: parseFloat(amountPaid) >= getTotalPrice() ? '#d4edda' : '#f8d7da',
                          textAlign: 'center'
                        }}>
                          <div style={{ fontSize: '14px', color: '#666', marginBottom: '5px' }}>المدفوع</div>
                          <div style={{ fontWeight: 'bold', fontSize: '16px', 
                            color: parseFloat(amountPaid) >= getTotalPrice() ? '#27ae60' : '#e74c3c' }}>
                            {formatPrice(parseFloat(amountPaid))}
                          </div>
                        </div>
                      </div>
                      
                      {/* عرض الباقي أو النقص */}
                      {parseFloat(amountPaid) > getTotalPrice() ? (
                        <div style={{ 
                          color: 'white', 
                          fontWeight: 'bold',
                          fontSize: '18px',
                          backgroundColor: '#27ae60',
                          padding: '15px',
                          borderRadius: '4px',
                          textAlign: 'center',
                          border: '2px solid #219a52'
                        }}>
                          💰 الباقي للزبون: {formatPrice(parseFloat(amountPaid) - getTotalPrice())}
                        </div>
                      ) : parseFloat(amountPaid) < getTotalPrice() ? (
                        <div style={{ 
                          color: 'white', 
                          fontWeight: 'bold',
                          fontSize: '18px',
                          backgroundColor: '#e74c3c',
                          padding: '15px',
                          borderRadius: '4px',
                          textAlign: 'center',
                          border: '2px solid #c0392b'
                        }}>
                          ⚠️ مطلوب إضافة: {formatPrice(getTotalPrice() - parseFloat(amountPaid))}
                        </div>
                      ) : (
                        <div style={{ 
                          color: 'white', 
                          fontWeight: 'bold',
                          fontSize: '18px',
                          backgroundColor: '#3498db',
                          padding: '15px',
                          borderRadius: '4px',
                          textAlign: 'center',
                          border: '2px solid #2980b9'
                        }}>
                          ✅ المبلغ مضبوط بالتمام
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )}

              {paymentType === 'card' && (
                <div style={{ 
                  marginBottom: '20px', 
                  padding: '12px', 
                  backgroundColor: '#e8f4f8', 
                  borderRadius: '4px' 
                }}>
                  <p style={{ margin: '0 0 15px 0', fontSize: '16px' }}>
                    يرجى تمرير البطاقة أو إدخالها في جهاز نقاط البيع
                  </p>
                  <div style={{ margin: '15px 0' }}>
                    <div style={{ 
                      display: 'inline-block', 
                      padding: '2px 6px', 
                      backgroundColor: '#3498db', 
                      color: 'white', 
                      borderRadius: '20px',
                      fontSize: '14px'
                    }}>
                      جاري المعالجة...
                    </div>
                  </div>
                </div>
              )}

              <div style={{ display: 'flex', gap: '15px', justifyContent: 'center' }}>
                <div style={{ position: 'relative', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                  <button 
                    onClick={processPayment}
                    disabled={
                      !paymentType || 
                      (paymentType === 'cash' && (!amountPaid || parseFloat(amountPaid) < getTotalPrice()))
                    }
                    style={{
                      backgroundColor: !paymentType || 
                        (paymentType === 'cash' && (!amountPaid || parseFloat(amountPaid) < getTotalPrice()))
                        ? '#95a5a6' : '#27ae60',
                      color: 'white',
                      border: 'none',
                      padding: '8px 12px',
                      fontSize: '16px',
                      borderRadius: '6px',
                      cursor: !paymentType || 
                        (paymentType === 'cash' && (!amountPaid || parseFloat(amountPaid) < getTotalPrice()))
                        ? 'not-allowed' : 'pointer',
                      fontWeight: 'bold'
                    }}
                  >
                    ✅ تأكيد الدفع
                  </button>
                  <div style={{
                    fontSize: '10px',
                    color: !paymentType || 
                      (paymentType === 'cash' && (!amountPaid || parseFloat(amountPaid) < getTotalPrice()))
                      ? '#bbb' : '#666',
                    textAlign: 'center',
                    marginTop: '2px',
                    opacity: !paymentType || 
                      (paymentType === 'cash' && (!amountPaid || parseFloat(amountPaid) < getTotalPrice()))
                      ? 0.5 : 1
                  }}>
                    (Enter)
                  </div>
                </div>
                <button 
                  onClick={() => {
                    setShowPaymentModal(false)
                    setAmountPaid('')
                    setPaymentType(null)
                  }}
                  style={{
                    backgroundColor: '#e74c3c',
                    color: 'white',
                    border: 'none',
                    padding: '8px 12px',
                    fontSize: '16px',
                    borderRadius: '6px',
                    cursor: 'pointer',
                    fontWeight: 'bold'
                  }}
                >
                  ❌ إلغاء
                </button>
              </div>
            </div>
          </div>
        )}
        
        {/* صفحة الإدارة */}
        {activeTab === 'admin' && isAdmin && (
          <div style={{
            backgroundColor: 'white',
            borderRadius: '4px',
            padding: '12px'
          }}>
            <h2 style={{ color: '#2c5aa0', marginBottom: '20px' }}>⚙️ لوحة الإدارة</h2>
            
            {/* خانة تفعيل النظام - بارزة إذا لم يكن مفعلاً */}
            {(!storeSettings.isActivated || !checkLicenseValidity()) && (
              <div style={{
                backgroundColor: '#fff3cd',
                border: '2px solid #ffc107',
                borderRadius: '10px',
                padding: '12px',
                marginBottom: '25px',
                textAlign: 'center'
              }}>
                <h3 style={{ 
                  color: '#856404', 
                  marginBottom: '15px',
                  fontSize: '20px',
                  fontWeight: 'bold'
                }}>
                  🔑 تفعيل النظام مطلوب
                </h3>
                
                <p style={{ 
                  color: '#856404', 
                  marginBottom: '20px',
                  fontSize: '16px'
                }}>
                  يرجى إدخال كود التفعيل السنوي لتفعيل جميع ميزات النظام
                </p>
                
                <div style={{ 
                  display: 'flex', 
                  gap: '15px', 
                  justifyContent: 'center',
                  alignItems: 'center',
                  flexWrap: 'wrap'
                }}>
                  <input 
                    type="text"
                    value={newLicenseKey}
                    onChange={(e) => setNewLicenseKey(e.target.value)}
                    style={{
                      padding: '12px 15px',
                      border: '2px solid #ffc107',
                      borderRadius: '6px',
                      fontSize: '16px',
                      minWidth: '300px',
                      textAlign: 'center',
                      fontWeight: 'bold'
                    }}
                    placeholder="أدخل كود التفعيل السنوي هنا"
                  />
                  <button
                    onClick={activateLicense}
                    style={{
                      backgroundColor: '#28a745',
                      color: 'white',
                      border: 'none',
                      padding: '12px 25px',
                      borderRadius: '6px',
                      cursor: 'pointer',
                      fontWeight: 'bold',
                      fontSize: '16px',
                      boxShadow: '0 2px 4px rgba(0,0,0,0.2)'
                    }}
                  >
                    🚀 تفعيل النظام
                  </button>
                </div>
                
                <div style={{ 
                  marginTop: '15px', 
                  fontSize: '10px', 
                  color: '#856404',
                  fontStyle: 'italic'
                }}>
                  الكود متوفر من نظام إدارة التراخيص الخاص بالشركة
                </div>
              </div>
            )}
            
            {/* إعدادات المتجر والتفعيل */}
            <div style={{
              backgroundColor: '#f8f9fa',
              padding: '12px',
              borderRadius: '4px',
              marginBottom: '20px',
              border: '1px solid #ddd'
            }}>
              <h3 style={{ color: '#2c5aa0', marginBottom: '15px' }}>🏪 إعدادات المتجر والتفعيل</h3>
              
              {/* معلومات حالة التفعيل */}
              <div style={{
                backgroundColor: storeSettings.isActivated && checkLicenseValidity() ? '#d4edda' : '#f8d7da',
                color: storeSettings.isActivated && checkLicenseValidity() ? '#155724' : '#721c24',
                padding: '15px',
                borderRadius: '6px',
                marginBottom: '20px',
                border: '1px solid ' + (storeSettings.isActivated && checkLicenseValidity() ? '#c3e6cb' : '#f5c6cb')
              }}>
                <div style={{ fontWeight: 'bold', fontSize: '16px', marginBottom: '10px', textAlign: 'center' }}>
                  {storeSettings.isActivated && checkLicenseValidity() ? '✅ النظام مفعل' : '⚠️ النظام غير مفعل'}
                </div>
                
                {storeSettings.isActivated && storeSettings.licenseInfo && (
                  <div style={{ 
                    display: 'grid', 
                    gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', 
                    gap: '8px',
                    fontSize: '10px',
                    marginTop: '10px'
                  }}>
                    {storeSettings.licenseInfo.customerName && (
                      <div>
                        <strong>🏢 العميل:</strong> {storeSettings.licenseInfo.customerName}
                      </div>
                    )}
                    {storeSettings.licenseInfo.contactPerson && (
                      <div>
                        <strong>👤 المسؤول:</strong> {storeSettings.licenseInfo.contactPerson}
                      </div>
                    )}
                    {storeSettings.licenseInfo.licenseType && (
                      <div>
                        <strong>📝 نوع الترخيص:</strong> {storeSettings.licenseInfo.licenseType}
                      </div>
                    )}
                    <div>
                      <strong>📅 تاريخ الانتهاء:</strong> {storeSettings.licenseExpiry ? new Date(storeSettings.licenseExpiry).toLocaleDateString('ar-LB') : 'غير محدد'}
                    </div>
                    {storeSettings.licenseInfo.remainingDays && (
                      <div>
                        <strong>⏰ المدة المتبقية:</strong> {storeSettings.licenseInfo.remainingDays} يوم
                      </div>
                    )}
                    {storeSettings.licenseInfo.activatedAt && (
                      <div>
                        <strong>🗓️ تم التفعيل في:</strong> {new Date(storeSettings.licenseInfo.activatedAt).toLocaleDateString('ar-LB')}
                      </div>
                    )}
                  </div>
                )}
                
                {(!storeSettings.isActivated || !checkLicenseValidity()) && (
                  <div style={{ textAlign: 'center', marginTop: '10px', fontSize: '14px' }}>
                    يرجى تفعيل النظام أو تجديد الترخيص أدناه
                  </div>
                )}
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' }}>
                {/* تغيير اسم المتجر */}
                <div>
                  <h4 style={{ color: '#2c5aa0', marginBottom: '10px' }}>اسم المتجر</h4>
                  <div style={{ marginBottom: '10px' }}>
                    <strong>الاسم الحالي:</strong> {storeSettings.storeName}
                  </div>
                  <div style={{ display: 'flex', gap: '10px' }}>
                    <input 
                      type="text"
                      value={newStoreName}
                      onChange={(e) => setNewStoreName(e.target.value)}
                      style={{
                        flex: 1,
                        padding: '10px',
                        border: '1px solid #ddd',
                        borderRadius: '4px'
                      }}
                      placeholder="أدخل اسم المتجر الجديد"
                    />
                    <button
                      onClick={updateStoreName}
                      style={{
                        backgroundColor: '#007bff',
                        color: 'white',
                        border: 'none',
                        padding: '10px 15px',
                        borderRadius: '4px',
                        cursor: 'pointer',
                        fontWeight: 'bold'
                      }}
                    >
                      تحديث
                    </button>
                  </div>
                </div>

              </div>
            </div>

            {/* إعدادات العملة */}
            <div style={{
              backgroundColor: '#f8f9fa',
              padding: '12px',
              borderRadius: '4px',
              marginBottom: '20px',
              border: '1px solid #ddd'
            }}>
              <h3 style={{ color: '#2c5aa0', marginBottom: '15px' }}>💰 إعدادات العملة</h3>
              
              <div style={{ marginBottom: '15px' }}>
                <div style={{ marginBottom: '10px', fontSize: '14px', color: '#666' }}>
                  العملة الحالية: <strong>{currencies[storeSettings.currency as keyof typeof currencies]?.name}</strong>
                </div>
                
                <div style={{ display: 'flex', alignItems: 'center', gap: '15px' }}>
                  <label style={{ fontWeight: 'bold', fontSize: '16px' }}>اختر العملة:</label>
                  <select
                    value={storeSettings.currency}
                    onChange={(e) => updateCurrency(e.target.value)}
                    style={{
                      padding: '8px 12px',
                      border: '1px solid #ddd',
                      borderRadius: '4px',
                      fontSize: '16px',
                      backgroundColor: 'white',
                      cursor: 'pointer',
                      minWidth: '200px'
                    }}
                  >
                    <option value="LBP">🇱🇧 الليرة اللبنانية (ل.ل)</option>
                    <option value="SYP">🇸🇾 الليرة السورية (ل.س)</option>
                    <option value="USD">🇺🇸 الدولار الأمريكي ($)</option>
                  </select>
                </div>
                
                <div style={{ marginTop: '10px', fontSize: '12px', color: '#666' }}>
                  ستؤثر هذه العملة على جميع الأسعار والمبالغ في النظام
                </div>
              </div>
            </div>

            {/* إدارة تسجيل دخول الإدارة */}
            <div style={{
              backgroundColor: '#f8f9fa',
              padding: '12px',
              borderRadius: '4px',
              marginBottom: '20px',
              border: '1px solid #ddd'
            }}>
              <h3 style={{ color: '#2c5aa0', marginBottom: '15px' }}>🔐 إعدادات تسجيل دخول الإدارة</h3>
              
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' }}>
                {/* تغيير اسم المستخدم */}
                <div>
                  <h4 style={{ color: '#2c5aa0', marginBottom: '10px' }}>اسم المستخدم</h4>
                  <div style={{ marginBottom: '10px' }}>
                    <strong>اسم المستخدم الحالي:</strong> {storeSettings.adminUsername}
                  </div>
                  <div style={{ display: 'flex', gap: '10px' }}>
                    <input 
                      type="text"
                      value={newAdminUsername}
                      onChange={(e) => setNewAdminUsername(e.target.value)}
                      style={{
                        flex: 1,
                        padding: '10px',
                        border: '1px solid #ddd',
                        borderRadius: '4px'
                      }}
                      placeholder="أدخل اسم المستخدم الجديد"
                    />
                    <button
                      onClick={updateAdminUsername}
                      style={{
                        backgroundColor: '#17a2b8',
                        color: 'white',
                        border: 'none',
                        padding: '10px 15px',
                        borderRadius: '4px',
                        cursor: 'pointer',
                        fontWeight: 'bold'
                      }}
                    >
                      تحديث
                    </button>
                  </div>
                </div>

                {/* تغيير كلمة المرور */}
                <div>
                  <h4 style={{ color: '#2c5aa0', marginBottom: '10px' }}>كلمة المرور</h4>
                  <div style={{ marginBottom: '10px', fontSize: '14px', color: '#666' }}>
                    أدخل كلمة مرور جديدة (6 أحرف على الأقل)
                  </div>
                  <div style={{ display: 'flex', gap: '10px' }}>
                    <input 
                      type="password"
                      value={newAdminPassword}
                      onChange={(e) => setNewAdminPassword(e.target.value)}
                      style={{
                        flex: 1,
                        padding: '10px',
                        border: '1px solid #ddd',
                        borderRadius: '4px'
                      }}
                      placeholder="أدخل كلمة المرور الجديدة"
                    />
                    <button
                      onClick={updateAdminPassword}
                      style={{
                        backgroundColor: '#dc3545',
                        color: 'white',
                        border: 'none',
                        padding: '10px 15px',
                        borderRadius: '4px',
                        cursor: 'pointer',
                        fontWeight: 'bold'
                      }}
                    >
                      تحديث
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* قسم مسح البيانات - منفصل للتأكيد على الخطورة */}
            <div style={{
              backgroundColor: '#fff3cd',
              padding: '12px',
              borderRadius: '4px',
              border: '2px solid #ffc107',
              marginTop: '20px'
            }}>
              <h3 style={{ color: '#dc3545', marginBottom: '15px', fontWeight: 'bold' }}>
                🗑️ مسح سجل المبيعات والعمليات
              </h3>
              <div style={{ 
                marginBottom: '15px', 
                fontSize: '14px', 
                color: '#856404',
                backgroundColor: '#fff3cd',
                padding: '10px',
                borderRadius: '4px',
                border: '1px solid #ffeaa7'
              }}>
                ⚠️ <strong>تحذير:</strong> هذا الإجراء سيقوم بحذف جميع البيانات التالية نهائياً:
                <ul style={{ margin: '10px 0', paddingRight: '20px' }}>
                  <li>جميع الطلبات والمبيعات المكتملة</li>
                  <li>جميع الإيصالات المطبوعة</li>
                  <li>جميع عمليات الإرجاع والاسترداد</li>
                  <li>سجل حركات المخزون</li>
                </ul>
                <strong>ملاحظة:</strong> المنتجات والإعدادات لن تتأثر.
              </div>
              
              <div style={{ display: 'flex', alignItems: 'center', gap: '15px' }}>
                <button
                  onClick={clearAllSalesData}
                  style={{
                    backgroundColor: '#dc3545',
                    color: 'white',
                    border: 'none',
                    padding: '12px 20px',
                    borderRadius: '6px',
                    cursor: 'pointer',
                    fontWeight: 'bold',
                    fontSize: '16px',
                    flex: 1,
                    transition: 'background-color 0.3s ease'
                  }}
                  onMouseEnter={(e) => e.target.style.backgroundColor = '#c82333'}
                  onMouseLeave={(e) => e.target.style.backgroundColor = '#dc3545'}
                >
                  🗑️ مسح جميع البيانات
                </button>
                
                <div style={{
                  fontSize: '10px',
                  color: '#dc3545',
                  fontWeight: 'bold',
                  textAlign: 'center',
                  padding: '8px',
                  backgroundColor: '#f8d7da',
                  borderRadius: '4px',
                  border: '1px solid #f5c6cb',
                  flex: 0.6
                }}>
                  إجراء لا يمكن<br/>التراجع عنه!
                </div>
              </div>
            </div>
            
            {/* قسم إدارة التراخيص التجارية */}
            <div style={{
              backgroundColor: '#f0f7ff',
              padding: '12px',
              borderRadius: '4px',
              border: '2px solid #9b59b6',
              marginTop: '20px'
            }}>
              <h3 style={{ color: '#2c5aa0', marginBottom: '20px', fontWeight: 'bold' }}>
                🔐 إدارة التراخيص التجارية
              </h3>
              
              {/* لوحة إدارة التراخيص الرئيسية */}
              <div>
                {/* شريط الإحصائيات العلوي */}
                <div style={{
                  display: 'grid',
                  gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))',
                  gap: '15px',
                  marginBottom: '20px'
                }}>
                  <div style={{
                    backgroundColor: '#3498db',
                    color: 'white',
                    padding: '12px',
                    borderRadius: '4px',
                    textAlign: 'center'
                  }}>
                    <h4 style={{ margin: '0 0 10px 0', fontSize: '16px' }}>إجمالي التراخيص</h4>
                    <div style={{ fontSize: '24px', fontWeight: 'bold' }}>
                      {licenseManagementData.stats?.totalLicenses || 0}
                    </div>
                  </div>
                  <div style={{
                    backgroundColor: '#27ae60',
                    color: 'white',
                    padding: '12px',
                    borderRadius: '4px',
                    textAlign: 'center'
                  }}>
                    <h4 style={{ margin: '0 0 10px 0', fontSize: '16px' }}>التراخيص النشطة</h4>
                    <div style={{ fontSize: '24px', fontWeight: 'bold' }}>
                      {licenseManagementData.stats?.activeLicenses || 0}
                    </div>
                  </div>
                  <div style={{
                    backgroundColor: '#e74c3c',
                    color: 'white',
                    padding: '12px',
                    borderRadius: '4px',
                    textAlign: 'center'
                  }}>
                    <h4 style={{ margin: '0 0 10px 0', fontSize: '16px' }}>التراخيص المنتهية</h4>
                    <div style={{ fontSize: '24px', fontWeight: 'bold' }}>
                      {licenseManagementData.stats?.expiredLicenses || 0}
                    </div>
                  </div>
                  <div style={{
                    backgroundColor: '#f39c12',
                    color: 'white',
                    padding: '12px',
                    borderRadius: '4px',
                    textAlign: 'center'
                  }}>
                    <h4 style={{ margin: '0 0 10px 0', fontSize: '16px' }}>إجمالي العملاء</h4>
                    <div style={{ fontSize: '24px', fontWeight: 'bold' }}>
                      {licenseManagementData.stats?.totalCustomers || 0}
                    </div>
                  </div>
                  <div style={{
                    backgroundColor: '#9b59b6',
                    color: 'white',
                    padding: '12px',
                    borderRadius: '4px',
                    textAlign: 'center'
                  }}>
                    <h4 style={{ margin: '0 0 10px 0', fontSize: '16px' }}>إجمالي الإيرادات</h4>
                    <div style={{ fontSize: '18px', fontWeight: 'bold' }}>
                      ${licenseManagementData.stats?.totalRevenue || 0}
                    </div>
                  </div>
                </div>

                {/* أزرار الإجراءات */}
                <div style={{
                  display: 'flex',
                  gap: '10px',
                  marginBottom: '20px',
                  flexWrap: 'wrap'
                }}>
                  <button
                    onClick={() => setShowCustomerForm(true)}
                    style={{
                      backgroundColor: '#3498db',
                      color: 'white',
                      border: 'none',
                      padding: '10px 20px',
                      borderRadius: '6px',
                      cursor: 'pointer',
                      fontWeight: 'bold'
                    }}
                  >
                    ➕ إضافة عميل جديد
                  </button>
                  <button
                    onClick={() => setShowLicenseForm(true)}
                    style={{
                      backgroundColor: '#27ae60',
                      color: 'white',
                      border: 'none',
                      padding: '10px 20px',
                      borderRadius: '6px',
                      cursor: 'pointer',
                      fontWeight: 'bold'
                    }}
                  >
                    🔐 إنتاج ترخيص جديد
                  </button>
                  <button
                    onClick={fetchLicenseData}
                    style={{
                      backgroundColor: '#f39c12',
                      color: 'white',
                      border: 'none',
                      padding: '10px 20px',
                      borderRadius: '6px',
                      cursor: 'pointer',
                      fontWeight: 'bold'
                    }}
                  >
                    🔄 تحديث البيانات
                  </button>
                  <button
                    onClick={logoutAdmin}
                    style={{
                      backgroundColor: '#e74c3c',
                      color: 'white',
                      border: 'none',
                      padding: '10px 20px',
                      borderRadius: '6px',
                      cursor: 'pointer',
                      fontWeight: 'bold',
                      marginLeft: 'auto'
                    }}
                  >
                    🚪 تسجيل الخروج
                  </button>
                </div>

                {/* ملخص بسيط للبيانات */}
                <div style={{ 
                  backgroundColor: 'white', 
                  padding: '15px', 
                  borderRadius: '6px',
                  border: '1px solid #ddd',
                  fontSize: '14px'
                }}>
                  <strong>ملاحظة:</strong> يمكنك إدارة العملاء والتراخيص التجارية من هنا. تأكد من صحة بيانات الدخول قبل إجراء أي تغييرات.
                </div>
              </div>
            </div>
          </div>
        )}

        {/* تبويبة إعدادات العميل */}
        {activeTab === 'customer-settings' && (
          <div style={{
            backgroundColor: 'white',
            borderRadius: '4px',
            padding: '12px'
          }}>
            <h2 style={{ color: '#2c5aa0', marginBottom: '20px' }}>👥 إعدادات العميل</h2>
            
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px', marginBottom: '20px' }}>
              {/* القسم الأول: إدارة المنتجات */}
              <div style={{
                backgroundColor: '#f8f9fa',
                padding: '12px',
                borderRadius: '4px',
                border: '1px solid #ddd'
              }}>
                <div style={{ 
                  display: 'flex', 
                  justifyContent: 'space-between', 
                  alignItems: 'center', 
                  marginBottom: '15px' 
                }}>
                  <h3 style={{ color: '#2c5aa0', margin: 0 }}>📦 إدارة المنتجات</h3>
                  <button
                    onClick={() => setShowAdvancedProductManager(true)}
                    style={{
                      backgroundColor: '#e74c3c',
                      color: 'white',
                      border: 'none',
                      padding: '8px 15px',
                      borderRadius: '20px',
                      cursor: 'pointer',
                      fontWeight: 'bold',
                      fontSize: '12px'
                    }}
                  >
                    🚀 الإدارة المتقدمة
                  </button>
                </div>
                
                {/* إضافة منتج جديد */}
                <div style={{ marginBottom: '15px' }}>
                  <h4 style={{ marginBottom: '10px' }}>إضافة منتج جديد:</h4>
                  <div style={{ display: 'grid', gap: '10px' }}>
                    <input 
                      type="text"
                      value={newProductName}
                      onChange={(e) => setNewProductName(e.target.value)}
                      style={{
                        width: '100%',
                        padding: '8px',
                        border: '1px solid #ddd',
                        borderRadius: '4px'
                      }}
                      placeholder="اسم المنتج"
                    />
                    <input 
                      type="number"
                      value={newProductPrice}
                      onChange={(e) => setNewProductPrice(e.target.value)}
                      style={{
                        width: '100%',
                        padding: '8px',
                        border: '1px solid #ddd',
                        borderRadius: '4px'
                      }}
                      placeholder={`السعر (${currencies[storeSettings.currency as keyof typeof currencies]?.symbol || 'ل.ل'})`}
                    />
                    <input 
                      type="text"
                      value={newProductBarcode}
                      onChange={(e) => setNewProductBarcode(e.target.value)}
                      style={{
                        width: '100%',
                        padding: '8px',
                        border: '1px solid #ddd',
                        borderRadius: '4px'
                      }}
                      placeholder="الباركود"
                    />
                    <input 
                      type="number"
                      min="0"
                      step="1"
                      value={newProductQuantity}
                      onChange={(e) => setNewProductQuantity(e.target.value)}
                      style={{
                        width: '100%',
                        padding: '8px',
                        border: '1px solid #ddd',
                        borderRadius: '4px'
                      }}
                      placeholder="العدد"
                    />
                    <button
                      onClick={addProduct}
                      style={{
                        backgroundColor: '#27ae60',
                        color: 'white',
                        border: 'none',
                        padding: '10px',
                        borderRadius: '4px',
                        cursor: 'pointer',
                        fontWeight: 'bold'
                      }}
                    >
                      ➕ إضافة منتج
                    </button>
                  </div>
                </div>

                {/* إحصائيات المنتجات */}
                <div style={{
                  backgroundColor: '#e3f2fd',
                  padding: '10px',
                  borderRadius: '4px',
                  textAlign: 'center',
                  marginBottom: '10px'
                }}>
                  <strong>إجمالي المنتجات: {products.length}</strong>
                </div>
              </div>

              {/* القسم الثاني: إدارة المخزون */}
              <div style={{
                backgroundColor: '#f8f9fa',
                padding: '12px',
                borderRadius: '4px',
                border: '1px solid #ddd'
              }}>
                <h3 style={{ color: '#2c5aa0', marginBottom: '15px' }}>📊 إدارة المخزون</h3>
                
                {/* إضافة حركة جديدة */}
                <div style={{ marginBottom: '15px' }}>
                  <h4 style={{ marginBottom: '10px' }}>تسجيل حركة جديدة:</h4>
                  <div style={{ display: 'grid', gap: '10px' }}>
                    <select
                      value={newMovementType}
                      onChange={(e) => setNewMovementType(e.target.value as 'incoming' | 'outgoing')}
                      style={{
                        width: '100%',
                        padding: '8px',
                        border: '1px solid #ddd',
                        borderRadius: '4px'
                      }}
                    >
                      <option value="incoming">📥 وارد</option>
                      <option value="outgoing">📤 صادر</option>
                    </select>
                    <input 
                      type="text"
                      value={newMovementProduct}
                      onChange={(e) => setNewMovementProduct(e.target.value)}
                      style={{
                        width: '100%',
                        padding: '8px',
                        border: '1px solid #ddd',
                        borderRadius: '4px'
                      }}
                      placeholder="اسم المنتج"
                    />
                    <input 
                      type="number"
                      value={newMovementQuantity}
                      onChange={(e) => setNewMovementQuantity(e.target.value)}
                      style={{
                        width: '100%',
                        padding: '8px',
                        border: '1px solid #ddd',
                        borderRadius: '4px'
                      }}
                      placeholder="الكمية"
                    />
                    <input 
                      type="text"
                      value={newMovementReason}
                      onChange={(e) => setNewMovementReason(e.target.value)}
                      style={{
                        width: '100%',
                        padding: '8px',
                        border: '1px solid #ddd',
                        borderRadius: '4px'
                      }}
                      placeholder="السبب (مطلوب)"
                    />
                    <input 
                      type="text"
                      value={newMovementNotes}
                      onChange={(e) => setNewMovementNotes(e.target.value)}
                      style={{
                        width: '100%',
                        padding: '8px',
                        border: '1px solid #ddd',
                        borderRadius: '4px'
                      }}
                      placeholder="ملاحظات (اختياري)"
                    />
                    <button
                      onClick={addStockMovement}
                      style={{
                        backgroundColor: '#3498db',
                        color: 'white',
                        border: 'none',
                        padding: '10px',
                        borderRadius: '4px',
                        cursor: 'pointer',
                        fontWeight: 'bold'
                      }}
                    >
                      ✅ تسجيل حركة
                    </button>
                  </div>
                </div>

                {/* إحصائيات المخزون */}
                <div style={{
                  backgroundColor: '#e8f5e8',
                  padding: '10px',
                  borderRadius: '4px',
                  fontSize: '10px',
                  lineHeight: '1.5'
                }}>
                  <div><strong>📥 إجمالي الوارد: {getTotalIncoming()}</strong></div>
                  <div><strong>📤 إجمالي الصادر: {getTotalOutgoing()}</strong></div>
                  <div><strong>📊 الرصيد الصافي: {getNetStock()}</strong></div>
                </div>
              </div>
            </div>

            {/* دليل الخطوات الإرشادية */}
            <div style={{
              backgroundColor: '#fff3cd',
              padding: '12px',
              borderRadius: '4px',
              border: '1px solid #ffeaa7',
              marginBottom: '20px'
            }}>
              <h3 style={{ color: '#856404', marginBottom: '15px' }}>📋 دليل الخطوات الإرشادية لصاحب المحل</h3>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' }}>
                <div>
                  <h4 style={{ color: '#856404' }}>🌅 الخطوات اليومية:</h4>
                  <ol style={{ paddingLeft: '20px', lineHeight: '1.6' }}>
                    <li>تحقق من حالة تفعيل النظام في الشريط العلوي</li>
                    <li>راجع قائمة المنتجات والأسعار</li>
                    <li>سجل أي مخزون وارد جديد</li>
                    <li>ابدأ عمليات البيع من تبويب "الكاشيير"</li>
                    <li>راجع التقارير في نهاية اليوم</li>
                  </ol>
                </div>
                <div>
                  <h4 style={{ color: '#856404' }}>📦 إدارة المخزون:</h4>
                  <ol style={{ paddingLeft: '20px', lineHeight: '1.6' }}>
                    <li>سجل كل البضاعة الواردة فور وصولها</li>
                    <li>سجل أي نواقص أو تلف في المخزون</li>
                    <li>راقب الأرصدة والمخزون المتاح</li>
                    <li>أضف منتجات جديدة عند الحاجة</li>
                    <li>حدث الأسعار حسب السوق</li>
                  </ol>
                </div>
              </div>
              <div style={{
                backgroundColor: '#ffeaa7',
                padding: '15px',
                borderRadius: '4px',
                marginTop: '15px'
              }}>
                <h4 style={{ color: '#856404', marginBottom: '10px' }}>⚠️ تذكيرات مهمة:</h4>
                <ul style={{ paddingLeft: '20px', lineHeight: '1.6', margin: 0 }}>
                  <li>تأكد من تفعيل النظام قبل بدء العمل</li>
                  <li>احفظ نسخة احتياطية من البيانات بانتظام</li>
                  <li>راجع التقارير المالية أسبوعياً</li>
                  <li>حدث قائمة المنتجات والأسعار شهرياً</li>
                </ul>
              </div>
            </div>

            {/* قوائم البيانات */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' }}>
              {/* قائمة المنتجات */}
              <div style={{
                backgroundColor: '#f8f9fa',
                padding: '12px',
                borderRadius: '4px',
                border: '1px solid #ddd'
              }}>
                <h3 style={{ color: '#2c5aa0', marginBottom: '15px' }}>📦 قائمة المنتجات</h3>
                <div style={{ maxHeight: '300px', overflowY: 'auto' }}>
                  {products.length > 0 ? products.map((product: any) => (
                    <div key={product.barcode} style={{
                      backgroundColor: 'white',
                      padding: '10px',
                      borderRadius: '4px',
                      border: '1px solid #ddd',
                      marginBottom: '8px',
                      display: 'flex',
                      justifyContent: 'space-between',
                      alignItems: 'center'
                    }}>
                      <div>
                        <div style={{ fontWeight: 'bold', fontSize: '14px' }}>{product.name}</div>
                        <div style={{ color: '#666', fontSize: '12px' }}>
                          {formatPrice(product.price)} | الباركود: {product.barcode}
                        </div>
                        <div style={{ color: '#27ae60', fontSize: '12px', fontWeight: 'bold' }}>
                          العدد المتاح: {product.quantity || 0}
                        </div>
                      </div>
                      <button
                        onClick={() => deleteProduct(product.barcode)}
                        style={{
                          backgroundColor: '#e74c3c',
                          color: 'white',
                          border: 'none',
                          padding: '6px 10px',
                          borderRadius: '4px',
                          cursor: 'pointer',
                          fontSize: '12px'
                        }}
                      >
                        🗑️
                      </button>
                    </div>
                  )) : (
                    <div style={{ 
                      textAlign: 'center', 
                      color: '#666', 
                      fontStyle: 'italic',
                      padding: '40px'
                    }}>
                      لا توجد منتجات مضافة بعد
                    </div>
                  )}
                </div>
              </div>

              {/* سجل حركات المخزون */}
              <div style={{
                backgroundColor: '#f8f9fa',
                padding: '12px',
                borderRadius: '4px',
                border: '1px solid #ddd'
              }}>
                <h3 style={{ color: '#2c5aa0', marginBottom: '15px' }}>📊 سجل حركات المخزون</h3>
                <div style={{ maxHeight: '300px', overflowY: 'auto' }}>
                  {stockMovements.length > 0 ? stockMovements.map((movement: any) => (
                    <div key={movement.id} style={{
                      backgroundColor: 'white',
                      padding: '10px',
                      borderRadius: '4px',
                      border: '1px solid #ddd',
                      marginBottom: '8px'
                    }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <div>
                          <div style={{ 
                            fontWeight: 'bold', 
                            fontSize: '10px',
                            color: movement.type === 'incoming' ? '#27ae60' : '#e74c3c'
                          }}>
                            {movement.type === 'incoming' ? '📥' : '📤'} {movement.productName}
                          </div>
                          <div style={{ color: '#666', fontSize: '12px' }}>
                            الكمية: {movement.quantity} | {movement.reason}
                          </div>
                          <div style={{ color: '#999', fontSize: '11px' }}>
                            {movement.date} {movement.time}
                          </div>
                        </div>
                        <button
                          onClick={() => deleteStockMovement(movement.id)}
                          style={{
                            backgroundColor: '#e74c3c',
                            color: 'white',
                            border: 'none',
                            padding: '6px 10px',
                            borderRadius: '4px',
                            cursor: 'pointer',
                            fontSize: '12px'
                          }}
                        >
                          🗑️
                        </button>
                      </div>
                    </div>
                  )) : (
                    <div style={{ 
                      textAlign: 'center', 
                      color: '#666', 
                      fontStyle: 'italic',
                      padding: '40px'
                    }}>
                      لا توجد حركات مخزون مسجلة بعد
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* تبويبة إعدادات الموظفين */}
        {activeTab === 'employee-settings' && (
          <div style={{
            backgroundColor: 'white',
            borderRadius: '4px',
            padding: '12px'
          }}>
            <h2 style={{ color: '#2c5aa0', marginBottom: '20px' }}>👨‍💼 إعدادات الموظفين</h2>
            
            {/* قسم إدارة الموظفين - تصميم مدمج */}
            <div style={{
              backgroundColor: '#f8f9fa',
              padding: '12px',
              borderRadius: '6px',
              marginTop: '15px',
              border: '1px solid #ddd'
            }}>
              <h3 style={{ color: '#2c5aa0', marginBottom: '12px', fontSize: '16px' }}>👥 إدارة الموظفين</h3>
              
              {/* نموذج مدمج */}
              <div style={{
                backgroundColor: '#e8f5e8',
                padding: '10px',
                borderRadius: '4px',
                marginBottom: '12px',
                border: '1px solid #c3e6cb'
              }}>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr auto', gap: '8px', alignItems: 'end' }}>
                  <div>
                    <label style={{ display: 'block', marginBottom: '3px', fontWeight: 'bold', fontSize: '12px' }}>
                      الاسم <span style={{ color: '#e74c3c' }}>*</span>
                    </label>
                    <input 
                      type="text"
                      value={newEmployeeName}
                      onChange={(e) => setNewEmployeeName(e.target.value)}
                      style={{
                        width: '100%',
                        padding: '6px',
                        border: '1px solid #ddd',
                        borderRadius: '3px',
                        fontSize: '12px'
                      }}
                      placeholder="الاسم الكامل"
                    />
                  </div>
                  
                  <div>
                    <label style={{ display: 'block', marginBottom: '3px', fontWeight: 'bold', fontSize: '12px' }}>
                      اسم المستخدم <span style={{ color: '#e74c3c' }}>*</span>
                    </label>
                    <input 
                      type="text"
                      value={newEmployeeUsername}
                      onChange={(e) => setNewEmployeeUsername(e.target.value)}
                      style={{
                        width: '100%',
                        padding: '6px',
                        border: '1px solid #ddd',
                        borderRadius: '3px',
                        fontSize: '12px'
                      }}
                      placeholder="اسم المستخدم"
                    />
                  </div>
                  
                  <div>
                    <label style={{ display: 'block', marginBottom: '3px', fontWeight: 'bold', fontSize: '12px' }}>
                      كلمة المرور <span style={{ color: '#e74c3c' }}>*</span>
                    </label>
                    <input 
                      type="password"
                      value={newEmployeePassword}
                      onChange={(e) => setNewEmployeePassword(e.target.value)}
                      style={{
                        width: '100%',
                        padding: '6px',
                        border: '1px solid #ddd',
                        borderRadius: '3px',
                        fontSize: '12px'
                      }}
                      placeholder="كلمة المرور"
                    />
                  </div>
                  
                  <div>
                    <button
                      onClick={addEmployee}
                      disabled={addingEmployee}
                      style={{
                        backgroundColor: addingEmployee ? '#6c757d' : '#27ae60',
                        color: 'white',
                        border: 'none',
                        padding: '7px 12px',
                        borderRadius: '3px',
                        cursor: addingEmployee ? 'default' : 'pointer',
                        fontWeight: 'bold',
                        fontSize: '10px',
                        whiteSpace: 'nowrap'
                      }}
                    >
                      {addingEmployee ? '...' : '➕ إضافة'}
                    </button>
                  </div>
                </div>
                
                {/* حقل الملاحظات في سطر منفصل */}
                <div style={{ marginTop: '8px' }}>
                  <input 
                    type="text"
                    value={newEmployeeNotes}
                    onChange={(e) => setNewEmployeeNotes(e.target.value)}
                    style={{
                      width: '100%',
                      padding: '6px',
                      border: '1px solid #ddd',
                      borderRadius: '3px',
                      fontSize: '12px'
                    }}
                    placeholder="ملاحظات (اختياري)"
                  />
                </div>
              </div>
              
              {/* قائمة مدمجة */}
              <div>
                <div style={{ 
                  display: 'flex', 
                  justifyContent: 'space-between', 
                  alignItems: 'center', 
                  marginBottom: '8px' 
                }}>
                  <h4 style={{ color: '#2c5aa0', margin: 0, fontSize: '14px' }}>
                    📋 الموظفين ({employees.length})
                  </h4>
                  <button
                    onClick={fetchEmployees}
                    disabled={loadingEmployees}
                    style={{
                      backgroundColor: '#17a2b8',
                      color: 'white',
                      border: 'none',
                      padding: '2px 6px',
                      borderRadius: '3px',
                      cursor: loadingEmployees ? 'default' : 'pointer',
                      fontSize: '11px'
                    }}
                  >
                    {loadingEmployees ? '⏳' : '🔄'}
                  </button>
                </div>
                
                {loadingEmployees ? (
                  <div style={{ 
                    textAlign: 'center', 
                    padding: '10px', 
                    color: '#666',
                    backgroundColor: '#f8f9fa',
                    borderRadius: '3px',
                    fontSize: '12px'
                  }}>
                    ⏳ جارٍ التحميل...
                  </div>
                ) : employees.length === 0 ? (
                  <div style={{ 
                    textAlign: 'center', 
                    padding: '10px', 
                    color: '#666',
                    backgroundColor: '#f8f9fa',
                    borderRadius: '3px',
                    fontSize: '12px'
                  }}>
                    👥 لا يوجد موظفين
                  </div>
                ) : (
                  <div style={{
                    backgroundColor: 'white',
                    border: '1px solid #ddd',
                    borderRadius: '4px',
                    overflow: 'hidden',
                    fontSize: '12px'
                  }}>
                    {/* جدول مدمج */}
                    {employees.map((employee: any, index) => (
                      <div 
                        key={employee.id}
                        style={{
                          padding: '8px',
                          display: 'flex',
                          justifyContent: 'space-between',
                          alignItems: 'center',
                          borderBottom: index < employees.length - 1 ? '1px solid #eee' : 'none',
                          backgroundColor: index % 2 === 0 ? 'white' : '#f8f9fa'
                        }}
                      >
                        <div style={{ flex: 1 }}>
                          <span style={{ fontWeight: 'bold', color: '#333' }}>
                            {employee.isActive ? '✅' : '❌'} {employee.name}
                          </span>
                          <span style={{ marginLeft: '10px', color: '#666' }}>
                            @{employee.username}
                          </span>
                        </div>
                        
                        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                          <span style={{ color: '#888', fontSize: '11px' }}>
                            {employee.createdAt ? new Date(employee.createdAt).toLocaleDateString('ar-LB', {day: '2-digit', month: '2-digit'}) : '-'}
                          </span>
                          <button
                            onClick={() => deleteEmployee(employee.id, employee.name)}
                            style={{
                              backgroundColor: '#dc3545',
                              color: 'white',
                              border: 'none',
                              padding: '3px 6px',
                              borderRadius: '2px',
                              cursor: 'pointer',
                              fontSize: '10px'
                            }}
                          >
                            🗑️
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* تبويبة إعدادات العمليات */}
        {activeTab === 'operations-settings' && (
          <div style={{
            backgroundColor: 'white',
            borderRadius: '4px',
            padding: '12px'
          }}>
            <h2 style={{ color: '#2c5aa0', marginBottom: '20px' }}>🔧 إعدادات العمليات</h2>
            
            {/* التبويبات الفرعية */}
            <div style={{ display: 'flex', gap: '5px', marginBottom: '20px', borderBottom: '1px solid #ddd', paddingBottom: '10px', flexWrap: 'wrap' }}>
              <button
                onClick={() => setOperationsTab('archives')}
                style={{
                  padding: '6px 12px',
                  backgroundColor: operationsTab === 'archives' ? '#2c5aa0' : '#f8f9fa',
                  color: operationsTab === 'archives' ? 'white' : '#666',
                  border: '1px solid #ddd',
                  borderRadius: '4px',
                  cursor: 'pointer',
                  fontSize: '13px'
                }}
              >
                🗄️ المحفوظات
              </button>
              <button
                onClick={() => setOperationsTab('returns')}
                style={{
                  padding: '6px 12px',
                  backgroundColor: operationsTab === 'returns' ? '#2c5aa0' : '#f8f9fa',
                  color: operationsTab === 'returns' ? 'white' : '#666',
                  border: '1px solid #ddd',
                  borderRadius: '4px',
                  cursor: 'pointer',
                  fontSize: '13px'
                }}
              >
                📦 المرتجعات
              </button>
              <button
                onClick={() => setOperationsTab('advanced-orders')}
                style={{
                  padding: '6px 12px',
                  backgroundColor: operationsTab === 'advanced-orders' ? '#2c5aa0' : '#f8f9fa',
                  color: operationsTab === 'advanced-orders' ? 'white' : '#666',
                  border: '1px solid #ddd',
                  borderRadius: '4px',
                  cursor: 'pointer',
                  fontSize: '13px'
                }}
              >
                📋 إدارة الطلبات
              </button>
              <button
                onClick={() => setOperationsTab('backup')}
                style={{
                  padding: '6px 12px',
                  backgroundColor: operationsTab === 'backup' ? '#2c5aa0' : '#f8f9fa',
                  color: operationsTab === 'backup' ? 'white' : '#666',
                  border: '1px solid #ddd',
                  borderRadius: '4px',
                  cursor: 'pointer',
                  fontSize: '13px'
                }}
              >
                💾 النسخ الاحتياطي
              </button>
              <button
                onClick={() => setOperationsTab('reports')}
                style={{
                  padding: '6px 12px',
                  backgroundColor: operationsTab === 'reports' ? '#2c5aa0' : '#f8f9fa',
                  color: operationsTab === 'reports' ? 'white' : '#666',
                  border: '1px solid #ddd',
                  borderRadius: '4px',
                  cursor: 'pointer',
                  fontSize: '13px'
                }}
              >
                📊 التقارير
              </button>
              <button
                onClick={() => setOperationsTab('sync')}
                style={{
                  padding: '6px 12px',
                  backgroundColor: operationsTab === 'sync' ? '#2c5aa0' : '#f8f9fa',
                  color: operationsTab === 'sync' ? 'white' : '#666',
                  border: '1px solid #ddd',
                  borderRadius: '4px',
                  cursor: 'pointer',
                  fontSize: '13px'
                }}
              >
                🔄 المزامنة
              </button>
            </div>

            {/* محتوى تبويب المحفوظات */}
            {operationsTab === 'archives' && (
              <div>
                <h3 style={{ color: '#2c5aa0', marginBottom: '15px' }}>🗄️ جميع عمليات البيع المحفوظة</h3>
                
                {/* قسم البحث عن فاتورة */}
                <div style={{
                  backgroundColor: '#f8f9fa',
                  padding: '20px',
                  borderRadius: '8px',
                  border: '2px solid #2c5aa0',
                  marginBottom: '20px'
                }}>
                  <h4 style={{ color: '#2c5aa0', marginBottom: '15px', fontSize: '16px' }}>🔍 البحث عن فاتورة برقمها</h4>
                  
                  <div style={{ marginBottom: '15px' }}>
                    <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
                      <input
                        type="text"
                        value={searchInvoiceNumber}
                        onChange={(e) => setSearchInvoiceNumber(e.target.value)}
                        style={{
                          flex: 1,
                          padding: '10px',
                          border: '2px solid #2c5aa0',
                          borderRadius: '6px',
                          fontSize: '14px',
                          textAlign: 'center',
                          fontWeight: 'bold'
                        }}
                        placeholder="أدخل رقم الفاتورة..."
                        onKeyPress={(e) => {
                          if (e.key === 'Enter') {
                            searchForInvoice()
                          }
                        }}
                      />
                      <button
                        onClick={searchForInvoice}
                        style={{
                          backgroundColor: '#27ae60',
                          color: 'white',
                          border: 'none',
                          padding: '10px 16px',
                          borderRadius: '6px',
                          cursor: 'pointer',
                          fontSize: '14px',
                          fontWeight: 'bold',
                          minWidth: '80px'
                        }}
                      >
                        🔍 بحث
                      </button>
                      <button
                        onClick={clearSearchResults}
                        style={{
                          backgroundColor: '#95a5a6',
                          color: 'white',
                          border: 'none',
                          padding: '10px 16px',
                          borderRadius: '6px',
                          cursor: 'pointer',
                          fontSize: '14px',
                          fontWeight: 'bold'
                        }}
                      >
                        🗑️ مسح
                      </button>
                      <button
                        onClick={addSampleDataWithEmployee}
                        style={{
                          backgroundColor: '#9b59b6',
                          color: 'white',
                          border: 'none',
                          padding: '10px 16px',
                          borderRadius: '6px',
                          cursor: 'pointer',
                          fontSize: '14px',
                          fontWeight: 'bold'
                        }}
                      >
                        📊 بيانات تجريبية
                      </button>
                    </div>
                  </div>
                  
                  {/* عرض رسالة الخطأ إن وجدت */}
                  {searchError && (
                    <div style={{
                      backgroundColor: '#ffebee',
                      border: '2px solid #f44336',
                      borderRadius: '6px',
                      padding: '10px',
                      marginBottom: '15px',
                      textAlign: 'center',
                      fontSize: '14px',
                      fontWeight: 'bold',
                      color: '#c62828'
                    }}>
                      {searchError}
                    </div>
                  )}

                  {/* عرض نتيجة البحث */}
                  {searchResult && (
                    <div style={{
                      backgroundColor: '#e8f5e8',
                      border: '2px solid #4caf50',
                      borderRadius: '8px',
                      padding: '15px',
                      marginBottom: '15px'
                    }}>
                      <h5 style={{ 
                        color: '#2e7d32', 
                        marginBottom: '10px',
                        textAlign: 'center',
                        fontSize: '16px'
                      }}>
                        ✅ تم العثور على الفاتورة!
                      </h5>
                      
                      <div style={{
                        backgroundColor: 'white',
                        padding: '15px',
                        borderRadius: '6px',
                        border: '1px solid #4caf50'
                      }}>
                        <div style={{ 
                          display: 'grid', 
                          gridTemplateColumns: '1fr 1fr 1fr', 
                          gap: '10px',
                          marginBottom: '10px'
                        }}>
                          <div style={{ fontSize: '12px' }}>
                            <span style={{ fontWeight: 'bold', color: '#2c5aa0' }}>📋 رقم:</span>
                            <br />{searchResult.id}
                          </div>
                          <div style={{ fontSize: '12px' }}>
                            <span style={{ fontWeight: 'bold', color: '#2c5aa0' }}>👤 العميل:</span>
                            <br />{searchResult.customerName}
                          </div>
                          <div style={{ fontSize: '12px' }}>
                            <span style={{ fontWeight: 'bold', color: '#27ae60' }}>💰 المجموع:</span>
                            <br />{formatPrice(searchResult.total)}
                          </div>
                        </div>
                        
                        <div style={{ 
                          display: 'flex', 
                          justifyContent: 'center', 
                          gap: '10px',
                          marginTop: '10px'
                        }}>
                          <button
                            onClick={() => printReceipt(searchResult)}
                            style={{
                              backgroundColor: '#3498db',
                              color: 'white',
                              border: 'none',
                              padding: '8px 12px',
                              borderRadius: '4px',
                              cursor: 'pointer',
                              fontSize: '12px',
                              fontWeight: 'bold'
                            }}
                          >
                            🖨️ طباعة
                          </button>
                          <button
                            onClick={() => {
                              setSelectedOrder(searchResult);
                              setReturnItems({});
                              setReturnReason('');
                              setShowReturnModal(true);
                            }}
                            style={{
                              backgroundColor: '#e74c3c',
                              color: 'white',
                              border: 'none',
                              padding: '8px 12px',
                              borderRadius: '4px',
                              cursor: 'pointer',
                              fontSize: '12px',
                              fontWeight: 'bold'
                            }}
                          >
                            🔄 إرجاع
                          </button>
                        </div>
                      </div>
                    </div>
                  )}
                  
                  {/* عرض أرقام الفواتير المتاحة للبحث إن وجدت */}
                  {orders.length > 0 && (
                    <div style={{
                      backgroundColor: '#fff3e0',
                      border: '1px solid #ff9800',
                      borderRadius: '6px',
                      padding: '10px',
                      fontSize: '12px',
                      color: '#e65100'
                    }}>
                      <div style={{ fontWeight: 'bold', marginBottom: '8px' }}>
                        📋 أرقام الفواتير المتاحة (انقر للبحث):
                      </div>
                      <div style={{ 
                        display: 'grid', 
                        gridTemplateColumns: 'repeat(auto-fit, minmax(120px, 1fr))', 
                        gap: '5px',
                        marginTop: '8px'
                      }}>
                        {orders.slice(0, 6).map((order) => (
                          <div key={order.id} style={{
                            backgroundColor: 'white',
                            padding: '4px',
                            borderRadius: '4px',
                            border: '1px solid #ff9800',
                            cursor: 'pointer',
                            textAlign: 'center',
                            fontSize: '10px'
                          }}
                          onClick={() => setSearchInvoiceNumber(order.id)}
                          >
                            <div style={{ fontWeight: 'bold', color: '#2c5aa0' }}>{order.id}</div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
                
                {orders.length > 0 ? (
                  <div style={{ display: 'grid', gap: '10px' }}>
                    {orders.map((order) => (
                      <div key={order.id} style={{
                        backgroundColor: '#f8f9fa',
                        padding: '15px',
                        borderRadius: '4px',
                        border: '1px solid #ddd',
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center'
                      }}>
                        <div style={{ flex: 1 }}>
                          <div style={{ display: 'flex', gap: '4px', alignItems: 'center' }}>
                            <div>
                              <div style={{ fontWeight: 'bold', fontSize: '16px', color: '#2c5aa0' }}>
                                فاتورة رقم: {order.id}
                              </div>
                              <div style={{ color: '#666', fontSize: '14px', marginTop: '5px' }}>
                                📅 {order.date} | 👤 {order.customerName}
                              </div>
                              <div style={{ color: '#2c5aa0', fontSize: '13px', marginTop: '3px', fontWeight: 'bold' }}>
                                🧑‍💼 الكاشير: {(order as any).employeeName || 'غير محدد'}
                              </div>
                              {/* زر إضافة بيانات تجريبية للاختبار */}
                              {orders.length === 0 && currentEmployee && (
                                <div style={{ marginTop: '15px' }}>
                                  <button
                                    onClick={addSampleDataWithEmployee}
                                    style={{
                                      backgroundColor: '#9b59b6',
                                      color: 'white',
                                      border: 'none',
                                      padding: '8px 15px',
                                      borderRadius: '4px',
                                      cursor: 'pointer',
                                      fontSize: '12px'
                                    }}
                                  >
                                    🎯 إضافة فواتير تجريبية لاختبار اسم الموظف
                                  </button>
                                </div>
                              )}
                            </div>
                            <div>
                              <div style={{ fontWeight: 'bold', color: '#27ae60', fontSize: '18px' }}>
                                {formatPrice(order.total)}
                              </div>
                              <div style={{ color: '#666', fontSize: '12px' }}>
                                {order.paymentMethod === 'cash' ? '💵 نقدي' : '💳 بطاقة'}
                              </div>
                            </div>
                            <div>
                              <div style={{ color: '#666', fontSize: '14px' }}>
                                📦 {order.items.length} صنف
                              </div>
                            </div>
                          </div>
                        </div>
                        
                        <div style={{ display: 'flex', gap: '10px' }}>
                          <button
                            onClick={() => {
                              setSelectedOrder(order);
                              setReturnItems({});
                              setReturnReason('');
                              setShowReturnModal(true);
                            }}
                            style={{
                              backgroundColor: '#e74c3c',
                              color: 'white',
                              border: 'none',
                              padding: '8px 12px',
                              borderRadius: '4px',
                              cursor: 'pointer',
                              fontSize: '14px'
                            }}
                          >
                            🔄 إرجاع
                          </button>
                          <button
                            onClick={() => printReceipt(order)}
                            style={{
                              backgroundColor: '#3498db',
                              color: 'white',
                              border: 'none',
                              padding: '8px 12px',
                              borderRadius: '4px',
                              cursor: 'pointer',
                              fontSize: '14px'
                            }}
                          >
                            🖨️ طباعة
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div style={{ 
                    textAlign: 'center', 
                    color: '#666', 
                    fontStyle: 'italic',
                    padding: '40px',
                    backgroundColor: '#f8f9fa',
                    borderRadius: '4px'
                  }}>
                    لا توجد عمليات بيع محفوظة بعد
                  </div>
                )}
              </div>
            )}

            {/* محتوى تبويب المرتجعات */}
            {operationsTab === 'returns' && (
              <div>
                <h3 style={{ color: '#2c5aa0', marginBottom: '15px' }}>📦 سجل المرتجعات</h3>
                
                {returns.length > 0 ? (
                  <div style={{ display: 'grid', gap: '10px' }}>
                    {returns.map((returnRecord) => (
                      <div key={returnRecord.id} style={{
                        backgroundColor: '#fff5f5',
                        padding: '15px',
                        borderRadius: '4px',
                        border: '1px solid #fed7d7',
                        borderLeft: '4px solid #e53e3e'
                      }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                          <div style={{ flex: 1 }}>
                            <div style={{ display: 'flex', gap: '10px', alignItems: 'center', marginBottom: '10px' }}>
                              <div>
                                <div style={{ fontWeight: 'bold', fontSize: '16px', color: '#e53e3e' }}>
                                  🔄 إرجاع رقم: {returnRecord.id}
                                </div>
                                <div style={{ color: '#666', fontSize: '14px', marginTop: '5px' }}>
                                  📅 {returnRecord.returnDate} - {returnRecord.returnTime} | 👤 {returnRecord.customerName}
                                </div>
                              </div>
                              <div>
                                <div style={{ fontWeight: 'bold', color: '#e53e3e', fontSize: '18px' }}>
                                  - {formatPrice(returnRecord.totalReturnAmount)}
                                </div>
                                <div style={{ color: '#666', fontSize: '12px' }}>
                                  📦 {returnRecord.returnedItems.length} صنف مرجع
                                </div>
                              </div>
                            </div>
                            
                            <div style={{ 
                              backgroundColor: 'rgba(229, 62, 62, 0.1)', 
                              padding: '10px', 
                              borderRadius: '6px', 
                              marginBottom: '10px' 
                            }}>
                              <div style={{ fontWeight: 'bold', marginBottom: '5px', color: '#2c5aa0' }}>
                                📋 تفاصيل الأصناف المرجعة:
                              </div>
                              {returnRecord.returnedItems.map((item, index) => (
                                <div key={index} style={{ fontSize: '14px', color: '#666', marginBottom: '3px' }}>
                                  • {item.name} - الكمية: {item.returnedQuantity} - المبلغ: {formatPrice(item.returnAmount)}
                                </div>
                              ))}
                            </div>
                            
                            {returnRecord.reason && (
                              <div style={{ 
                                backgroundColor: '#f8f9fa', 
                                padding: '8px', 
                                borderRadius: '4px', 
                                marginBottom: '10px',
                                fontSize: '14px'
                              }}>
                                <span style={{ fontWeight: 'bold' }}>📝 السبب: </span>
                                <span style={{ color: '#666' }}>{returnRecord.reason}</span>
                              </div>
                            )}
                            
                            <div style={{ fontSize: '12px', color: '#999' }}>
                              📄 الفاتورة الأصلية: {returnRecord.originalOrderId} ({returnRecord.originalOrderDate})
                              <br />
                              👨‍💼 تمت المعالجة بواسطة: {returnRecord.processedBy}
                            </div>
                          </div>
                          
                          <div style={{ display: 'flex', gap: '10px', flexDirection: 'column' }}>
                            <button
                              onClick={() => printReturnReceipt(returnRecord)}
                              style={{
                                backgroundColor: '#3498db',
                                color: 'white',
                                border: 'none',
                                padding: '8px 12px',
                                borderRadius: '4px',
                                cursor: 'pointer',
                                fontSize: '14px'
                              }}
                            >
                              🖨️ طباعة
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div style={{ 
                    textAlign: 'center', 
                    color: '#666', 
                    fontStyle: 'italic',
                    padding: '40px',
                    backgroundColor: '#f8f9fa',
                    borderRadius: '4px'
                  }}>
                    لا توجد عمليات إرجاع مسجلة بعد
                  </div>
                )}
              </div>
            )}


            {/* محتوى تبويب إدارة الطلبات المتقدمة */}
            {operationsTab === 'advanced-orders' && (
              <div style={{
                backgroundColor: '#f8f9fa',
                padding: '12px',
                borderRadius: '4px',
                border: '1px solid #ddd'
              }}>
                <h3 style={{ color: '#2c5aa0', marginBottom: '15px' }}>📋 إدارة الطلبات المتقدمة</h3>
                <div style={{
                  backgroundColor: '#2c5aa0',
                  color: 'white',
                  padding: '10px',
                  display: 'grid',
                  gridTemplateColumns: '1fr 1fr 1fr 1fr 1fr 100px',
                  gap: '10px',
                  fontWeight: 'bold'
                }}>
                  <div>رقم الطلب</div>
                  <div>العميل</div>
                  <div>التاريخ</div>
                  <div>المجموع</div>
                  <div>الحالة</div>
                  <div>حذف</div>
                </div>
                
                {orders.length === 0 ? (
                  <div style={{ padding: '40px', textAlign: 'center', color: '#666' }}>
                    لا توجد أوامر
                  </div>
                ) : (
                  orders.map(order => (
                    <div 
                      key={order.id}
                      style={{
                        display: 'grid',
                        gridTemplateColumns: '1fr 1fr 1fr 1fr 1fr 100px',
                        gap: '10px',
                        padding: '15px 10px',
                        borderBottom: '1px solid #eee',
                        alignItems: 'center',
                        backgroundColor: 'white'
                      }}
                    >
                      <div style={{ fontWeight: 'bold', fontSize: '14px' }}>{order.id}</div>
                      <div>{order.customerName}</div>
                      <div>{order.date}</div>
                      <div>{formatPrice(order.total)}</div>
                      <div>
                        <span style={{
                          padding: '2px 6px',
                          borderRadius: '12px',
                          fontSize: '10px',
                          color: 'white',
                          backgroundColor: 
                            order.status === 'completed' ? '#27ae60' :
                            order.status === 'pending' ? '#f39c12' : '#e74c3c'
                        }}>
                          {order.status === 'completed' ? 'مكتمل' :
                           order.status === 'pending' ? 'معلق' : 'ملغي'}
                        </span>
                      </div>
                      <div>
                        <button
                          onClick={() => {
                            const updatedOrders = orders.filter(o => o.id !== order.id);
                            setOrders(updatedOrders);
                            localStorage.setItem('supermarket_orders', JSON.stringify(updatedOrders));
                          }}
                          style={{
                            backgroundColor: '#e74c3c',
                            color: 'white',
                            border: 'none',
                            padding: '5px 10px',
                            borderRadius: '4px',
                            cursor: 'pointer',
                            fontSize: '12px'
                          }}
                        >
                          🗑️
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            )}

            {/* محتوى تبويب النسخ الاحتياطي */}
            {operationsTab === 'backup' && (
              <div style={{
                backgroundColor: '#f8f9fa',
                padding: '12px',
                borderRadius: '4px',
                border: '1px solid #ddd'
              }}>
                <h3 style={{ color: '#2c5aa0', marginBottom: '15px' }}>💾 نسخ احتياطي للبيانات</h3>
                <div style={{ marginBottom: '15px', fontSize: '14px', color: '#666' }}>
                  تصدير جميع بيانات البرنامج (المنتجات، الطلبات، الإعدادات، المخزون، المرتجعات)
                </div>
                <button
                  onClick={exportAllData}
                  style={{
                    backgroundColor: '#28a745',
                    color: 'white',
                    border: 'none',
                    padding: '12px 20px',
                    borderRadius: '6px',
                    cursor: 'pointer',
                    fontWeight: 'bold',
                    fontSize: '16px',
                    width: '100%'
                  }}
                >
                  📤 تصدير البيانات
                </button>
              </div>
            )}

            {/* محتوى تبويب التقارير */}
            {operationsTab === 'reports' && (
              <div style={{
                backgroundColor: '#f8f9fa',
                padding: '12px',
                borderRadius: '4px',
                border: '1px solid #ddd'
              }}>
                <h3 style={{ color: '#2c5aa0', marginBottom: '15px' }}>📊 التقرير السنوي</h3>
                <div style={{ marginBottom: '15px', fontSize: '14px', color: '#666' }}>
                  إجمالي المبيعات للعام الحالي ({new Date().getFullYear()})
                </div>
                <div style={{
                  backgroundColor: '#2c5aa0',
                  color: 'white',
                  padding: '15px',
                  borderRadius: '6px',
                  textAlign: 'center',
                  fontSize: '20px',
                  fontWeight: 'bold'
                }}>
                  {formatPrice(calculateAnnualSales())}
                </div>
              </div>
            )}

            {/* محتوى تبويب المزامنة */}
            {operationsTab === 'sync' && (
              <div style={{
                backgroundColor: '#e8f5ff',
                padding: '12px',
                borderRadius: '4px',
                border: '2px solid #3498db'
              }}>
                <div style={{ 
                  display: 'flex', 
                  justifyContent: 'space-between', 
                  alignItems: 'center', 
                  marginBottom: '20px' 
                }}>
                  <h3 style={{ color: '#2c5aa0', margin: 0, fontWeight: 'bold' }}>
                    🔄 مزامنة الأجهزة عبر الشبكة المحلية
                  </h3>
                  <button
                    onClick={() => setShowSyncSettings(true)}
                    style={{
                      backgroundColor: '#3498db',
                      color: 'white',
                      border: 'none',
                      padding: '10px 20px',
                      borderRadius: '20px',
                      cursor: 'pointer',
                      fontWeight: 'bold',
                      fontSize: '14px'
                    }}
                  >
                    ⚙️ إعدادات المزامنة
                  </button>
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '10px', marginBottom: '20px' }}>
                  {/* حالة المزامنة */}
                  <div style={{
                    backgroundColor: 'white',
                    padding: '15px',
                    borderRadius: '4px',
                    border: '1px solid #3498db'
                  }}>
                    <h4 style={{ color: '#2c5aa0', marginBottom: '10px', fontSize: '16px' }}>📊 حالة المزامنة</h4>
                    <div style={{ fontSize: '14px', lineHeight: '1.6' }}>
                      <div style={{ 
                        color: syncSettings.enabled ? '#27ae60' : '#e74c3c',
                        fontWeight: 'bold',
                        marginBottom: '5px'
                      }}>
                        {syncSettings.enabled ? '🟢 مفعلة' : '🔴 معطلة'}
                      </div>
                      <div style={{ color: '#666' }}>
                        الجهاز: {syncSettings.deviceName}
                      </div>
                      {syncSettings.lastSync && (
                        <div style={{ color: '#666' }}>
                          آخر مزامنة: {new Date(syncSettings.lastSync).toLocaleString('ar-LB')}
                        </div>
                      )}
                    </div>
                  </div>

                  {/* إحصائيات المزامنة */}
                  <div style={{
                    backgroundColor: 'white',
                    padding: '15px',
                    borderRadius: '4px',
                    border: '1px solid #3498db'
                  }}>
                    <h4 style={{ color: '#2c5aa0', marginBottom: '10px', fontSize: '16px' }}>📈 إحصائيات</h4>
                    <div style={{ fontSize: '14px', lineHeight: '1.6' }}>
                      <div style={{ marginBottom: '5px' }}>
                        📦 منتجات: {products.length}
                      </div>
                      <div style={{ marginBottom: '5px' }}>
                        📝 طلبات: {orders.length}
                      </div>
                      <div style={{ marginBottom: '5px' }}>
                        🔄 مرتجعات: {returns.length}
                      </div>
                    </div>
                  </div>

                  {/* إجراءات سريعة */}
                  <div style={{
                    backgroundColor: 'white',
                    padding: '15px',
                    borderRadius: '4px',
                    border: '1px solid #3498db'
                  }}>
                    <h4 style={{ color: '#2c5aa0', marginBottom: '10px', fontSize: '16px' }}>⚡ إجراءات سريعة</h4>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                      <button
                        onClick={handleManualUpload}
                        disabled={!syncSettings.enabled || isUploading}
                        style={{
                          backgroundColor: syncSettings.enabled ? '#27ae60' : '#95a5a6',
                          color: 'white',
                          border: 'none',
                          padding: '8px 12px',
                          borderRadius: '4px',
                          cursor: syncSettings.enabled ? 'pointer' : 'not-allowed',
                          fontSize: '12px'
                        }}
                      >
                        {isUploading ? '⏳ جاري الرفع...' : '📤 رفع البيانات'}
                      </button>
                      <button
                        onClick={handleManualDownload}
                        disabled={!syncSettings.enabled || isDownloading}
                        style={{
                          backgroundColor: syncSettings.enabled ? '#3498db' : '#95a5a6',
                          color: 'white',
                          border: 'none',
                          padding: '8px 12px',
                          borderRadius: '4px',
                          cursor: syncSettings.enabled ? 'pointer' : 'not-allowed',
                          fontSize: '12px'
                        }}
                      >
                        {isDownloading ? '⏳ جاري التنزيل...' : '📥 تنزيل البيانات'}
                      </button>
                    </div>
                  </div>
                </div>

                {/* معلومات الشبكة والاتصال */}
                <div style={{
                  backgroundColor: '#fff',
                  padding: '15px',
                  borderRadius: '4px',
                  border: '1px solid #3498db'
                }}>
                  <h4 style={{ color: '#2c5aa0', marginBottom: '10px' }}>🌐 معلومات الشبكة</h4>
                  <div style={{ fontSize: '14px', color: '#666', lineHeight: '1.6' }}>
                    <div><strong>URL الخادم:</strong> {syncSettings.serverUrl || 'غير محدد'}</div>
                    <div><strong>آخر اختبار اتصال:</strong> {syncSettings.lastConnectivityTest ? new Date(syncSettings.lastConnectivityTest).toLocaleString('ar-LB') : 'لم يتم'}</div>
                    <div><strong>حالة الاتصال:</strong> 
                      <span style={{ 
                        color: syncSettings.connectivityStatus === 'connected' ? '#27ae60' : '#e74c3c',
                        fontWeight: 'bold',
                        marginLeft: '5px'
                      }}>
                        {syncSettings.connectivityStatus === 'connected' ? '🟢 متصل' : '🔴 غير متصل'}
                      </span>
                    </div>
                  </div>
                </div>

                {/* تعليمات الإعداد */}
                <div style={{
                  backgroundColor: '#fff3cd',
                  padding: '15px',
                  borderRadius: '4px',
                  border: '1px solid #ffc107',
                  marginTop: '15px'
                }}>
                  <h4 style={{ color: '#856404', marginBottom: '10px' }}>💡 كيفية الإعداد</h4>
                  <ol style={{ fontSize: '14px', color: '#856404', marginLeft: '20px', lineHeight: '1.6' }}>
                    <li>على الجهاز الرئيسي: اتركه كما هو (localhost)</li>
                    <li>على الأجهزة الأخرى: ضع عنوان IP للجهاز الرئيسي مثل: http://192.168.1.100:5000</li>
                    <li>تأكد من أن جميع الأجهزة متصلة بنفس الشبكة المحلية</li>
                    <li>اختبر الاتصال قبل البدء</li>
                  </ol>
                </div>
              </div>
            )}
          </div>
        )}

        {/* نافذة الإرجاع */}
        {showReturnModal && selectedOrder && (
          <div style={{
            position: 'fixed',
            top: 0,
            left: 0,
            width: '100%',
            height: '100%',
            backgroundColor: 'rgba(0, 0, 0, 0.5)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 1000
          }}>
            <div style={{
              backgroundColor: 'white',
              padding: '30px',
              borderRadius: '4px',
              width: '80%',
              maxWidth: '600px',
              maxHeight: '80%',
              overflowY: 'auto',
              boxShadow: '0 4px 8px rgba(0,0,0,0.2)'
            }}>
              <h3 style={{ color: '#2c5aa0', marginBottom: '20px', textAlign: 'center' }}>
                🔄 إرجاع أصناف من فاتورة رقم: {selectedOrder.id}
              </h3>

              <div style={{ marginBottom: '20px', padding: '15px', backgroundColor: '#f8f9fa', borderRadius: '6px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '10px' }}>
                  <span>📅 التاريخ: {selectedOrder.date}</span>
                  <span>👤 العميل: {selectedOrder.customerName}</span>
                </div>
                <div style={{ fontWeight: 'bold', color: '#27ae60' }}>
                  💰 إجمالي الفاتورة: {formatPrice(selectedOrder.total)}
                </div>
              </div>

              <h4 style={{ color: '#2c5aa0', marginBottom: '15px' }}>📦 الأصناف المتاحة للإرجاع:</h4>
              
              <div style={{ display: 'grid', gap: '10px', marginBottom: '20px' }}>
                {selectedOrder.items.map((item, index) => {
                  // حساب الكمية المرجعة مسبقاً لهذا الصنف
                  const alreadyReturned = returns.reduce((total, returnRecord) => {
                    if (returnRecord.originalOrderId === selectedOrder.id) {
                      const returnedItem = returnRecord.returnedItems.find(ri => ri.barcode === item.barcode)
                      return total + (returnedItem ? returnedItem.returnedQuantity : 0)
                    }
                    return total
                  }, 0)
                  
                  const maxReturnableQty = item.quantity - alreadyReturned
                  
                  return (
                    <div key={index} style={{
                      display: 'flex',
                      justifyContent: 'space-between',
                      alignItems: 'center',
                      padding: '10px',
                      backgroundColor: maxReturnableQty > 0 ? '#f8f9fa' : '#fff3cd',
                      borderRadius: '6px',
                      border: `1px solid ${maxReturnableQty > 0 ? '#ddd' : '#ffeaa7'}`
                    }}>
                      <div style={{ flex: 1 }}>
                        <div style={{ fontWeight: 'bold', fontSize: '16px', marginBottom: '5px' }}>{item.name}</div>
                        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '15px', marginBottom: '8px' }}>
                          <div style={{ 
                            backgroundColor: '#e3f2fd', 
                            padding: '4px 8px', 
                            borderRadius: '4px',
                            fontSize: '12px',
                            fontWeight: 'bold',
                            color: '#1976d2'
                          }}>
                            📦 الكمية الأصلية: {item.quantity}
                          </div>
                          <div style={{ 
                            backgroundColor: '#f1f8e9', 
                            padding: '4px 8px', 
                            borderRadius: '4px',
                            fontSize: '12px',
                            fontWeight: 'bold',
                            color: '#388e3c'
                          }}>
                            💰 السعر: {formatPrice(item.price)}
                          </div>
                          {alreadyReturned > 0 && (
                            <div style={{ 
                              backgroundColor: '#ffebee', 
                              padding: '4px 8px', 
                              borderRadius: '4px',
                              fontSize: '12px',
                              fontWeight: 'bold',
                              color: '#d32f2f'
                            }}>
                              🔄 تم إرجاع: {alreadyReturned}
                            </div>
                          )}
                          <div style={{ 
                            backgroundColor: maxReturnableQty > 0 ? '#e8f5e8' : '#fff3e0', 
                            padding: '4px 8px', 
                            borderRadius: '4px',
                            fontSize: '12px',
                            fontWeight: 'bold',
                            color: maxReturnableQty > 0 ? '#2e7d32' : '#f57c00'
                          }}>
                            ✅ متاح للإرجاع: {maxReturnableQty}
                          </div>
                        </div>
                        {maxReturnableQty === 0 && (
                          <div style={{ 
                            color: '#ff9800', 
                            fontSize: '13px', 
                            fontWeight: 'bold',
                            backgroundColor: '#fff3e0',
                            padding: '5px 8px',
                            borderRadius: '4px',
                            border: '1px solid #ffb74d'
                          }}>
                            ⚠️ تم إرجاع الكمية كاملة - لا يمكن الإرجاع
                          </div>
                        )}
                      </div>
                      
                      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '8px', minWidth: '120px' }}>
                        <span style={{ fontSize: '14px', fontWeight: 'bold', color: '#2c5aa0' }}>كمية الإرجاع:</span>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
                          <button
                            onClick={() => {
                              const currentValue = returnItems[item.barcode] || 0;
                              if (currentValue > 0) {
                                setReturnItems(prev => ({
                                  ...prev,
                                  [item.barcode]: currentValue - 1
                                }));
                              }
                            }}
                            disabled={maxReturnableQty === 0 || (returnItems[item.barcode] || 0) <= 0}
                            style={{
                              width: '30px',
                              height: '30px',
                              borderRadius: '50%',
                              border: '1px solid #ddd',
                              backgroundColor: '#f8f9fa',
                              cursor: 'pointer',
                              fontSize: '18px',
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center'
                            }}
                          >
                            -
                          </button>
                          <input
                            type="number"
                            min="0"
                            max={maxReturnableQty}
                            value={returnItems[item.barcode] || 0}
                            disabled={maxReturnableQty === 0}
                            onChange={(e) => {
                              const value = Math.min(parseInt(e.target.value) || 0, maxReturnableQty);
                              setReturnItems(prev => ({
                                ...prev,
                                [item.barcode]: value
                              }));
                            }}
                            style={{
                              width: '60px',
                              height: '30px',
                              padding: '5px',
                              border: '2px solid #2c5aa0',
                              borderRadius: '6px',
                              textAlign: 'center',
                              backgroundColor: maxReturnableQty === 0 ? '#f5f5f5' : 'white',
                              color: maxReturnableQty === 0 ? '#999' : '#2c5aa0',
                              fontWeight: 'bold',
                              fontSize: '14px'
                            }}
                          />
                          <button
                            onClick={() => {
                              const currentValue = returnItems[item.barcode] || 0;
                              if (currentValue < maxReturnableQty) {
                                setReturnItems(prev => ({
                                  ...prev,
                                  [item.barcode]: currentValue + 1
                                }));
                              }
                            }}
                            disabled={maxReturnableQty === 0 || (returnItems[item.barcode] || 0) >= maxReturnableQty}
                            style={{
                              width: '30px',
                              height: '30px',
                              borderRadius: '50%',
                              border: '1px solid #ddd',
                              backgroundColor: '#f8f9fa',
                              cursor: 'pointer',
                              fontSize: '18px',
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center'
                            }}
                          >
                            +
                          </button>
                        </div>
                        {maxReturnableQty > 0 && (
                          <button
                            onClick={() => {
                              setReturnItems(prev => ({
                                ...prev,
                                [item.barcode]: maxReturnableQty
                              }));
                            }}
                            style={{
                              fontSize: '10px',
                              padding: '2px 6px',
                              backgroundColor: '#e3f2fd',
                              color: '#1976d2',
                              border: '1px solid #1976d2',
                              borderRadius: '4px',
                              cursor: 'pointer'
                            }}
                          >
                            إرجاع الكل
                          </button>
                        )}
                        {(returnItems[item.barcode] || 0) > 0 && (
                          <div style={{
                            fontSize: '12px',
                            fontWeight: 'bold',
                            color: '#d32f2f',
                            backgroundColor: '#ffebee',
                            padding: '2px 6px',
                            borderRadius: '4px',
                            border: '1px solid #f44336'
                          }}>
                            💰 -{formatPrice((returnItems[item.barcode] || 0) * item.price)}
                          </div>
                        )}
                      </div>
                    </div>
                  )
                })}
              </div>

              <div style={{ marginBottom: '20px' }}>
                <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
                  📝 سبب الإرجاع:
                </label>
                <textarea
                  value={returnReason}
                  onChange={(e) => setReturnReason(e.target.value)}
                  placeholder="اختياري - اكتب سبب الإرجاع..."
                  style={{
                    width: '100%',
                    padding: '10px',
                    border: '1px solid #ddd',
                    borderRadius: '4px',
                    minHeight: '60px',
                    resize: 'vertical'
                  }}
                />
              </div>

              {/* حساب إجمالي المبلغ المرجع */}
              {(() => {
                const totalReturnAmount = selectedOrder.items.reduce((total, item) => {
                  const returnQty = returnItems[item.barcode] || 0;
                  return total + (returnQty * item.price);
                }, 0);
                
                return totalReturnAmount > 0 ? (
                  <div style={{
                    padding: '15px',
                    backgroundColor: '#e8f5e8',
                    border: '1px solid #27ae60',
                    borderRadius: '6px',
                    marginBottom: '20px',
                    textAlign: 'center'
                  }}>
                    <div style={{ fontWeight: 'bold', color: '#27ae60', fontSize: '18px' }}>
                      💰 إجمالي المبلغ المرجع: {formatPrice(totalReturnAmount)}
                    </div>
                  </div>
                ) : null;
              })()}

              <div style={{ display: 'flex', gap: '10px', justifyContent: 'center' }}>
                <button
                  onClick={() => {
                    setShowReturnModal(false);
                    setSelectedOrder(null);
                    setReturnItems({});
                    setReturnReason('');
                  }}
                  style={{
                    padding: '10px 20px',
                    backgroundColor: '#95a5a6',
                    color: 'white',
                    border: 'none',
                    borderRadius: '6px',
                    cursor: 'pointer'
                  }}
                >
                  إلغاء
                </button>
                <button
                  onClick={processReturn}
                  disabled={Object.values(returnItems).every(qty => qty === 0)}
                  style={{
                    padding: '10px 20px',
                    backgroundColor: Object.values(returnItems).some(qty => qty > 0) ? '#27ae60' : '#95a5a6',
                    color: 'white',
                    border: 'none',
                    borderRadius: '6px',
                    cursor: Object.values(returnItems).some(qty => qty > 0) ? 'pointer' : 'not-allowed'
                  }}
                >
                  ✅ تأكيد الإرجاع
                </button>
              </div>
            </div>
          </div>
        )}

        {/* نافذة إعدادات المزامنة */}
        {showSyncSettings && (
          <div style={{
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: 'rgba(0, 0, 0, 0.8)',
            zIndex: 9999,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            padding: '12px'
          }}>
            <div style={{
              backgroundColor: 'white',
              borderRadius: '15px',
              padding: '30px',
              width: '90%',
              maxWidth: '600px',
              position: 'relative',
              maxHeight: '90vh',
              overflow: 'auto'
            }}>
              {/* رأس النافذة */}
              <div style={{
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                marginBottom: '25px',
                borderBottom: '2px solid #3498db',
                paddingBottom: '15px'
              }}>
                <h2 style={{
                  color: '#2c5aa0',
                  margin: 0,
                  fontSize: '24px',
                  fontWeight: 'bold'
                }}>
                  ⚙️ إعدادات المزامنة
                </h2>
                <button
                  onClick={() => setShowSyncSettings(false)}
                  style={{
                    backgroundColor: '#e74c3c',
                    color: 'white',
                    border: 'none',
                    padding: '10px 15px',
                    borderRadius: '6px',
                    cursor: 'pointer',
                    fontSize: '10px',
                    fontWeight: 'bold'
                  }}
                >
                  ✖️ إغلاق
                </button>
              </div>

              {/* تفعيل/تعطيل المزامنة */}
              <div style={{
                backgroundColor: '#f8f9fa',
                padding: '12px',
                borderRadius: '4px',
                border: '1px solid #ddd',
                marginBottom: '20px'
              }}>
                <h3 style={{ color: '#2c5aa0', marginBottom: '15px' }}>🔄 تفعيل المزامنة</h3>
                <label style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '15px',
                  cursor: 'pointer',
                  fontSize: '16px',
                  fontWeight: 'bold'
                }}>
                  <input
                    type="checkbox"
                    checked={syncSettings.enabled}
                    onChange={(e) => setSyncSettings(prev => ({ ...prev, enabled: e.target.checked }))}
                    style={{
                      width: '20px',
                      height: '15px',
                      cursor: 'pointer'
                    }}
                  />
                  <span style={{ color: syncSettings.enabled ? '#27ae60' : '#e74c3c' }}>
                    {syncSettings.enabled ? '✅ المزامنة مفعلة' : '❌ المزامنة معطلة'}
                  </span>
                </label>
                <div style={{ fontSize: '14px', color: '#666', marginTop: '10px' }}>
                  عند التفعيل، سيتم مشاركة البيانات مع الأجهزة الأخرى عبر الشبكة المحلية
                </div>
              </div>

              {/* إعدادات الخادم */}
              <div style={{
                backgroundColor: '#f8f9fa',
                padding: '12px',
                borderRadius: '4px',
                border: '1px solid #ddd',
                marginBottom: '20px'
              }}>
                <h3 style={{ color: '#2c5aa0', marginBottom: '15px' }}>🖥️ إعدادات الخادم</h3>
                
                <div style={{ marginBottom: '15px' }}>
                  <label style={{ display: 'block', marginBottom: '8px', fontWeight: 'bold' }}>
                    عنوان الخادم (URL):
                  </label>
                  <input
                    type="text"
                    value={syncSettings.serverUrl}
                    onChange={(e) => setSyncSettings(prev => ({ ...prev, serverUrl: e.target.value }))}
                    style={{
                      width: '100%',
                      padding: '12px',
                      border: '2px solid #ddd',
                      borderRadius: '6px',
                      fontSize: '14px'
                    }}
                    placeholder="http://192.168.1.100:5000"
                  />
                  <div style={{ fontSize: '12px', color: '#666', marginTop: '5px' }}>
                    مثال: http://192.168.1.100:5000 (عنوان IP للجهاز الرئيسي في الشبكة المحلية)
                  </div>
                </div>

                <div style={{ marginBottom: '15px' }}>
                  <label style={{ display: 'block', marginBottom: '8px', fontWeight: 'bold' }}>
                    اسم هذا الجهاز:
                  </label>
                  <input
                    type="text"
                    value={syncSettings.deviceName}
                    onChange={(e) => setSyncSettings(prev => ({ ...prev, deviceName: e.target.value }))}
                    style={{
                      width: '100%',
                      padding: '12px',
                      border: '2px solid #ddd',
                      borderRadius: '6px',
                      fontSize: '14px'
                    }}
                    placeholder="كاشيير 1"
                  />
                  <div style={{ fontSize: '12px', color: '#666', marginTop: '5px' }}>
                    اسم مميز لهذا الجهاز ليظهر للأجهزة الأخرى
                  </div>
                </div>

                <div style={{ marginBottom: '15px' }}>
                  <label style={{ display: 'block', marginBottom: '8px', fontWeight: 'bold' }}>
                    🔐 مفتاح المزامنة الآمن:
                  </label>
                  <input
                    type="password"
                    value={syncSettings.syncToken}
                    onChange={(e) => setSyncSettings(prev => ({ ...prev, syncToken: e.target.value }))}
                    style={{
                      width: '100%',
                      padding: '12px',
                      border: '2px solid #ddd',
                      borderRadius: '6px',
                      fontSize: '14px'
                    }}
                    placeholder="أدخل مفتاح المزامنة الآمن"
                  />
                  <div style={{ fontSize: '12px', color: '#666', marginTop: '5px' }}>
                    مفتاح سري للحماية من الوصول غير المصرح به. يجب أن يكون نفس المفتاح على جميع الأجهزة
                  </div>
                </div>
              </div>

              {/* إعدادات المزامنة التلقائية */}
              <div style={{
                backgroundColor: '#f8f9fa',
                padding: '12px',
                borderRadius: '4px',
                border: '1px solid #ddd',
                marginBottom: '20px'
              }}>
                <h3 style={{ color: '#2c5aa0', marginBottom: '15px' }}>⚡ المزامنة التلقائية</h3>
                
                <label style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '10px',
                  cursor: 'pointer',
                  marginBottom: '15px'
                }}>
                  <input
                    type="checkbox"
                    checked={syncSettings.autoSync}
                    onChange={(e) => setSyncSettings(prev => ({ ...prev, autoSync: e.target.checked }))}
                    style={{
                      width: '18px',
                      height: '18px',
                      cursor: 'pointer'
                    }}
                  />
                  <span style={{ fontWeight: 'bold' }}>تفعيل المزامنة التلقائية</span>
                </label>

                <div style={{ marginBottom: '15px' }}>
                  <label style={{ display: 'block', marginBottom: '8px', fontWeight: 'bold' }}>
                    فترة المزامنة (ثانية):
                  </label>
                  <select
                    value={syncSettings.syncInterval}
                    onChange={(e) => setSyncSettings(prev => ({ ...prev, syncInterval: parseInt(e.target.value) }))}
                    style={{
                      width: '100%',
                      padding: '12px',
                      border: '2px solid #ddd',
                      borderRadius: '6px',
                      fontSize: '14px'
                    }}
                  >
                    <option value={10000}>كل 10 ثوان</option>
                    <option value={30000}>كل 30 ثانية</option>
                    <option value={60000}>كل دقيقة</option>
                    <option value={300000}>كل 5 دقائق</option>
                    <option value={600000}>كل 10 دقائق</option>
                  </select>
                </div>
              </div>

              {/* اختبار الاتصال */}
              <div style={{
                backgroundColor: '#f8f9fa',
                padding: '12px',
                borderRadius: '4px',
                border: '1px solid #ddd',
                marginBottom: '20px'
              }}>
                <h3 style={{ color: '#2c5aa0', marginBottom: '15px' }}>🔍 اختبار الاتصال</h3>
                
                <button
                  onClick={async () => {
                    if (!syncSettings.serverUrl) {
                      alert('يرجى إدخال عنوان الخادم أولاً')
                      return
                    }
                    
                    try {
                      setSyncMessage('جارٍ اختبار الاتصال...')
                      setSyncStatus('syncing')
                      
                      const response = await fetch(`${syncSettings.serverUrl.replace(/\/$/, '')}/api/health`)
                      if (response.ok) {
                        setSyncMessage('✅ الاتصال ناجح!')
                        setSyncStatus('success')
                      } else {
                        setSyncMessage('❌ فشل الاتصال')
                        setSyncStatus('error')
                      }
                    } catch (error) {
                      setSyncMessage(`❌ خطأ في الاتصال: ${error.message}`)
                      setSyncStatus('error')
                    }
                    
                    setTimeout(() => {
                      setSyncStatus('idle')
                      setSyncMessage('')
                    }, 3000)
                  }}
                  disabled={!syncSettings.serverUrl || syncStatus === 'syncing'}
                  style={{
                    backgroundColor: syncSettings.serverUrl && syncStatus !== 'syncing' ? '#3498db' : '#bdc3c7',
                    color: 'white',
                    border: 'none',
                    padding: '12px 20px',
                    borderRadius: '6px',
                    cursor: syncSettings.serverUrl && syncStatus !== 'syncing' ? 'pointer' : 'not-allowed',
                    fontWeight: 'bold',
                    fontSize: '10px',
                    width: '100%'
                  }}
                >
                  {syncStatus === 'syncing' ? '🔄 جارٍ الاختبار...' : '🔍 اختبار الاتصال'}
                </button>
                
                {syncMessage && (
                  <div style={{
                    marginTop: '10px',
                    padding: '10px',
                    borderRadius: '4px',
                    backgroundColor: 
                      syncStatus === 'success' ? '#d4edda' :
                      syncStatus === 'error' ? '#f8d7da' : '#fff3cd',
                    color:
                      syncStatus === 'success' ? '#155724' :
                      syncStatus === 'error' ? '#721c24' : '#856404',
                    fontSize: '10px',
                    fontWeight: 'bold'
                  }}>
                    {syncMessage}
                  </div>
                )}
              </div>

              {/* أزرار التحكم */}
              <div style={{
                display: 'flex',
                gap: '15px',
                justifyContent: 'center'
              }}>
                <button
                  onClick={() => {
                    alert('تم حفظ الإعدادات بنجاح!')
                    setShowSyncSettings(false)
                  }}
                  style={{
                    backgroundColor: '#27ae60',
                    color: 'white',
                    border: 'none',
                    padding: '12px 25px',
                    borderRadius: '6px',
                    cursor: 'pointer',
                    fontWeight: 'bold',
                    fontSize: '16px'
                  }}
                >
                  ✅ حفظ الإعدادات
                </button>
                
                <button
                  onClick={() => setShowSyncSettings(false)}
                  style={{
                    backgroundColor: '#95a5a6',
                    color: 'white',
                    border: 'none',
                    padding: '12px 25px',
                    borderRadius: '6px',
                    cursor: 'pointer',
                    fontWeight: 'bold',
                    fontSize: '16px'
                  }}
                >
                  ❌ إلغاء
                </button>
              </div>

              {/* دليل الاستخدام */}
              <div style={{
                backgroundColor: '#e8f5ff',
                padding: '15px',
                borderRadius: '6px',
                border: '1px solid #3498db',
                marginTop: '20px',
                fontSize: '13px',
                color: '#2c5aa0'
              }}>
                <strong>📖 دليل الإعداد:</strong>
                <ol style={{ marginTop: '10px', paddingRight: '20px' }}>
                  <li>اختر جهازاً واحداً ليكون الخادم الرئيسي</li>
                  <li>على الجهاز الرئيسي: فعّل المزامنة واترك عنوان الخادم فارغاً</li>
                  <li>على الأجهزة الأخرى: ضع عنوان IP للجهاز الرئيسي مثل: http://192.168.1.100:5000</li>
                  <li>تأكد من أن جميع الأجهزة متصلة بنفس الشبكة المحلية</li>
                  <li>اختبر الاتصال قبل البدء</li>
                </ol>
              </div>

            </div>
          </div>
        )}

        {/* نافذة حل التعارض */}
        {syncConflicts.length > 0 && (
          <div style={{
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: 'rgba(0, 0, 0, 0.8)',
            zIndex: 10000,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            padding: '12px'
          }}>
            <div style={{
              backgroundColor: 'white',
              borderRadius: '15px',
              padding: '25px',
              width: '90%',
              maxWidth: '700px',
              maxHeight: '80vh',
              overflow: 'auto'
            }}>
              <h2 style={{ color: '#e74c3c', marginBottom: '20px' }}>
                ⚠️ تعارض في البيانات ({syncConflicts.length})
              </h2>
              
              {syncConflicts.map((conflict, index) => (
                <div key={index} style={{
                  backgroundColor: '#fff3cd',
                  padding: '15px',
                  borderRadius: '4px',
                  border: '1px solid #ffc107',
                  marginBottom: '15px'
                }}>
                  <h4 style={{ color: '#856404', marginBottom: '10px' }}>
                    {conflict.type === 'product' ? `منتج: ${conflict.barcode}` : `إعداد: ${conflict.key}`}
                  </h4>
                  
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px', marginBottom: '15px' }}>
                    <div style={{
                      backgroundColor: '#d1ecf1',
                      padding: '10px',
                      borderRadius: '4px',
                      border: '1px solid #b3d7dd'
                    }}>
                      <strong>البيانات المحلية:</strong>
                      <pre style={{ fontSize: '12px', margin: '5px 0' }}>
                        {JSON.stringify(conflict.local, null, 2)}
                      </pre>
                    </div>
                    
                    <div style={{
                      backgroundColor: '#f8d7da',
                      padding: '10px',
                      borderRadius: '4px',
                      border: '1px solid #f5c6cb'
                    }}>
                      <strong>بيانات الخادم:</strong>
                      <pre style={{ fontSize: '12px', margin: '5px 0' }}>
                        {JSON.stringify(conflict.server, null, 2)}
                      </pre>
                    </div>
                  </div>
                  
                  <div style={{ display: 'flex', gap: '10px' }}>
                    <button
                      onClick={() => resolveConflict(conflict, 'local')}
                      style={{
                        backgroundColor: '#17a2b8',
                        color: 'white',
                        border: 'none',
                        padding: '8px 15px',
                        borderRadius: '4px',
                        cursor: 'pointer',
                        fontSize: '14px'
                      }}
                    >
                      استخدام المحلي
                    </button>
                    
                    <button
                      onClick={() => resolveConflict(conflict, 'server')}
                      style={{
                        backgroundColor: '#dc3545',
                        color: 'white',
                        border: 'none',
                        padding: '8px 15px',
                        borderRadius: '4px',
                        cursor: 'pointer',
                        fontSize: '14px'
                      }}
                    >
                      استخدام الخادم
                    </button>
                  </div>
                </div>
              ))}
              
              <button
                onClick={() => setSyncConflicts([])}
                style={{
                  backgroundColor: '#6c757d',
                  color: 'white',
                  border: 'none',
                  padding: '10px 20px',
                  borderRadius: '6px',
                  cursor: 'pointer',
                  fontSize: '10px',
                  width: '100%'
                }}
              >
                إغلاق وتجاهل التعارضات
              </button>
            </div>
          </div>
        )}

        {/* نافذة تسجيل دخول المدير */}
        {showAdminLogin && (
          <div style={{
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: 'rgba(0, 0, 0, 0.7)',
            zIndex: 10000,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            padding: '12px'
          }}>
            <div style={{
              backgroundColor: 'white',
              borderRadius: '12px',
              padding: '30px',
              width: '100%',
              maxWidth: '400px',
              boxShadow: '0 10px 25px rgba(0, 0, 0, 0.2)'
            }}>
              <h2 style={{ 
                color: '#2c5aa0', 
                textAlign: 'center', 
                marginBottom: '25px',
                fontSize: '24px',
                fontWeight: 'bold'
              }}>
                🔐 تسجيل دخول المدير
              </h2>
              
              <div style={{ marginBottom: '20px' }}>
                <label style={{ 
                  display: 'block', 
                  marginBottom: '8px', 
                  fontWeight: 'bold',
                  color: '#333'
                }}>
                  اسم المستخدم:
                </label>
                <input
                  type="text"
                  value={adminLoginUsername}
                  onChange={(e) => setAdminLoginUsername(e.target.value)}
                  style={{
                    width: '100%',
                    padding: '12px',
                    border: '2px solid #ddd',
                    borderRadius: '4px',
                    fontSize: '16px',
                    boxSizing: 'border-box'
                  }}
                  placeholder="أدخل اسم المستخدم"
                  autoFocus
                />
              </div>
              
              <div style={{ marginBottom: '25px' }}>
                <label style={{ 
                  display: 'block', 
                  marginBottom: '8px', 
                  fontWeight: 'bold',
                  color: '#333'
                }}>
                  كلمة المرور:
                </label>
                <input
                  type="password"
                  value={adminPassword}
                  onChange={(e) => setAdminPassword(e.target.value)}
                  style={{
                    width: '100%',
                    padding: '12px',
                    border: '2px solid #ddd',
                    borderRadius: '4px',
                    fontSize: '16px',
                    boxSizing: 'border-box'
                  }}
                  placeholder="أدخل كلمة المرور"
                  onKeyPress={(e) => e.key === 'Enter' && loginAdmin()}
                />
              </div>
              
              <div style={{ display: 'flex', gap: '10px' }}>
                <button
                  onClick={loginAdmin}
                  style={{
                    flex: 1,
                    padding: '12px',
                    backgroundColor: '#2c5aa0',
                    color: 'white',
                    border: 'none',
                    borderRadius: '4px',
                    cursor: 'pointer',
                    fontWeight: 'bold',
                    fontSize: '16px'
                  }}
                >
                  🔑 تسجيل الدخول
                </button>
                
                <button
                  onClick={() => {
                    setShowAdminLogin(false);
                    setAdminPassword('');
                    setAdminLoginUsername('');
                  }}
                  style={{
                    flex: 1,
                    padding: '12px',
                    backgroundColor: '#95a5a6',
                    color: 'white',
                    border: 'none',
                    borderRadius: '4px',
                    cursor: 'pointer',
                    fontWeight: 'bold',
                    fontSize: '16px'
                  }}
                >
                  ❌ إلغاء
                </button>
              </div>
            </div>
          </div>
        )}

        {/* نافذة تسجيل دخول مدير التراخيص (منفصلة) */}
        {showLicenseManagerLogin && (
          <div style={{
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: 'rgba(0, 0, 0, 0.8)',
            zIndex: 11000,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            padding: '12px'
          }}>
            <div style={{
              backgroundColor: '#f8f9fa',
              borderRadius: '12px',
              padding: '30px',
              width: '100%',
              maxWidth: '400px',
              boxShadow: '0 10px 25px rgba(0, 0, 0, 0.3)',
              border: '3px solid #e74c3c'
            }}>
              <h2 style={{ 
                color: '#e74c3c', 
                textAlign: 'center', 
                marginBottom: '25px',
                fontSize: '24px',
                fontWeight: 'bold'
              }}>
                🔑 مدير إدارة التراخيص
              </h2>
              
              <div style={{ marginBottom: '15px', padding: '10px', backgroundColor: '#fff3cd', borderRadius: '6px', border: '1px solid #ffeaa7' }}>
                <small style={{ color: '#856404', fontSize: '12px' }}>
                  ⚠️ هذا النظام منفصل عن المدير العادي - مخصص لإنشاء وإدارة أكواد التفعيل
                </small>
              </div>
              
              <div style={{ marginBottom: '20px' }}>
                <label style={{ 
                  display: 'block', 
                  marginBottom: '8px', 
                  fontWeight: 'bold',
                  color: '#333'
                }}>
                  اسم مستخدم مدير التراخيص:
                </label>
                <input
                  type="text"
                  value={licenseManagerUsername}
                  onChange={(e) => setLicenseManagerUsername(e.target.value)}
                  style={{
                    width: '100%',
                    padding: '12px',
                    border: '2px solid #e74c3c',
                    borderRadius: '4px',
                    fontSize: '16px',
                    boxSizing: 'border-box'
                  }}
                  placeholder="أدخل اسم مستخدم مدير التراخيص"
                  autoFocus
                />
              </div>
              
              <div style={{ marginBottom: '25px' }}>
                <label style={{ 
                  display: 'block', 
                  marginBottom: '8px', 
                  fontWeight: 'bold',
                  color: '#333'
                }}>
                  كلمة مرور مدير التراخيص:
                </label>
                <input
                  type="password"
                  value={licenseManagerPassword}
                  onChange={(e) => setLicenseManagerPassword(e.target.value)}
                  style={{
                    width: '100%',
                    padding: '12px',
                    border: '2px solid #e74c3c',
                    borderRadius: '4px',
                    fontSize: '16px',
                    boxSizing: 'border-box'
                  }}
                  placeholder="أدخل كلمة مرور مدير التراخيص"
                  onKeyPress={(e) => {
                    if (e.key === 'Enter') {
                      loginLicenseManager()
                    }
                  }}
                />
              </div>
              
              <div style={{ 
                display: 'flex', 
                gap: '10px', 
                justifyContent: 'center' 
              }}>
                <button
                  onClick={loginLicenseManager}
                  style={{
                    backgroundColor: '#e74c3c',
                    color: 'white',
                    border: 'none',
                    padding: '12px 25px',
                    borderRadius: '4px',
                    fontSize: '16px',
                    fontWeight: 'bold',
                    cursor: 'pointer',
                    transition: 'background-color 0.3s'
                  }}
                  onMouseOver={(e) => e.target.style.backgroundColor = '#c0392b'}
                  onMouseOut={(e) => e.target.style.backgroundColor = '#e74c3c'}
                >
                  🔓 دخول إدارة التراخيص
                </button>
                <button
                  onClick={() => {
                    setShowLicenseManagerLogin(false)
                    setLicenseManagerUsername('')
                    setLicenseManagerPassword('')
                  }}
                  style={{
                    backgroundColor: '#6c757d',
                    color: 'white',
                    border: 'none',
                    padding: '12px 25px',
                    borderRadius: '4px',
                    fontSize: '16px',
                    fontWeight: 'bold',
                    cursor: 'pointer',
                    transition: 'background-color 0.3s'
                  }}
                  onMouseOver={(e) => e.target.style.backgroundColor = '#5a6268'}
                  onMouseOut={(e) => e.target.style.backgroundColor = '#6c757d'}
                >
                  ✖️ إلغاء
                </button>
              </div>
            </div>
          </div>
        )}
        
        {/* واجهة مدير التراخيص المنفصلة */}
        {activeTab === 'license-manager' && isLicenseManager && (
          <div style={{
            backgroundColor: 'white',
            borderRadius: '4px',
            padding: '12px'
          }}>
            <h2 style={{ color: '#2c5aa0', marginBottom: '20px' }}>🔑 لوحة إدارة التراخيص</h2>
            
            {/* شريط الإحصائيات */}
            <div style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
              gap: '15px',
              marginBottom: '15px'
            }}>
              <div style={{
                backgroundColor: '#3498db',
                color: 'white',
                padding: '12px',
                borderRadius: '4px',
                textAlign: 'center'
              }}>
                <h4 style={{ margin: '0 0 10px 0', fontSize: '16px' }}>إجمالي التراخيص</h4>
                <div style={{ fontSize: '24px', fontWeight: 'bold' }}>
                  {licenseManagementData.stats?.totalLicenses || 0}
                </div>
              </div>
              <div style={{
                backgroundColor: '#27ae60',
                color: 'white',
                padding: '12px',
                borderRadius: '4px',
                textAlign: 'center'
              }}>
                <h4 style={{ margin: '0 0 10px 0', fontSize: '16px' }}>التراخيص النشطة</h4>
                <div style={{ fontSize: '24px', fontWeight: 'bold' }}>
                  {licenseManagementData.stats?.activeLicenses || 0}
                </div>
              </div>
              <div style={{
                backgroundColor: '#e74c3c',
                color: 'white',
                padding: '12px',
                borderRadius: '4px',
                textAlign: 'center'
              }}>
                <h4 style={{ margin: '0 0 10px 0', fontSize: '16px' }}>التراخيص المنتهية</h4>
                <div style={{ fontSize: '24px', fontWeight: 'bold' }}>
                  {licenseManagementData.stats?.expiredLicenses || 0}
                </div>
              </div>
              <div style={{
                backgroundColor: '#f39c12',
                color: 'white',
                padding: '12px',
                borderRadius: '4px',
                textAlign: 'center'
              }}>
                <h4 style={{ margin: '0 0 10px 0', fontSize: '16px' }}>الإيرادات الشهرية</h4>
                <div style={{ fontSize: '24px', fontWeight: 'bold' }}>
                  {licenseManagementData.stats?.monthlyRevenue || 0} $
                </div>
              </div>
            </div>
            
            {/* أزرار الإجراءات السريعة */}
            <div style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
              gap: '10px',
              marginBottom: '15px'
            }}>
              <button
                onClick={() => setShowCustomerForm(true)}
                style={{
                  backgroundColor: '#3498db',
                  color: 'white',
                  border: 'none',
                  padding: '12px',
                  borderRadius: '4px',
                  cursor: 'pointer',
                  fontSize: '16px',
                  fontWeight: 'bold'
                }}
              >
                👥 إضافة عميل جديد
              </button>
              <button
                onClick={() => setShowLicenseForm(true)}
                style={{
                  backgroundColor: '#27ae60',
                  color: 'white',
                  border: 'none',
                  padding: '12px',
                  borderRadius: '4px',
                  cursor: 'pointer',
                  fontSize: '16px',
                  fontWeight: 'bold'
                }}
              >
                🔐 إصدار ترخيص جديد
              </button>
            </div>
            
            {/* قائمة العملاء */}
            <div style={{
              backgroundColor: '#f8f9fa',
              padding: '12px',
              borderRadius: '4px',
              marginBottom: '20px'
            }}>
              <h3 style={{ color: '#2c5aa0', marginBottom: '15px' }}>👥 قائمة العملاء</h3>
              {licenseManagementData.customers && licenseManagementData.customers.length > 0 ? (
                <div style={{
                  display: 'grid',
                  gap: '10px'
                }}>
                  {licenseManagementData.customers.map((customer: any, index: number) => (
                    <div key={index} style={{
                      backgroundColor: 'white',
                      padding: '15px',
                      borderRadius: '6px',
                      border: '1px solid #ddd',
                      display: 'flex',
                      justifyContent: 'space-between',
                      alignItems: 'center'
                    }}>
                      <div>
                        <strong>{customer.companyName || 'بدون اسم'}</strong>
                        <br />
                        <small style={{ color: '#666' }}>
                          {customer.email || customer.contactEmail || 'بدون إيميل'}
                        </small>
                        <br />
                        <small style={{ color: '#999', fontSize: '11px' }}>
                          المسؤول: {customer.contactPerson || 'غير محدد'}
                        </small>
                      </div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                        <div style={{
                          backgroundColor: customer.isActive ? '#27ae60' : '#e74c3c',
                          color: 'white',
                          padding: '2px 6px',
                          borderRadius: '4px',
                          fontSize: '12px'
                        }}>
                          {customer.isActive ? 'نشط' : 'غير نشط'}
                        </div>
                        <button
                          onClick={() => deleteCustomer(customer.id, customer.companyName || 'عميل بدون اسم')}
                          style={{
                            backgroundColor: '#e74c3c',
                            color: 'white',
                            border: 'none',
                            padding: '6px 8px',
                            borderRadius: '4px',
                            cursor: 'pointer',
                            fontSize: '10px',
                            fontWeight: 'bold',
                            transition: 'background-color 0.3s'
                          }}
                          title="حذف العميل"
                          onMouseEnter={(e) => e.target.style.backgroundColor = '#c0392b'}
                          onMouseLeave={(e) => e.target.style.backgroundColor = '#e74c3c'}
                        >
                          🗑️ حذف
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div style={{
                  textAlign: 'center',
                  color: '#666',
                  padding: '12px'
                }}>
                  لا توجد عملاء مسجلين حتى الآن
                </div>
              )}
            </div>
            
            {/* قائمة التراخيص */}
            <div style={{
              backgroundColor: '#f0f7ff',
              padding: '12px',
              borderRadius: '4px',
              border: '2px solid #3498db'
            }}>
              <h3 style={{ color: '#2c5aa0', marginBottom: '15px' }}>🔐 التراخيص النشطة</h3>
              {licenseManagementData.licenses && licenseManagementData.licenses.length > 0 ? (
                <div style={{
                  display: 'grid',
                  gap: '10px'
                }}>
                  {licenseManagementData.licenses.slice(0, 5).map((license: any, index: number) => {
                    // البحث عن اسم العميل من قائمة العملاء
                    const customer = licenseManagementData.customers?.find((c: any) => c.id === license.customerId);
                    const customerName = customer?.companyName || 'عميل غير محدد';
                    const contactPerson = customer?.contactPerson;
                    
                    // تنسيق تاريخ الانتهاء - استخدام البيانات الموجودة
                    let expiryDate = 'غير محدد';
                    if (license.expiryDate) {
                      expiryDate = new Date(license.expiryDate).toLocaleDateString('ar-LB');
                    } else if (license.validUntil) {
                      expiryDate = license.validUntil;
                    }
                    
                    // تحديد حالة الترخيص - استخدام البيانات الموجودة
                    let isLicenseActive = false;
                    let statusText = '❌ منتهي';
                    
                    if (license.status) {
                      // إذا كان هناك status جاهز من الخادم
                      isLicenseActive = license.status === 'active';
                      statusText = isLicenseActive ? '✅ نشط' : '❌ منتهي';
                    } else if (license.isActive !== undefined) {
                      // إذا كانت هناك بيانات isActive
                      const hasValidDate = license.expiryDate ? (new Date() < new Date(license.expiryDate)) : true;
                      isLicenseActive = license.isActive && !license.isRevoked && hasValidDate;
                      statusText = isLicenseActive ? '✅ نشط' : '❌ منتهي';
                    }
                    
                    return (
                    <div key={index} style={{
                      backgroundColor: 'white',
                      padding: '15px',
                      borderRadius: '6px',
                      border: '1px solid #3498db',
                      display: 'flex',
                      justifyContent: 'space-between',
                      alignItems: 'center'
                    }}>
                      <div>
                        <strong style={{ color: '#2c5aa0' }}>
                          {license.licenseKey ? license.licenseKey.substring(0, 20) + '...' : 'غير محدد'}
                        </strong>
                        <br />
                        <small style={{ color: '#666' }}>
                          🏢 {customerName}
                          {contactPerson && <span> | 👤 {contactPerson}</span>}
                        </small>
                        <br />
                        <small style={{ color: '#999' }}>
                          ⏰ صالح حتى: {expiryDate}
                        </small>
                      </div>
                      <div style={{
                        backgroundColor: isLicenseActive ? '#27ae60' : '#e74c3c',
                        color: 'white',
                        padding: '2px 6px',
                        borderRadius: '4px',
                        fontSize: '12px'
                      }}>
                        {statusText}
                      </div>
                    </div>
                    )
                  })}
                </div>
              ) : (
                <div style={{
                  textAlign: 'center',
                  color: '#666',
                  padding: '12px'
                }}>
                  لا توجد تراخيص صادرة حتى الآن
                </div>
              )}
            </div>
            
            {/* رسالة ترحيبية */}
            <div style={{
              backgroundColor: '#d4edda',
              color: '#155724',
              padding: '15px',
              borderRadius: '6px',
              marginTop: '20px',
              textAlign: 'center'
            }}>
              🎉 أهلاً بك في لوحة إدارة التراخيص! يمكنك إدارة العملاء وإصدار التراخيص من هنا
            </div>
          </div>
        )}
        
        {/* نموذج إضافة عميل جديد */}
        {showCustomerForm && (
          <div style={{
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: 'rgba(0,0,0,0.5)',
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            zIndex: 1000
          }}>
            <div style={{
              backgroundColor: 'white',
              padding: '30px',
              borderRadius: '10px',
              minWidth: '500px',
              maxWidth: '600px'
            }}>
              <h3 style={{ color: '#2c5aa0', marginBottom: '20px', textAlign: 'center' }}>
                👥 إضافة عميل جديد
              </h3>
              
              <div style={{ display: 'grid', gap: '15px' }}>
                <div>
                  <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
                    اسم الشركة *
                  </label>
                  <input 
                    type="text"
                    value={newStoreName}
                    onChange={(e) => setNewStoreName(e.target.value)}
                    style={{
                      width: '100%',
                      padding: '10px',
                      border: '1px solid #ddd',
                      borderRadius: '4px',
                      fontSize: '16px'
                    }}
                    placeholder="أدخل اسم الشركة"
                  />
                </div>
                
                <div>
                  <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
                    اسم المسؤول *
                  </label>
                  <input 
                    type="text"
                    value={newAdminUsername}
                    onChange={(e) => setNewAdminUsername(e.target.value)}
                    style={{
                      width: '100%',
                      padding: '10px',
                      border: '1px solid #ddd',
                      borderRadius: '4px',
                      fontSize: '16px'
                    }}
                    placeholder="أدخل اسم المسؤول"
                  />
                </div>
                
                <div>
                  <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
                    البريد الإلكتروني (اختياري)
                  </label>
                  <input 
                    type="email"
                    value={newAdminPassword}
                    onChange={(e) => setNewAdminPassword(e.target.value)}
                    style={{
                      width: '100%',
                      padding: '10px',
                      border: '1px solid #ddd',
                      borderRadius: '4px',
                      fontSize: '16px'
                    }}
                    placeholder="أدخل البريد الإلكتروني"
                  />
                </div>
                
                <div style={{ 
                  display: 'flex', 
                  gap: '10px', 
                  justifyContent: 'center',
                  marginTop: '20px'
                }}>
                  <button
                    onClick={async () => {
                      if (!newStoreName || !newAdminUsername) {
                        alert('يرجى ملء البيانات الأساسية')
                        return
                      }
                      
                      const customerData = {
                        companyName: newStoreName,
                        contactPerson: newAdminUsername,
                        email: newAdminPassword || null, // البريد اختياري
                        isActive: true
                      }
                      
                      // تحديد نوع المدير وإستدعاء الدالة المناسبة
                      const adminAuth = sessionStorage.getItem('adminAuth');
                      const licenseManagerAuth = sessionStorage.getItem('licenseManagerAuth');
                      
                      let success = false;
                      if (licenseManagerAuth) {
                        success = await createNewCustomerForLicenseManager(customerData)
                      } else if (adminAuth) {
                        success = await createNewCustomer(customerData)
                      } else {
                        alert('يجب تسجيل الدخول أولاً');
                        return;
                      }
                      if (success) {
                        setShowCustomerForm(false)
                        setNewStoreName('')
                        setNewAdminUsername('')
                        setNewAdminPassword('')
                        alert('تم إضافة العميل بنجاح!')
                      }
                    }}
                    style={{
                      backgroundColor: '#3498db',
                      color: 'white',
                      border: 'none',
                      padding: '12px 25px',
                      borderRadius: '6px',
                      cursor: 'pointer',
                      fontSize: '16px',
                      fontWeight: 'bold'
                    }}
                  >
                    ✅ إضافة العميل
                  </button>
                  
                  <button
                    onClick={() => {
                      setShowCustomerForm(false)
                      setNewStoreName('')
                      setNewAdminUsername('')
                      setNewAdminPassword('')
                    }}
                    style={{
                      backgroundColor: '#e74c3c',
                      color: 'white',
                      border: 'none',
                      padding: '12px 25px',
                      borderRadius: '6px',
                      cursor: 'pointer',
                      fontSize: '16px',
                      fontWeight: 'bold'
                    }}
                  >
                    ❌ إلغاء
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
        
        {/* نموذج إصدار ترخيص جديد */}
        {showLicenseForm && (
          <div style={{
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: 'rgba(0,0,0,0.5)',
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            zIndex: 1000
          }}>
            <div style={{
              backgroundColor: 'white',
              padding: '30px',
              borderRadius: '10px',
              minWidth: '500px',
              maxWidth: '600px'
            }}>
              <h3 style={{ color: '#2c5aa0', marginBottom: '20px', textAlign: 'center' }}>
                🔐 إصدار ترخيص جديد
              </h3>
              
              <div style={{ display: 'grid', gap: '15px' }}>
                <div>
                  <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
                    اختر العميل *
                  </label>
                  <select 
                    value={newStoreName}
                    onChange={(e) => setNewStoreName(e.target.value)}
                    style={{
                      width: '100%',
                      padding: '10px',
                      border: '1px solid #ddd',
                      borderRadius: '4px',
                      fontSize: '16px'
                    }}
                  >
                    <option value="">اختر العميل</option>
                    {licenseManagementData.customers && licenseManagementData.customers.map((customer: any, index: number) => (
                      <option key={index} value={customer.id || customer.companyName}>
                        {customer.companyName}
                      </option>
                    ))}
                  </select>
                </div>
                
                <div>
                  <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
                    نوع الترخيص *
                  </label>
                  <select 
                    value={newLicenseKey}
                    onChange={(e) => setNewLicenseKey(e.target.value)}
                    style={{
                      width: '100%',
                      padding: '10px',
                      border: '1px solid #ddd',
                      borderRadius: '4px',
                      fontSize: '16px'
                    }}
                  >
                    <option value="">اختر نوع الترخيص</option>
                    <option value="basic">أساسي - شهر واحد</option>
                    <option value="premium">مميز - 6 أشهر</option>
                    <option value="enterprise">متقدم - سنة كاملة</option>
                  </select>
                </div>
                
                <div style={{
                  backgroundColor: '#f0f7ff',
                  padding: '15px',
                  borderRadius: '6px',
                  border: '1px solid #3498db'
                }}>
                  <strong style={{ color: '#2c5aa0' }}>ملاحظة:</strong>
                  <p style={{ margin: '5px 0 0 0', fontSize: '14px', color: '#666' }}>
                    سيتم إنشاء مفتاح ترخيص فريد تلقائياً للعميل المحدد. 
                    تأكد من اختيار العميل ونوع الترخيص المناسب.
                  </p>
                </div>
                
                <div style={{ 
                  display: 'flex', 
                  gap: '10px', 
                  justifyContent: 'center',
                  marginTop: '20px'
                }}>
                  <button
                    onClick={async () => {
                      if (!newStoreName || !newLicenseKey) {
                        alert('يرجى اختيار العميل ونوع الترخيص')
                        return
                      }
                      
                      const success = await generateLicenseForManager(newStoreName, newLicenseKey)
                      if (success) {
                        setShowLicenseForm(false)
                        setNewStoreName('')
                        setNewLicenseKey('')
                      }
                    }}
                    style={{
                      backgroundColor: '#27ae60',
                      color: 'white',
                      border: 'none',
                      padding: '12px 25px',
                      borderRadius: '6px',
                      cursor: 'pointer',
                      fontSize: '16px',
                      fontWeight: 'bold'
                    }}
                  >
                    🔐 إصدار الترخيص
                  </button>
                  
                  <button
                    onClick={() => {
                      setShowLicenseForm(false)
                      setNewStoreName('')
                      setNewLicenseKey('')
                    }}
                    style={{
                      backgroundColor: '#e74c3c',
                      color: 'white',
                      border: 'none',
                      padding: '12px 25px',
                      borderRadius: '6px',
                      cursor: 'pointer',
                      fontSize: '16px',
                      fontWeight: 'bold'
                    }}
                  >
                    ❌ إلغاء
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

export default App