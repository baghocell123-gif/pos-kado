import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { licenseStorage } from './storage.js';
import crypto from 'crypto';
import bcrypt from 'bcryptjs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;
const isDev = process.env.NODE_ENV === 'development';

// Admin credentials - يجب تعيينها في متغيرات البيئة فقط
const ADMIN_USERNAME = process.env.ADMIN_USERNAME;
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD;

// License Manager credentials - منفصل عن المدير العادي
const LICENSE_MANAGER_USERNAME = process.env.LICENSE_MANAGER_USERNAME;
const LICENSE_MANAGER_PASSWORD = process.env.LICENSE_MANAGER_PASSWORD;

if (!ADMIN_USERNAME || !ADMIN_PASSWORD) {
  console.error('⚠️  خطأ: يجب تعيين ADMIN_USERNAME و ADMIN_PASSWORD في متغيرات البيئة للأمان');
  process.exit(1);
}

if (!LICENSE_MANAGER_USERNAME || !LICENSE_MANAGER_PASSWORD) {
  console.error('⚠️  خطأ: يجب تعيين LICENSE_MANAGER_USERNAME و LICENSE_MANAGER_PASSWORD في متغيرات البيئة للأمان');
  process.exit(1);
}

// === تحسينات الأمان ===
// تشفير كلمات المرور عند بدء الخادم (مرة واحدة فقط)
let ADMIN_PASSWORD_HASH: string;
let LICENSE_MANAGER_PASSWORD_HASH: string;

const initializePasswordHashes = async () => {
  const saltRounds = 12; // مستوى تشفير عالي
  
  try {
    ADMIN_PASSWORD_HASH = await bcrypt.hash(ADMIN_PASSWORD, saltRounds);
    LICENSE_MANAGER_PASSWORD_HASH = await bcrypt.hash(LICENSE_MANAGER_PASSWORD, saltRounds);
    console.log('🔐 تم تشفير كلمات مرور الإدارة بنجاح');
  } catch (error) {
    console.error('❌ فشل تشفير كلمات مرور الإدارة:', error);
    process.exit(1);
  }
};

// Basic middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// إضافة headers أمان إضافية
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('X-XSS-Protection', '1; mode=block');
  next();
});

// Middleware للتحقق من صحة admin (مع تشفير آمن)
const requireAdmin = async (req: express.Request, res: express.Response, next: express.NextFunction) => {
  const authHeader = req.headers.authorization;
  
  if (!authHeader || !authHeader.startsWith('Basic ')) {
    return res.status(401).json({ error: 'مطلوب مصادقة المسؤول' });
  }
  
  const base64Credentials = authHeader.split(' ')[1];
  const credentials = Buffer.from(base64Credentials, 'base64').toString('ascii');
  const [username, password] = credentials.split(':');
  
  // التحقق الآمن من اسم المستخدم وكلمة المرور
  const usernameMatch = username === ADMIN_USERNAME;
  const passwordMatch = ADMIN_PASSWORD_HASH ? await bcrypt.compare(password, ADMIN_PASSWORD_HASH) : false;
  
  if (!usernameMatch || !passwordMatch) {
    return res.status(401).json({ error: 'بيانات المسؤول غير صحيحة' });
  }
  
  next();
};

// Middleware للتحقق من صحة مدير التراخيص (مع تشفير آمن)
const requireLicenseManager = async (req: express.Request, res: express.Response, next: express.NextFunction) => {
  const authHeader = req.headers.authorization;
  
  if (!authHeader || !authHeader.startsWith('Basic ')) {
    return res.status(401).json({ error: 'مطلوب مصادقة مدير التراخيص' });
  }
  
  const base64Credentials = authHeader.split(' ')[1];
  const credentials = Buffer.from(base64Credentials, 'base64').toString('ascii');
  const [username, password] = credentials.split(':');
  
  // التحقق الآمن من اسم المستخدم وكلمة المرور
  const usernameMatch = username === LICENSE_MANAGER_USERNAME;
  const passwordMatch = LICENSE_MANAGER_PASSWORD_HASH ? await bcrypt.compare(password, LICENSE_MANAGER_PASSWORD_HASH) : false;
  
  if (!usernameMatch || !passwordMatch) {
    return res.status(401).json({ error: 'بيانات مدير التراخيص غير صحيحة' });
  }
  
  next();
};

// دالة مساعدة لتوليد device fingerprint
const generateDeviceFingerprint = (req: express.Request) => {
  const userAgent = req.headers['user-agent'] || '';
  const ip = req.ip || req.connection.remoteAddress || '';
  const acceptLanguage = req.headers['accept-language'] || '';
  
  return crypto
    .createHash('sha256')
    .update(`${userAgent}${ip}${acceptLanguage}`)
    .digest('hex');
};

// === مسارات الصحة والتشخيص ===
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// === APIs الإدارة والمصادقة ===

// خريطة محاولات تسجيل الدخول الفاشلة لـ rate limiting
const loginAttempts = new Map<string, { count: number; lastAttempt: Date }>();

// خريطة منفصلة لمحاولات تسجيل دخول الموظفين
const employeeLoginAttempts = new Map<string, { count: number; lastAttempt: Date }>();

// تسجيل دخول آمن للمدير مع rate limiting وتشفير آمن
app.post('/api/admin/login', async (req, res) => {
  const { username, password } = req.body;
  const clientIP = req.ip || req.connection.remoteAddress || 'unknown';
  
  if (!username || !password) {
    return res.status(400).json({ error: 'اسم المستخدم وكلمة المرور مطلوبان' });
  }
  
  // فحص rate limiting
  const attempts = loginAttempts.get(clientIP) || { count: 0, lastAttempt: new Date() };
  const now = new Date();
  
  // إعادة تعيين العداد بعد 15 دقيقة
  if (now.getTime() - attempts.lastAttempt.getTime() > 15 * 60 * 1000) {
    attempts.count = 0;
  }
  
  // منع الهجمات إذا كان هناك أكثر من 5 محاولات فاشلة
  if (attempts.count >= 5) {
    const timeLeft = Math.ceil((15 * 60 * 1000 - (now.getTime() - attempts.lastAttempt.getTime())) / 1000 / 60);
    return res.status(429).json({ 
      error: `محاولات تسجيل دخول كثيرة. حاول مرة أخرى بعد ${timeLeft} دقيقة`
    });
  }
  
  // مقارنة آمنة مع تشفير bcrypt
  const usernameMatch = username === ADMIN_USERNAME;
  const passwordMatch = ADMIN_PASSWORD_HASH ? await bcrypt.compare(password, ADMIN_PASSWORD_HASH) : false;
  
  if (usernameMatch && passwordMatch) {
    // إزالة محاولات فاشلة عند نجاح تسجيل الدخول
    loginAttempts.delete(clientIP);
    res.json({ success: true, message: 'تم تسجيل الدخول بنجاح' });
  } else {
    // تسجيل المحاولة الفاشلة
    attempts.count++;
    attempts.lastAttempt = now;
    loginAttempts.set(clientIP, attempts);
    
    console.warn(`محاولة تسجيل دخول فاشلة من ${clientIP}. المحاولة رقم ${attempts.count}`);
    res.status(401).json({ error: 'اسم المستخدم أو كلمة المرور غير صحيحة' });
  }
});

// تسجيل دخول آمن لمدير التراخيص (منفصل عن المدير العادي) مع تشفير آمن
app.post('/api/license-manager/login', async (req, res) => {
  const { username, password } = req.body;
  const clientIP = req.ip || req.connection.remoteAddress || 'unknown';
  
  if (!username || !password) {
    return res.status(400).json({ error: 'اسم المستخدم وكلمة المرور مطلوبان' });
  }
  
  // فحص rate limiting (نفس النظام للمدير العادي)
  const attempts = loginAttempts.get(clientIP) || { count: 0, lastAttempt: new Date() };
  const now = new Date();
  
  // إعادة تعيين العداد بعد 15 دقيقة
  if (now.getTime() - attempts.lastAttempt.getTime() > 15 * 60 * 1000) {
    attempts.count = 0;
  }
  
  // منع الهجمات إذا كان هناك أكثر من 5 محاولات فاشلة
  if (attempts.count >= 5) {
    const timeLeft = Math.ceil((15 * 60 * 1000 - (now.getTime() - attempts.lastAttempt.getTime())) / 1000 / 60);
    return res.status(429).json({ 
      error: `محاولات تسجيل دخول كثيرة. حاول مرة أخرى بعد ${timeLeft} دقيقة`
    });
  }
  
  // مقارنة آمنة مع تشفير bcrypt لبيانات مدير التراخيص
  const usernameMatch = username === LICENSE_MANAGER_USERNAME;
  const passwordMatch = LICENSE_MANAGER_PASSWORD_HASH ? await bcrypt.compare(password, LICENSE_MANAGER_PASSWORD_HASH) : false;
  
  if (usernameMatch && passwordMatch) {
    // إزالة محاولات فاشلة عند نجاح تسجيل الدخول
    loginAttempts.delete(clientIP);
    res.json({ success: true, message: 'تم تسجيل الدخول بنجاح كمدير تراخيص' });
  } else {
    // تسجيل المحاولة الفاشلة
    attempts.count++;
    attempts.lastAttempt = now;
    loginAttempts.set(clientIP, attempts);
    
    console.warn(`محاولة تسجيل دخول فاشلة لمدير التراخيص من ${clientIP}. المحاولة رقم ${attempts.count}`);
    res.status(401).json({ error: 'اسم المستخدم أو كلمة المرور غير صحيحة لمدير التراخيص' });
  }
});

// === APIs الموظفين ===

// تسجيل دخول موظف
app.post('/api/employees/login', async (req, res) => {
  const { username, password } = req.body;
  const clientIP = req.ip || req.connection.remoteAddress || 'unknown';

  if (!username || !password) {
    return res.status(400).json({ error: 'اسم المستخدم وكلمة المرور مطلوبان' });
  }

  // فحص rate limiting للموظفين (منفصل عن المدراء)
  const attempts = employeeLoginAttempts.get(clientIP) || { count: 0, lastAttempt: new Date() };
  const now = new Date();

  // إعادة تعيين العداد بعد 15 دقيقة
  if (now.getTime() - attempts.lastAttempt.getTime() > 15 * 60 * 1000) {
    attempts.count = 0;
  }

  // منع الهجمات إذا كان هناك أكثر من 5 محاولات فاشلة
  if (attempts.count >= 5) {
    const timeLeft = Math.ceil((15 * 60 * 1000 - (now.getTime() - attempts.lastAttempt.getTime())) / 1000 / 60);
    return res.status(429).json({ 
      error: `محاولات تسجيل دخول كثيرة. حاول مرة أخرى بعد ${timeLeft} دقيقة`
    });
  }

  try {
    // البحث عن الموظف
    const employee = await licenseStorage.getEmployeeByUsername(username);
    
    if (!employee) {
      // تسجيل المحاولة الفاشلة
      attempts.count++;
      attempts.lastAttempt = now;
      employeeLoginAttempts.set(clientIP, attempts);
      
      console.warn(`محاولة تسجيل دخول فاشلة للموظف من ${clientIP} - اسم المستخدم غير موجود: ${username}`);
      return res.status(401).json({ error: 'اسم المستخدم أو كلمة المرور غير صحيحة' });
    }

    // التحقق من أن الموظف نشط
    if (!employee.isActive) {
      console.warn(`محاولة تسجيل دخول موظف غير نشط من ${clientIP}: ${username}`);
      return res.status(401).json({ error: 'حساب الموظف غير نشط. يرجى الاتصال بالمدير' });
    }

    // التحقق من كلمة المرور
    const passwordMatch = await bcrypt.compare(password, employee.passwordHash);
    
    if (!passwordMatch) {
      // تسجيل المحاولة الفاشلة
      attempts.count++;
      attempts.lastAttempt = now;
      employeeLoginAttempts.set(clientIP, attempts);
      
      console.warn(`محاولة تسجيل دخول فاشلة للموظف من ${clientIP} - كلمة مرور خاطئة: ${username}`);
      return res.status(401).json({ error: 'اسم المستخدم أو كلمة المرور غير صحيحة' });
    }

    // تحديث آخر تسجيل دخول
    await licenseStorage.updateEmployeeLastLogin(employee.id);

    // إزالة محاولات فاشلة عند نجاح تسجيل الدخول
    employeeLoginAttempts.delete(clientIP);
    
    console.log(`تم تسجيل دخول الموظف بنجاح: ${employee.name} (${username}) من ${clientIP}`);
    
    res.json({ 
      success: true, 
      message: 'تم تسجيل الدخول بنجاح',
      employee: {
        id: employee.id,
        name: employee.name,
        username: employee.username
        // لا نرسل كلمة المرور أبداً
      }
    });
  } catch (error) {
    console.error('❌ خطأ في تسجيل دخول الموظف:', error);
    res.status(500).json({ error: 'خطأ في الخادم. يرجى المحاولة لاحقاً' });
  }
});

// تسجيل خروج موظف
app.post('/api/employees/logout', async (req, res) => {
  const { employeeId } = req.body;
  
  try {
    if (employeeId) {
      console.log(`تم تسجيل خروج الموظف رقم ${employeeId}`);
    }
    
    res.json({ 
      success: true, 
      message: 'تم تسجيل الخروج بنجاح' 
    });
  } catch (error) {
    console.error('❌ خطأ في تسجيل خروج الموظف:', error);
    res.status(500).json({ error: 'خطأ في الخادم' });
  }
});

// === APIs إدارة الموظفين (مدير فقط) ===

// عرض جميع الموظفين - مدير فقط
app.get('/api/admin/employees', async (req, res) => {
  try {
    const employees = await licenseStorage.getAllEmployees();
    
    // إزالة كلمات المرور من الاستجابة
    const safeEmployees = employees.map(emp => ({
      id: emp.id,
      name: emp.name,
      username: emp.username,
      isActive: emp.isActive,
      createdAt: emp.createdAt,
      createdBy: emp.createdBy,
      lastLoginAt: emp.lastLoginAt,
      notes: emp.notes
      // لا نرسل passwordHash أبداً
    }));
    
    console.log(`مدير طلب قائمة الموظفين: ${safeEmployees.length} موظف`);
    res.json({ success: true, employees: safeEmployees });
  } catch (error) {
    console.error('❌ خطأ في جلب قائمة الموظفين:', error);
    res.status(500).json({ error: 'خطأ في الخادم' });
  }
});

// إضافة موظف جديد - مدير فقط
app.post('/api/admin/employees', requireAdmin, async (req, res) => {
  try {
    const { name, username, password, isActive = true, notes } = req.body;
    
    // التحقق من البيانات المطلوبة
    if (!name || !username || !password) {
      return res.status(400).json({ 
        error: 'الاسم واسم المستخدم وكلمة المرور مطلوبة' 
      });
    }

    // التحقق من طول كلمة المرور
    if (password.length < 4) {
      return res.status(400).json({ 
        error: 'كلمة المرور يجب أن تكون 4 أحرف على الأقل' 
      });
    }

    // التحقق من عدم وجود اسم المستخدم
    const existingEmployee = await licenseStorage.getEmployeeByUsername(username);
    if (existingEmployee) {
      return res.status(400).json({ 
        error: 'اسم المستخدم موجود مسبقاً. يرجى اختيار اسم آخر' 
      });
    }

    // تشفير كلمة المرور
    const saltRounds = 12; // مستوى تشفير عالي
    const passwordHash = await bcrypt.hash(password, saltRounds);

    // إنشاء الموظف
    const newEmployee = await licenseStorage.createEmployee({
      name,
      username,
      passwordHash,
      isActive,
      createdBy: 'admin', // يمكن تحسينه لاحقاً لمعرف المدير الفعلي
      notes
    });

    // إرسال الاستجابة بدون كلمة المرور
    const safeEmployee = {
      id: newEmployee.id,
      name: newEmployee.name,
      username: newEmployee.username,
      isActive: newEmployee.isActive,
      createdAt: newEmployee.createdAt,
      createdBy: newEmployee.createdBy,
      notes: newEmployee.notes
    };

    console.log(`تم إنشاء موظف جديد: ${newEmployee.name} (${newEmployee.username})`);
    res.json({ 
      success: true, 
      message: 'تم إضافة الموظف بنجاح',
      employee: safeEmployee
    });
  } catch (error) {
    console.error('❌ خطأ في إضافة موظف جديد:', error);
    res.status(500).json({ error: 'خطأ في الخادم' });
  }
});

// حذف موظف - مدير فقط
app.delete('/api/admin/employees/:id', requireAdmin, async (req, res) => {
  try {
    const employeeId = parseInt(req.params.id);
    
    if (!employeeId || employeeId <= 0) {
      return res.status(400).json({ error: 'معرف الموظف غير صحيح' });
    }

    // التحقق من وجود الموظف أولاً
    const employee = await licenseStorage.getEmployee(employeeId);
    if (!employee) {
      return res.status(404).json({ error: 'الموظف غير موجود' });
    }

    // حذف الموظف
    const deleted = await licenseStorage.deleteEmployee(employeeId);
    
    if (deleted) {
      console.log(`تم حذف الموظف: ${employee.name} (${employee.username}) - ID: ${employeeId}`);
      res.json({ 
        success: true, 
        message: 'تم حذف الموظف بنجاح',
        deletedEmployee: {
          id: employee.id,
          name: employee.name,
          username: employee.username
        }
      });
    } else {
      res.status(400).json({ error: 'فشل في حذف الموظف' });
    }
  } catch (error) {
    console.error('❌ خطأ في حذف الموظف:', error);
    res.status(500).json({ error: 'خطأ في الخادم' });
  }
});

// === APIs مدير التراخيص ===

// إضافة عميل جديد - مدير التراخيص
app.post('/api/license-manager/customers', requireLicenseManager, async (req, res) => {
  try {
    const customer = await licenseStorage.createCustomer(req.body);
    res.json({ success: true, customer });
  } catch (error) {
    res.status(400).json({ error: error instanceof Error ? error.message : 'خطأ غير معروف' });
  }
});

// حذف عميل - مدير التراخيص
app.delete('/api/license-manager/customers/:id', requireLicenseManager, async (req, res) => {
  try {
    const deleted = await licenseStorage.deleteCustomer(parseInt(req.params.id));
    if (!deleted) {
      return res.status(404).json({ error: 'العميل غير موجود أو لا يمكن حذفه' });
    }
    res.json({ success: true, message: 'تم حذف العميل بنجاح' });
  } catch (error) {
    res.status(400).json({ error: error instanceof Error ? error.message : 'خطأ في حذف العميل' });
  }
});

// إصدار ترخيص جديد - مدير التراخيص
app.post('/api/license-manager/licenses', requireLicenseManager, async (req, res) => {
  try {
    const { customerId, licenseTypeId, licenseType } = req.body;
    
    // إذا لم يتم تمرير licenseTypeId، نستخدم القيمة الافتراضية بناء على النوع
    let actualLicenseTypeId = licenseTypeId;
    if (!actualLicenseTypeId && licenseType) {
      switch(licenseType) {
        case 'basic': actualLicenseTypeId = 1; break;
        case 'premium': actualLicenseTypeId = 2; break;
        case 'enterprise': actualLicenseTypeId = 3; break;
        default: actualLicenseTypeId = 1;
      }
    }
    
    const license = await licenseStorage.generateLicense(
      parseInt(customerId) || customerId,
      actualLicenseTypeId, 
      'license-manager'
    );
    res.json({ success: true, license });
  } catch (error) {
    res.status(400).json({ error: error instanceof Error ? error.message : 'خطأ غير معروف' });
  }
});

// جلب جميع العملاء - مدير التراخيص
app.get('/api/license-manager/customers', requireLicenseManager, async (req, res) => {
  try {
    const customers = await licenseStorage.getAllCustomers();
    res.json({ success: true, customers });
  } catch (error) {
    res.status(500).json({ error: error instanceof Error ? error.message : 'خطأ في الخادم' });
  }
});

// جلب جميع التراخيص - مدير التراخيص
app.get('/api/license-manager/licenses', requireLicenseManager, async (req, res) => {
  try {
    const licenses = await licenseStorage.getAllLicenses();
    res.json({ success: true, licenses });
  } catch (error) {
    res.status(500).json({ error: error instanceof Error ? error.message : 'خطأ في الخادم' });
  }
});

// جلب أنواع التراخيص - مدير التراخيص
app.get('/api/license-manager/license-types', requireLicenseManager, async (req, res) => {
  try {
    const licenseTypes = await licenseStorage.getAllLicenseTypes();
    res.json({ success: true, licenseTypes });
  } catch (error) {
    res.status(500).json({ error: error instanceof Error ? error.message : 'خطأ في الخادم' });
  }
});

// جلب الإحصائيات - مدير التراخيص
app.get('/api/license-manager/stats', requireLicenseManager, async (req, res) => {
  try {
    const stats = await licenseStorage.getLicenseStats();
    res.json({ success: true, stats });
  } catch (error) {
    res.status(500).json({ error: error instanceof Error ? error.message : 'خطأ في الخادم' });
  }
});

// === APIs إدارة العملاء ===

// إنشاء عميل جديد
app.post('/api/admin/customers', requireAdmin, async (req, res) => {
  try {
    const customer = await licenseStorage.createCustomer(req.body);
    res.json({ success: true, customer });
  } catch (error) {
    res.status(400).json({ error: error instanceof Error ? error.message : 'خطأ غير معروف' });
  }
});

// الحصول على جميع العملاء
app.get('/api/admin/customers', requireAdmin, async (req, res) => {
  try {
    const customers = await licenseStorage.getAllCustomers();
    res.json({ success: true, customers });
  } catch (error) {
    res.status(500).json({ error: error instanceof Error ? error.message : 'خطأ في الخادم' });
  }
});

// الحصول على عميل محدد
app.get('/api/admin/customers/:id', requireAdmin, async (req, res) => {
  try {
    const customer = await licenseStorage.getCustomer(parseInt(req.params.id));
    if (!customer) {
      return res.status(404).json({ error: 'العميل غير موجود' });
    }
    res.json({ success: true, customer });
  } catch (error) {
    res.status(500).json({ error: error instanceof Error ? error.message : 'خطأ في الخادم' });
  }
});

// تحديث بيانات عميل
app.put('/api/admin/customers/:id', requireAdmin, async (req, res) => {
  try {
    const customer = await licenseStorage.updateCustomer(parseInt(req.params.id), req.body);
    if (!customer) {
      return res.status(404).json({ error: 'العميل غير موجود' });
    }
    res.json({ success: true, customer });
  } catch (error) {
    res.status(400).json({ error: error instanceof Error ? error.message : 'خطأ غير معروف' });
  }
});

// حذف عميل
app.delete('/api/admin/customers/:id', requireAdmin, async (req, res) => {
  try {
    const deleted = await licenseStorage.deleteCustomer(parseInt(req.params.id));
    if (!deleted) {
      return res.status(404).json({ error: 'العميل غير موجود أو لا يمكن حذفه' });
    }
    res.json({ success: true, message: 'تم حذف العميل بنجاح' });
  } catch (error) {
    res.status(400).json({ error: error instanceof Error ? error.message : 'خطأ في حذف العميل' });
  }
});

// === APIs إدارة أنواع التراخيص ===

// إنشاء نوع ترخيص جديد
app.post('/api/admin/license-types', requireAdmin, async (req, res) => {
  try {
    const licenseType = await licenseStorage.createLicenseType(req.body);
    res.json({ success: true, licenseType });
  } catch (error) {
    res.status(400).json({ error: error instanceof Error ? error.message : 'خطأ غير معروف' });
  }
});

// الحصول على جميع أنواع التراخيص
app.get('/api/admin/license-types', requireAdmin, async (req, res) => {
  try {
    const licenseTypes = await licenseStorage.getAllLicenseTypes();
    res.json({ success: true, licenseTypes });
  } catch (error) {
    res.status(500).json({ error: error instanceof Error ? error.message : 'خطأ في الخادم' });
  }
});

// === APIs إدارة التراخيص ===

// إنشاء ترخيص جديد
app.post('/api/admin/licenses', requireAdmin, async (req, res) => {
  try {
    const { customerId, licenseTypeId } = req.body;
    const license = await licenseStorage.generateLicense(
      customerId, 
      licenseTypeId, 
      'admin' // في التطبيق الحقيقي، سيكون من بيانات المستخدم المسجل
    );
    res.json({ success: true, license });
  } catch (error) {
    res.status(400).json({ error: error instanceof Error ? error.message : 'خطأ غير معروف' });
  }
});

// جلب جميع التراخيص 
app.get('/api/admin/licenses', requireAdmin, async (req, res) => {
  try {
    const licenses = await licenseStorage.getAllLicenses();
    res.json({ success: true, licenses });
  } catch (error) {
    res.status(500).json({ error: error instanceof Error ? error.message : 'خطأ في الخادم' });
  }
});

// الحصول على تراخيص عميل
app.get('/api/admin/customers/:customerId/licenses', requireAdmin, async (req, res) => {
  try {
    const licenses = await licenseStorage.getCustomerLicenses(parseInt(req.params.customerId));
    res.json({ success: true, licenses });
  } catch (error) {
    res.status(500).json({ error: error instanceof Error ? error.message : 'خطأ في الخادم' });
  }
});

// إلغاء ترخيص
app.post('/api/admin/licenses/:id/revoke', requireAdmin, async (req, res) => {
  try {
    const { reason } = req.body;
    const success = await licenseStorage.revokeLicense(
      parseInt(req.params.id), 
      reason || 'إلغاء من قبل المسؤول', 
      'admin'
    );
    
    if (success) {
      res.json({ success: true, message: 'تم إلغاء الترخيص بنجاح' });
    } else {
      res.status(404).json({ error: 'الترخيص غير موجود' });
    }
  } catch (error) {
    res.status(400).json({ error: error instanceof Error ? error.message : 'خطأ غير معروف' });
  }
});

// تجديد ترخيص
app.post('/api/admin/licenses/:id/renew', requireAdmin, async (req, res) => {
  try {
    const { validityDays } = req.body;
    const newExpiryDate = new Date();
    newExpiryDate.setDate(newExpiryDate.getDate() + (validityDays || 365));
    
    const license = await licenseStorage.renewLicense(
      parseInt(req.params.id), 
      newExpiryDate, 
      'admin'
    );
    
    if (license) {
      res.json({ success: true, license });
    } else {
      res.status(404).json({ error: 'الترخيص غير موجود' });
    }
  } catch (error) {
    res.status(400).json({ error: error instanceof Error ? error.message : 'خطأ غير معروف' });
  }
});

// === APIs التحقق من التراخيص (للعامة) ===

// تفعيل ترخيص
app.post('/api/license/activate', async (req, res) => {
  try {
    const { licenseKey, deviceInfo } = req.body;
    
    if (!licenseKey) {
      return res.status(400).json({ error: 'مطلوب مفتاح الترخيص' });
    }
    
    // تجميع معلومات الجهاز
    const deviceData = {
      deviceId: deviceInfo?.deviceId || generateDeviceFingerprint(req),
      deviceName: deviceInfo?.deviceName || 'Unknown Device',
      fingerprint: deviceInfo?.fingerprint || generateDeviceFingerprint(req),
      ipAddress: req.ip || req.connection.remoteAddress,
      userAgent: req.headers['user-agent'],
      osInfo: deviceInfo?.osInfo,
      hardwareInfo: deviceInfo?.hardwareInfo
    };
    
    const result = await licenseStorage.activateLicense(licenseKey, deviceData);
    
    if (result.success) {
      res.json({ 
        success: true, 
        activation: result.activation,
        message: 'تم تفعيل الترخيص بنجاح'
      });
    } else {
      res.status(400).json({ 
        success: false, 
        error: result.error 
      });
    }
  } catch (error) {
    res.status(500).json({ error: error instanceof Error ? error.message : 'خطأ في الخادم' });
  }
});

// التحقق من صحة ترخيص
app.post('/api/license/validate', async (req, res) => {
  try {
    const { licenseKey, deviceId } = req.body;
    
    if (!licenseKey) {
      return res.status(400).json({ error: 'مطلوب مفتاح الترخيص' });
    }
    
    const deviceFingerprint = deviceId || generateDeviceFingerprint(req);
    const result = await licenseStorage.validateLicense(licenseKey, deviceFingerprint);
    
    res.json({
      valid: result.valid,
      reason: result.reason,
      remainingDays: result.remainingDays,
      license: result.license ? {
        id: result.license.id,
        expiryDate: result.license.expiryDate,
        maxActivations: result.license.maxActivations,
        currentActivations: result.license.currentActivations
      } : undefined
    });
  } catch (error) {
    res.status(500).json({ error: error instanceof Error ? error.message : 'خطأ في الخادم' });
  }
});

// إلغاء تفعيل ترخيص
app.post('/api/license/deactivate', async (req, res) => {
  try {
    const { licenseKey, deviceId } = req.body;
    
    if (!licenseKey) {
      return res.status(400).json({ error: 'مطلوب مفتاح الترخيص' });
    }
    
    const deviceFingerprint = deviceId || generateDeviceFingerprint(req);
    const success = await licenseStorage.deactivateLicense(licenseKey, deviceFingerprint);
    
    if (success) {
      res.json({ success: true, message: 'تم إلغاء التفعيل بنجاح' });
    } else {
      res.status(400).json({ error: 'فشل في إلغاء التفعيل' });
    }
  } catch (error) {
    res.status(500).json({ error: error instanceof Error ? error.message : 'خطأ في الخادم' });
  }
});

// === APIs الإحصائيات ===

app.get('/api/admin/stats', requireAdmin, async (req, res) => {
  try {
    const stats = await licenseStorage.getLicenseStats();
    res.json({ success: true, stats });
  } catch (error) {
    res.status(500).json({ error: error instanceof Error ? error.message : 'خطأ في الخادم' });
  }
});

// === APIs سجل العمليات ===

app.get('/api/admin/licenses/:id/audit', requireAdmin, async (req, res) => {
  try {
    const auditLog = await licenseStorage.getLicenseAuditLog(parseInt(req.params.id));
    res.json({ success: true, auditLog });
  } catch (error) {
    res.status(500).json({ error: error instanceof Error ? error.message : 'خطأ في الخادم' });
  }
});

// === APIs إدارة الدفعات ===

app.post('/api/admin/payments', requireAdmin, async (req, res) => {
  try {
    const payment = await licenseStorage.createPayment(req.body);
    res.json({ success: true, payment });
  } catch (error) {
    res.status(400).json({ error: error instanceof Error ? error.message : 'خطأ غير معروف' });
  }
});

app.get('/api/admin/customers/:customerId/payments', requireAdmin, async (req, res) => {
  try {
    const payments = await licenseStorage.getCustomerPayments(parseInt(req.params.customerId));
    res.json({ success: true, payments });
  } catch (error) {
    res.status(500).json({ error: error instanceof Error ? error.message : 'خطأ في الخادم' });
  }
});

// === API خاص للبرنامج الأساسي (license check) ===

// التحقق من صحة كود التفعيل (للتفعيل السنوي للنظام)
app.post('/api/validate-activation-code', async (req, res) => {
  try {
    const { licenseKey, deviceId, storeName } = req.body;

    if (!licenseKey?.trim()) {
      return res.status(400).json({ error: 'كود التفعيل مطلوب', valid: false });
    }

    // التحقق من صحة الترخيص أولاً (بدون تحقق من الجهاز)
    const validation = await licenseStorage.validateLicense(
      licenseKey.trim().toUpperCase()
    );

    if (!validation.valid) {
      return res.json({
        valid: false,
        error: validation.reason || 'كود التفعيل غير صحيح'
      });
    }

    // إذا كان الترخيص صحيح، قم بتفعيل الجهاز تلقائياً
    if (deviceId) {
      const deviceInfo = {
        deviceId: deviceId,
        deviceName: storeName || 'متجر نقاط البيع',
        fingerprint: `POS-${Date.now()}`,
        ipAddress: req.ip || '127.0.0.1',
        userAgent: req.get('user-agent') || 'POS System',
        osInfo: 'Web Browser',
        hardwareInfo: 'POS Terminal'
      };

      const activationResult = await licenseStorage.activateLicense(
        licenseKey.trim().toUpperCase(),
        deviceInfo
      );

      if (!activationResult.success) {
        return res.json({
          valid: false,
          error: activationResult.error || 'فشل في تفعيل الجهاز'
        });
      }
    }

    // إذا كان الترخيص صالحاً، احصل على معلومات العميل
    const license = validation.license;
    let customer = null;
    let licenseType = null;

    if (license?.customerId) {
      try {
        customer = await licenseStorage.getCustomer(license.customerId);
        if (license.licenseTypeId) {
          const allLicenseTypes = await licenseStorage.getAllLicenseTypes();
          licenseType = allLicenseTypes.find(lt => lt.id === license.licenseTypeId);
        }
      } catch (error) {
        console.warn('تعذر جلب بيانات العميل أو نوع الترخيص:', error);
      }
    }

    // إرجاع معلومات التفعيل المكتملة
    return res.json({
      valid: true,
      license: {
        key: license?.licenseKey,
        expiryDate: license?.expiryDate,
        remainingDays: validation.remainingDays,
        isActive: license?.isActive,
        isRevoked: license?.isRevoked
      },
      customer: customer ? {
        id: customer.id,
        companyName: customer.companyName,
        contactPerson: customer.contactPerson,
        email: customer.email,
        phone: customer.phone
      } : null,
      licenseType: licenseType ? {
        id: licenseType.id,
        name: licenseType.name,
        description: licenseType.description,
        price: licenseType.price,
        validityDays: licenseType.validityDays,
        deviceLimit: licenseType.maxDevices,
        features: licenseType.features
      } : null,
      activationInfo: {
        activatedAt: new Date().toISOString(),
        deviceId: deviceId || null,
        storeName: storeName || null
      }
    });

  } catch (error) {
    console.error('خطأ في التحقق من كود التفعيل:', error);
    res.status(500).json({ 
      valid: false,
      error: 'خطأ في الخادم أثناء التحقق من كود التفعيل' 
    });
  }
});

app.post('/api/pos/validate-license', async (req, res) => {
  try {
    const { licenseKey } = req.body;
    
    if (!licenseKey) {
      return res.status(400).json({ valid: false, reason: 'مطلوب مفتاح الترخيص' });
    }
    
    const deviceFingerprint = generateDeviceFingerprint(req);
    const result = await licenseStorage.validateLicense(licenseKey, deviceFingerprint);
    
    // تسجيل استخدام البرنامج
    if (result.valid && result.license) {
      try {
        const activations = await licenseStorage.getLicenseActivations(result.license.id);
        const userActivation = activations.find(a => a.deviceId === deviceFingerprint && a.isActive);
        
        if (userActivation) {
          await licenseStorage.logUsage(result.license.id, userActivation.id, {
            actionType: 'pos_access',
            featureUsed: 'main_application',
            additionalData: JSON.stringify({
              ip: req.ip,
              userAgent: req.headers['user-agent'],
              timestamp: new Date().toISOString()
            })
          });
        }
      } catch (usageError) {
        console.error('خطأ في تسجيل الاستخدام:', usageError);
      }
    }
    
    res.json({
      valid: result.valid,
      reason: result.reason,
      remainingDays: result.remainingDays,
      features: result.license?.metadata ? JSON.parse(result.license.metadata).features : null
    });
  } catch (error) {
    res.status(500).json({ valid: false, reason: 'خطأ في الخادم' });
  }
});

// نقطة فحص صحة الخادم للمزامنة
app.get('/api/health', (req, res) => {
  res.json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    service: 'Lebanese Supermarket Sync Server',
    version: '1.0.0'
  });
});

// === APIs المزامنة بين الأجهزة ===

// مفتاح المزامنة الآمن (من متغيرات البيئة فقط)
const SYNC_SECRET = process.env.SYNC_SECRET;

if (!SYNC_SECRET) {
  console.warn('⚠️  تحذير: لم يتم تعيين SYNC_SECRET في متغيرات البيئة. المزامنة معطلة.');
}

// middleware للتحقق من صحة المزامنة
const validateSyncAuth = (req: any, res: any, next: any) => {
  // التحقق من تفعيل المزامنة
  if (!SYNC_SECRET) {
    return res.status(503).json({ error: 'المزامنة غير مفعلة على الخادم' });
  }
  
  const syncToken = req.headers['x-sync-token'];
  
  // التحقق من وجود المفتاح
  if (!syncToken || syncToken !== SYNC_SECRET) {
    return res.status(401).json({ error: 'غير مخول للوصول للمزامنة' });
  }
  
  next();
};

// دالة تنظيف البيانات الحساسة
const sanitizeStoreSettings = (settings: any) => {
  if (!settings) return settings;
  
  const { adminPassword, licenseKey, ...safeSettings } = settings;
  return safeSettings;
};

// بيانات الأجهزة المتصلة والمزامنة
let connectedDevices: Map<string, { name: string, lastSync: string, ip: string }> = new Map();
let syncData: any = {
  products: [],
  orders: [],
  storeSettings: {},
  stockMovements: [],
  returns: []
};

// رفع البيانات للخادم (من الجهاز للخادم)
app.post('/api/sync/upload', validateSyncAuth, async (req, res) => {
  try {
    const { deviceName, timestamp, products, orders, storeSettings, stockMovements, returns } = req.body;
    
    if (!deviceName) {
      return res.status(400).json({ error: 'اسم الجهاز مطلوب' });
    }

    // تحديث بيانات الجهاز المتصل
    connectedDevices.set(deviceName, {
      name: deviceName,
      lastSync: timestamp || new Date().toISOString(),
      ip: req.ip || 'unknown'
    });

    // حفظ البيانات مع تنظيف المعلومات الحساسة
    if (products) syncData.products = products;
    if (orders) syncData.orders = orders;
    if (storeSettings) syncData.storeSettings = sanitizeStoreSettings(storeSettings);
    if (stockMovements) syncData.stockMovements = stockMovements;
    if (returns) syncData.returns = returns;

    console.log(`تم رفع البيانات من الجهاز: ${deviceName}`);
    
    res.json({ 
      success: true, 
      message: 'تم رفع البيانات بنجاح',
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('خطأ في رفع البيانات:', error);
    res.status(500).json({ error: 'خطأ في رفع البيانات' });
  }
});

// تنزيل البيانات من الخادم (من الخادم للجهاز)
app.get('/api/sync/download', validateSyncAuth, async (req, res) => {
  try {
    const deviceName = req.query.deviceName as string;
    
    // تحديث آخر مزامنة للجهاز
    if (deviceName && connectedDevices.has(deviceName)) {
      const device = connectedDevices.get(deviceName)!;
      connectedDevices.set(deviceName, {
        ...device,
        lastSync: new Date().toISOString()
      });
    }

    console.log(`تم تنزيل البيانات للجهاز: ${deviceName || 'غير محدد'}`);
    
    res.json({
      success: true,
      data: syncData,
      timestamp: new Date().toISOString(),
      // إرسال البيانات مباشرة في الـ response root للتوافق مع الفرونت إند
      ...syncData
    });
  } catch (error) {
    console.error('خطأ في تنزيل البيانات:', error);
    res.status(500).json({ error: 'خطأ في تنزيل البيانات' });
  }
});

// جلب قائمة الأجهزة المتصلة
app.get('/api/sync/devices', validateSyncAuth, async (req, res) => {
  try {
    const devices = Array.from(connectedDevices.values());
    
    res.json(devices);
  } catch (error) {
    console.error('خطأ في جلب الأجهزة المتصلة:', error);
    res.status(500).json({ error: 'خطأ في جلب الأجهزة المتصلة' });
  }
});

// حالة المزامنة والإحصائيات
app.get('/api/sync/status', validateSyncAuth, async (req, res) => {
  try {
    const stats = {
      connectedDevices: connectedDevices.size,
      lastDataUpdate: syncData.timestamp || null,
      dataStats: {
        products: syncData.products?.length || 0,
        orders: syncData.orders?.length || 0,
        stockMovements: syncData.stockMovements?.length || 0,
        returns: syncData.returns?.length || 0
      }
    };
    
    res.json(stats);
  } catch (error) {
    console.error('خطأ في جلب حالة المزامنة:', error);
    res.status(500).json({ error: 'خطأ في جلب حالة المزامنة' });
  }
});

// مسح بيانات المزامنة (للاختبار)
app.delete('/api/sync/clear', async (req, res) => {
  try {
    syncData = {
      products: [],
      orders: [],
      storeSettings: {},
      stockMovements: [],
      returns: []
    };
    connectedDevices.clear();
    
    res.json({ success: true, message: 'تم مسح بيانات المزامنة' });
  } catch (error) {
    console.error('خطأ في مسح بيانات المزامنة:', error);
    res.status(500).json({ error: 'خطأ في مسح بيانات المزامنة' });
  }
});

if (isDev) {
  // In development, serve from client directory (for hot reload)
  app.use(express.static(path.join(__dirname, '../client')));
  
  // Serve React app for all NON-API routes
  app.get(/^(?!\/api).*/, (req, res) => {
    res.sendFile(path.join(__dirname, '../client/index.html'));
  });
} else {
  // In production, serve built files from dist/public
  app.use(express.static(path.join(__dirname, './public')));
  
  // Add Cache-Control headers for better performance
  app.use((req, res, next) => {
    res.setHeader('Cache-Control', 'no-cache');
    next();
  });
  
  // Serve the React app for all NON-API routes (exclude /api paths)
  app.get(/^(?!\/api).*/, (req, res) => {
    res.sendFile(path.join(__dirname, './public/index.html'));
  });
}

// بدء الخادم مع تهيئة كلمات المرور الآمنة
const startServer = async () => {
  try {
    // تهيئة تشفير كلمات المرور أولاً
    await initializePasswordHashes();
    
    // بدء الخادم بعد نجاح التشفير
    app.listen(PORT, '0.0.0.0', () => {
      console.log(`🚀 Server running on port ${PORT}`);
      console.log('🔒 Security: Password hashing enabled');
      console.log('🛡️  Security: Rate limiting active');
      console.log('🔐 Security headers: Active');
    });
  } catch (error) {
    console.error('❌ Failed to start server:', error);
    process.exit(1);
  }
};

// بدء الخادم
startServer();