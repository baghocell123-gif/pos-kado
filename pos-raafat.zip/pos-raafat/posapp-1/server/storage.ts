import { 
  customers, 
  licenses, 
  licenseTypes, 
  licenseActivations, 
  licenseUsage, 
  licensePayments, 
  licenseAuditLog,
  employees,
  type Customer,
  type InsertCustomer,
  type License,
  type InsertLicense,
  type LicenseType,
  type InsertLicenseType,
  type LicenseActivation,
  type InsertLicenseActivation,
  type LicenseUsage as LicenseUsageType,
  type InsertLicenseUsage,
  type LicensePayment,
  type InsertLicensePayment,
  type LicenseAuditLog,
  type InsertLicenseAuditLog,
  type Employee,
  type InsertEmployee
} from "../shared/schema";
import { db } from "./db";
import { eq, and, gte, lte, sql, desc, asc } from "drizzle-orm";
import { randomBytes } from 'crypto';

// واجهة إدارة التراخيص
export interface ILicenseStorage {
  // إدارة العملاء
  createCustomer(customer: InsertCustomer): Promise<Customer>;
  getCustomer(id: number): Promise<Customer | undefined>;
  getCustomerByEmail(email: string): Promise<Customer | undefined>;
  updateCustomer(id: number, updates: Partial<Customer>): Promise<Customer | undefined>;
  deleteCustomer(id: number): Promise<boolean>;
  getAllCustomers(): Promise<Customer[]>;
  
  // إدارة أنواع التراخيص
  createLicenseType(licenseType: InsertLicenseType): Promise<LicenseType>;
  getLicenseType(id: number): Promise<LicenseType | undefined>;
  getAllLicenseTypes(): Promise<LicenseType[]>;
  updateLicenseType(id: number, updates: Partial<LicenseType>): Promise<LicenseType | undefined>;
  
  // إدارة التراخيص
  generateLicense(customerId: number, licenseTypeId: number, createdBy: string): Promise<License>;
  getLicense(id: number): Promise<License | undefined>;
  getLicenseByKey(licenseKey: string): Promise<License | undefined>;
  getAllLicenses(): Promise<License[]>;
  updateLicense(id: number, updates: Partial<License>): Promise<License | undefined>;
  revokeLicense(id: number, reason: string, revokedBy: string): Promise<boolean>;
  renewLicense(id: number, newExpiryDate: Date, renewedBy: string): Promise<License | undefined>;
  getCustomerLicenses(customerId: number): Promise<License[]>;
  
  // إدارة التفعيلات
  activateLicense(licenseKey: string, deviceInfo: any): Promise<{ success: boolean; activation?: LicenseActivation; error?: string }>;
  deactivateLicense(licenseKey: string, deviceId: string): Promise<boolean>;
  getLicenseActivations(licenseId: number): Promise<LicenseActivation[]>;
  
  // تسجيل الاستخدام
  logUsage(licenseId: number, activationId: number, usage: Omit<InsertLicenseUsage, 'licenseId' | 'activationId'>): Promise<LicenseUsageType>;
  
  // إدارة الدفعات
  createPayment(payment: InsertLicensePayment): Promise<LicensePayment>;
  updatePaymentStatus(id: number, status: string): Promise<LicensePayment | undefined>;
  getCustomerPayments(customerId: number): Promise<LicensePayment[]>;
  
  // سجل العمليات
  logAudit(log: InsertLicenseAuditLog): Promise<LicenseAuditLog>;
  getLicenseAuditLog(licenseId: number): Promise<LicenseAuditLog[]>;
  
  // التحقق من صحة الترخيص
  validateLicense(licenseKey: string, deviceId?: string): Promise<{
    valid: boolean;
    license?: License;
    reason?: string;
    remainingDays?: number;
  }>;
  
  // الإحصائيات
  getLicenseStats(): Promise<{
    totalLicenses: number;
    activeLicenses: number;
    expiredLicenses: number;
    totalCustomers: number;
    totalRevenue: number;
  }>;
  
  // إدارة الموظفين
  createEmployee(employee: InsertEmployee): Promise<Employee>;
  getEmployee(id: number): Promise<Employee | undefined>;
  getEmployeeByUsername(username: string): Promise<Employee | undefined>;
  getAllEmployees(): Promise<Employee[]>;
  updateEmployee(id: number, updates: Partial<Employee>): Promise<Employee | undefined>;
  deleteEmployee(id: number): Promise<boolean>;
  updateEmployeeLastLogin(id: number): Promise<void>;
}

// تطبيق نظام إدارة التراخيص
export class DatabaseLicenseStorage implements ILicenseStorage {
  
  // توليد مفتاح ترخيص آمن بتنسيق POS24-XXXX-XXXX-XXXX
  private generateLicenseKey(): string {
    const prefix = 'POS24'; // ثابت للمنتج
    const group1 = randomBytes(2).toString('hex').toUpperCase(); // 4 أحرف
    const group2 = randomBytes(2).toString('hex').toUpperCase(); // 4 أحرف
    const dataForChecksum = prefix + group1 + group2;
    const checksum = this.calculateChecksum(dataForChecksum);
    
    return `${prefix}-${group1}-${group2}-${checksum}`;
  }
  
  // حساب checksum للتحقق من صحة المفتاح
  private calculateChecksum(input: string): string {
    let sum = 0;
    for (let i = 0; i < input.length; i++) {
      sum += input.charCodeAt(i);
    }
    return (sum % 9999).toString().padStart(4, '0');
  }
  
  // التحقق من صحة تنسيق مفتاح الترخيص POS24-XXXX-XXXX-XXXX
  private isValidLicenseKeyFormat(licenseKey: string): boolean {
    const pattern = /^POS24-[A-F0-9]{4}-[A-F0-9]{4}-\d{4}$/;
    return pattern.test(licenseKey);
  }

  // التحقق من صحة checksum المفتاح
  private verifyLicenseKeyChecksum(licenseKey: string): boolean {
    if (!this.isValidLicenseKeyFormat(licenseKey)) {
      return false;
    }
    
    const parts = licenseKey.split('-');
    const prefix = parts[0]; // POS24
    const group1 = parts[1]; // XXXX
    const group2 = parts[2]; // XXXX
    const receivedChecksum = parts[3]; // XXXX
    
    const dataForChecksum = prefix + group1 + group2;
    const calculatedChecksum = this.calculateChecksum(dataForChecksum);
    
    return receivedChecksum === calculatedChecksum;
  }
  
  // === إدارة العملاء ===
  async createCustomer(customer: InsertCustomer): Promise<Customer> {
    const [newCustomer] = await db
      .insert(customers)
      .values(customer)
      .returning();
    return newCustomer;
  }
  
  async getCustomer(id: number): Promise<Customer | undefined> {
    const [customer] = await db
      .select()
      .from(customers)
      .where(eq(customers.id, id));
    return customer || undefined;
  }
  
  async getCustomerByEmail(email: string): Promise<Customer | undefined> {
    const [customer] = await db
      .select()
      .from(customers)
      .where(eq(customers.email, email));
    return customer || undefined;
  }
  
  async updateCustomer(id: number, updates: Partial<Customer>): Promise<Customer | undefined> {
    const [updated] = await db
      .update(customers)
      .set(updates)
      .where(eq(customers.id, id))
      .returning();
    return updated || undefined;
  }
  
  async deleteCustomer(id: number): Promise<boolean> {
    try {
      // التحقق من وجود تراخيص نشطة مرتبطة بالعميل فقط
      const activeLicenses = await db
        .select()
        .from(licenses)
        .where(
          and(
            eq(licenses.customerId, id),
            eq(licenses.isActive, true),
            eq(licenses.isRevoked, false)
          )
        );
      
      if (activeLicenses.length > 0) {
        throw new Error(`لا يمكن حذف العميل لأنه يملك ${activeLicenses.length} ترخيص نشط. يجب إلغاء التراخيص النشطة أولاً.`);
      }

      const [deleted] = await db
        .delete(customers)
        .where(eq(customers.id, id))
        .returning();
      
      return deleted !== undefined;
    } catch (error) {
      console.error('خطأ في حذف العميل:', error);
      throw error; // رمي الخطأ بدلاً من إرجاع false لعرض رسالة واضحة
    }
  }
  
  async getAllCustomers(): Promise<Customer[]> {
    return await db.select().from(customers).orderBy(asc(customers.companyName));
  }
  
  // === إدارة أنواع التراخيص ===
  async createLicenseType(licenseType: InsertLicenseType): Promise<LicenseType> {
    const [newType] = await db
      .insert(licenseTypes)
      .values(licenseType)
      .returning();
    return newType;
  }
  
  async getLicenseType(id: number): Promise<LicenseType | undefined> {
    const [type] = await db
      .select()
      .from(licenseTypes)
      .where(eq(licenseTypes.id, id));
    return type || undefined;
  }
  
  async getAllLicenseTypes(): Promise<LicenseType[]> {
    return await db
      .select()
      .from(licenseTypes)
      .where(eq(licenseTypes.isActive, true))
      .orderBy(asc(licenseTypes.name));
  }
  
  async updateLicenseType(id: number, updates: Partial<LicenseType>): Promise<LicenseType | undefined> {
    const [updated] = await db
      .update(licenseTypes)
      .set(updates)
      .where(eq(licenseTypes.id, id))
      .returning();
    return updated || undefined;
  }
  
  // === إدارة التراخيص ===
  async generateLicense(customerId: number, licenseTypeId: number, createdBy: string): Promise<License> {
    const licenseType = await this.getLicenseType(licenseTypeId);
    if (!licenseType) {
      throw new Error('نوع الترخيص غير موجود');
    }
    
    const licenseKey = this.generateLicenseKey();
    const issueDate = new Date();
    const validityDays = licenseType.validityDays || 365; // قيمة افتراضية سنة واحدة
    const expiryDate = new Date(issueDate.getTime() + (validityDays * 24 * 60 * 60 * 1000));
    
    const [newLicense] = await db
      .insert(licenses)
      .values({
        licenseKey,
        customerId,
        licenseTypeId,
        issueDate,
        expiryDate,
        maxActivations: licenseType.maxDevices,
        createdBy,
        metadata: JSON.stringify({
          features: licenseType.features,
          generatedAt: new Date().toISOString()
        })
      })
      .returning();
    
    // تسجيل العملية في سجل التدقيق
    await this.logAudit({
      licenseId: newLicense.id,
      action: 'created',
      performedBy: createdBy,
      newValues: JSON.stringify(newLicense),
      notes: `تم إنشاء ترخيص جديد للعميل ${customerId}`
    });
    
    return newLicense;
  }
  
  async getLicense(id: number): Promise<License | undefined> {
    const [license] = await db
      .select()
      .from(licenses)
      .where(eq(licenses.id, id));
    return license || undefined;
  }
  
  async getLicenseByKey(licenseKey: string): Promise<License | undefined> {
    if (!this.isValidLicenseKeyFormat(licenseKey) || !this.verifyLicenseKeyChecksum(licenseKey)) {
      return undefined;
    }
    
    const [license] = await db
      .select()
      .from(licenses)
      .where(eq(licenses.licenseKey, licenseKey));
    return license || undefined;
  }
  
  async updateLicense(id: number, updates: Partial<License>): Promise<License | undefined> {
    const [updated] = await db
      .update(licenses)
      .set(updates)
      .where(eq(licenses.id, id))
      .returning();
    return updated || undefined;
  }
  
  async revokeLicense(id: number, reason: string, revokedBy: string): Promise<boolean> {
    const [updated] = await db
      .update(licenses)
      .set({
        isRevoked: true,
        revokedDate: new Date(),
        revokedReason: reason
      })
      .where(eq(licenses.id, id))
      .returning();
    
    if (updated) {
      await this.logAudit({
        licenseId: id,
        action: 'revoked',
        performedBy: revokedBy,
        notes: `تم إلغاء الترخيص. السبب: ${reason}`
      });
      return true;
    }
    return false;
  }
  
  async renewLicense(id: number, newExpiryDate: Date, renewedBy: string): Promise<License | undefined> {
    const [updated] = await db
      .update(licenses)
      .set({
        expiryDate: newExpiryDate,
        isActive: true
      })
      .where(eq(licenses.id, id))
      .returning();
    
    if (updated) {
      await this.logAudit({
        licenseId: id,
        action: 'renewed',
        performedBy: renewedBy,
        newValues: JSON.stringify({ expiryDate: newExpiryDate }),
        notes: `تم تجديد الترخيص حتى ${newExpiryDate.toLocaleDateString('ar-LB')}`
      });
    }
    
    return updated || undefined;
  }
  
  async getAllLicenses(): Promise<License[]> {
    return await db
      .select()
      .from(licenses)
      .orderBy(desc(licenses.issueDate));
  }

  async getCustomerLicenses(customerId: number): Promise<License[]> {
    return await db
      .select()
      .from(licenses)
      .where(eq(licenses.customerId, customerId))
      .orderBy(desc(licenses.issueDate));
  }
  
  // === إدارة التفعيلات ===
  async activateLicense(licenseKey: string, deviceInfo: any): Promise<{ success: boolean; activation?: LicenseActivation; error?: string }> {
    const license = await this.getLicenseByKey(licenseKey);
    
    if (!license) {
      return { success: false, error: 'مفتاح الترخيص غير صحيح' };
    }
    
    if (license.isRevoked) {
      return { success: false, error: 'تم إلغاء هذا الترخيص' };
    }
    
    if (!license.isActive) {
      return { success: false, error: 'الترخيص غير نشط' };
    }
    
    if (new Date() > license.expiryDate) {
      return { success: false, error: 'انتهت صلاحية الترخيص' };
    }
    
    const licenseCurrentActivations = license.currentActivations || 0;
    const licenseMaxActivations = license.maxActivations || 1;
    
    if (licenseCurrentActivations >= licenseMaxActivations) {
      return { success: false, error: 'تم الوصول للحد الأقصى لعدد التفعيلات' };
    }
    
    // التحقق من وجود تفعيل سابق لنفس الجهاز
    const [existingActivation] = await db
      .select()
      .from(licenseActivations)
      .where(
        and(
          eq(licenseActivations.licenseId, license.id),
          eq(licenseActivations.deviceId, deviceInfo.deviceId),
          eq(licenseActivations.isActive, true)
        )
      );
    
    if (existingActivation) {
      // تحديث آخر heartbeat
      await db
        .update(licenseActivations)
        .set({ lastHeartbeat: new Date() })
        .where(eq(licenseActivations.id, existingActivation.id));
      
      return { success: true, activation: existingActivation };
    }
    
    // إنشاء تفعيل جديد
    const [newActivation] = await db
      .insert(licenseActivations)
      .values({
        licenseId: license.id,
        deviceId: deviceInfo.deviceId,
        deviceName: deviceInfo.deviceName || 'Unknown Device',
        deviceFingerprint: deviceInfo.fingerprint,
        ipAddress: deviceInfo.ipAddress,
        userAgent: deviceInfo.userAgent,
        osInfo: deviceInfo.osInfo,
        hardwareInfo: deviceInfo.hardwareInfo
      })
      .returning();
    
    // تحديث عدد التفعيلات الحالية
    const activationCount = license.currentActivations || 0;
    await db
      .update(licenses)
      .set({
        currentActivations: activationCount + 1,
        lastActivationDate: new Date()
      })
      .where(eq(licenses.id, license.id));
    
    // تسجيل العملية
    await this.logAudit({
      licenseId: license.id,
      action: 'activated',
      performedBy: 'system',
      newValues: JSON.stringify(deviceInfo),
      notes: `تم تفعيل الترخيص على الجهاز ${deviceInfo.deviceName}`
    });
    
    return { success: true, activation: newActivation };
  }
  
  async deactivateLicense(licenseKey: string, deviceId: string): Promise<boolean> {
    const license = await this.getLicenseByKey(licenseKey);
    if (!license) return false;
    
    const [updated] = await db
      .update(licenseActivations)
      .set({
        isActive: false,
        deactivationDate: new Date()
      })
      .where(
        and(
          eq(licenseActivations.licenseId, license.id),
          eq(licenseActivations.deviceId, deviceId),
          eq(licenseActivations.isActive, true)
        )
      )
      .returning();
    
    if (updated) {
      // تقليل عدد التفعيلات الحالية
      const deactivationCount = license.currentActivations || 0;
      await db
        .update(licenses)
        .set({
          currentActivations: Math.max(0, deactivationCount - 1)
        })
        .where(eq(licenses.id, license.id));
      
      await this.logAudit({
        licenseId: license.id,
        action: 'deactivated',
        performedBy: 'system',
        notes: `تم إلغاء تفعيل الجهاز ${deviceId}`
      });
      
      return true;
    }
    
    return false;
  }
  
  async getLicenseActivations(licenseId: number): Promise<LicenseActivation[]> {
    return await db
      .select()
      .from(licenseActivations)
      .where(eq(licenseActivations.licenseId, licenseId))
      .orderBy(desc(licenseActivations.activationDate));
  }
  
  // === تسجيل الاستخدام ===
  async logUsage(licenseId: number, activationId: number, usage: Omit<InsertLicenseUsage, 'licenseId' | 'activationId'>): Promise<LicenseUsageType> {
    const [newUsage] = await db
      .insert(licenseUsage)
      .values({
        licenseId,
        activationId,
        ...usage
      })
      .returning();
    return newUsage;
  }
  
  // === إدارة الدفعات ===
  async createPayment(payment: InsertLicensePayment): Promise<LicensePayment> {
    const [newPayment] = await db
      .insert(licensePayments)
      .values(payment)
      .returning();
    return newPayment;
  }
  
  async updatePaymentStatus(id: number, status: string): Promise<LicensePayment | undefined> {
    const [updated] = await db
      .update(licensePayments)
      .set({
        paymentStatus: status,
        paymentDate: status === 'completed' ? new Date() : undefined
      })
      .where(eq(licensePayments.id, id))
      .returning();
    return updated || undefined;
  }
  
  async getCustomerPayments(customerId: number): Promise<LicensePayment[]> {
    return await db
      .select()
      .from(licensePayments)
      .where(eq(licensePayments.customerId, customerId))
      .orderBy(desc(licensePayments.createdAt));
  }
  
  // === سجل العمليات ===
  async logAudit(log: InsertLicenseAuditLog): Promise<LicenseAuditLog> {
    const [newLog] = await db
      .insert(licenseAuditLog)
      .values(log)
      .returning();
    return newLog;
  }
  
  async getLicenseAuditLog(licenseId: number): Promise<LicenseAuditLog[]> {
    return await db
      .select()
      .from(licenseAuditLog)
      .where(eq(licenseAuditLog.licenseId, licenseId))
      .orderBy(desc(licenseAuditLog.timestamp));
  }
  
  // === التحقق من صحة الترخيص ===
  async validateLicense(licenseKey: string, deviceId?: string): Promise<{
    valid: boolean;
    license?: License;
    reason?: string;
    remainingDays?: number;
  }> {
    if (!this.isValidLicenseKeyFormat(licenseKey)) {
      return { valid: false, reason: 'تنسيق مفتاح الترخيص غير صحيح' };
    }

    if (!this.verifyLicenseKeyChecksum(licenseKey)) {
      return { valid: false, reason: 'مفتاح الترخيص غير صحيح (checksum خاطئ)' };
    }
    
    const license = await this.getLicenseByKey(licenseKey);
    
    if (!license) {
      return { valid: false, reason: 'مفتاح الترخيص غير موجود' };
    }
    
    if (license.isRevoked) {
      return { valid: false, license, reason: 'تم إلغاء الترخيص' };
    }
    
    if (!license.isActive) {
      return { valid: false, license, reason: 'الترخيص غير نشط' };
    }
    
    const now = new Date();
    const remainingTime = license.expiryDate.getTime() - now.getTime();
    const remainingDays = Math.ceil(remainingTime / (1000 * 60 * 60 * 24));
    
    if (remainingDays <= 0) {
      return { valid: false, license, reason: 'انتهت صلاحية الترخيص', remainingDays: 0 };
    }
    
    // التحقق من تفعيل الجهاز إذا تم تمرير معرف الجهاز
    if (deviceId) {
      const [activation] = await db
        .select()
        .from(licenseActivations)
        .where(
          and(
            eq(licenseActivations.licenseId, license.id),
            eq(licenseActivations.deviceId, deviceId),
            eq(licenseActivations.isActive, true)
          )
        );
      
      if (!activation) {
        return { valid: false, license, reason: 'الجهاز غير مفعل', remainingDays };
      }
    }
    
    return { valid: true, license, remainingDays };
  }
  
  // === الإحصائيات ===
  async getLicenseStats(): Promise<{
    totalLicenses: number;
    activeLicenses: number;
    expiredLicenses: number;
    totalCustomers: number;
    totalRevenue: number;
  }> {
    const now = new Date();
    
    const [totalLicenses] = await db
      .select({ count: sql`count(*)` })
      .from(licenses);
    
    const [activeLicenses] = await db
      .select({ count: sql`count(*)` })
      .from(licenses)
      .where(
        and(
          eq(licenses.isActive, true),
          eq(licenses.isRevoked, false),
          gte(licenses.expiryDate, now)
        )
      );
    
    const [expiredLicenses] = await db
      .select({ count: sql`count(*)` })
      .from(licenses)
      .where(lte(licenses.expiryDate, now));
    
    const [totalCustomers] = await db
      .select({ count: sql`count(*)` })
      .from(customers)
      .where(eq(customers.isActive, true));
    
    const [revenueResult] = await db
      .select({ total: sql`COALESCE(SUM(amount), 0)` })
      .from(licensePayments)
      .where(eq(licensePayments.paymentStatus, 'completed'));
    
    return {
      totalLicenses: Number(totalLicenses.count) || 0,
      activeLicenses: Number(activeLicenses.count) || 0,
      expiredLicenses: Number(expiredLicenses.count) || 0,
      totalCustomers: Number(totalCustomers.count) || 0,
      totalRevenue: Number(revenueResult.total) || 0
    };
  }
  
  // === إدارة الموظفين ===
  
  // إنشاء موظف جديد
  async createEmployee(employee: InsertEmployee): Promise<Employee> {
    const [newEmployee] = await db
      .insert(employees)
      .values(employee)
      .returning();
    
    if (!newEmployee) {
      throw new Error('فشل في إنشاء الموظف');
    }
    
    return newEmployee;
  }
  
  // الحصول على موظف بواسطة ID
  async getEmployee(id: number): Promise<Employee | undefined> {
    const [employee] = await db
      .select()
      .from(employees)
      .where(eq(employees.id, id));
    
    return employee;
  }
  
  // الحصول على موظف بواسطة اسم المستخدم
  async getEmployeeByUsername(username: string): Promise<Employee | undefined> {
    const [employee] = await db
      .select()
      .from(employees)
      .where(eq(employees.username, username));
    
    return employee;
  }
  
  // الحصول على جميع الموظفين
  async getAllEmployees(): Promise<Employee[]> {
    return await db
      .select()
      .from(employees)
      .orderBy(asc(employees.createdAt));
  }
  
  // تحديث موظف
  async updateEmployee(id: number, updates: Partial<Employee>): Promise<Employee | undefined> {
    const [updatedEmployee] = await db
      .update(employees)
      .set(updates)
      .where(eq(employees.id, id))
      .returning();
    
    return updatedEmployee;
  }
  
  // حذف موظف
  async deleteEmployee(id: number): Promise<boolean> {
    const result = await db
      .delete(employees)
      .where(eq(employees.id, id));
    
    return result.rowCount !== null && result.rowCount > 0;
  }
  
  // تحديث آخر تسجيل دخول للموظف
  async updateEmployeeLastLogin(id: number): Promise<void> {
    await db
      .update(employees)
      .set({ lastLoginAt: new Date() })
      .where(eq(employees.id, id));
  }
}

export const licenseStorage = new DatabaseLicenseStorage();