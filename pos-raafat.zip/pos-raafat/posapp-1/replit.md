# Point of Sale System

## Overview

This is a modern Point of Sale (POS) system built for Arabic-speaking retail businesses. The application provides a complete retail management solution with product management, sales processing, inventory tracking, and administrative features. The system is designed with a right-to-left (RTL) interface to support Arabic language requirements and includes features like barcode scanning, thermal receipt printing, and comprehensive sales analytics.

## Recent Changes

**September 22, 2025**: Significantly improved administrative interface organization by consolidating multiple management functions within the "Operations Settings" (إعدادات العمليات) section. This major enhancement includes:

- **Unified Operations Dashboard**: All operational management functions are now centralized under a single tabbed interface
- **Advanced Orders Management**: Complete order management moved from admin panel to operations settings
- **Data Backup & Reports**: Backup functionality and annual reports consolidated within operations
- **Comprehensive Sync Management**: Network synchronization features (upload, download, comprehensive sync) integrated into operations
- **License Management Integration**: Commercial license management moved from separate tab to main admin panel
- **Streamlined Navigation**: Reduced interface complexity by eliminating redundant navigation paths
- **Enhanced User Experience**: Single-location access to all administrative and operational functions

This reorganization significantly improves workflow efficiency for store managers and administrators by providing logical grouping of related functions and reducing the need to navigate between multiple separate interfaces.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
The frontend is built using **React** with **TypeScript** and follows a component-based architecture. The application uses **Vite** as the build tool and development server for fast development and optimized production builds.

**UI Framework**: The system leverages **shadcn/ui** components built on top of **Radix UI** primitives, providing a consistent and accessible design system. **Tailwind CSS** is used for styling with custom CSS variables for theming support.

**State Management**: **TanStack Query (React Query)** handles server state management, caching, and synchronization. Local state is managed using React's built-in hooks.

**Routing**: **Wouter** is used as a lightweight client-side routing solution, providing navigation between different pages (POS, Products, Sales, Admin).

**Form Handling**: **React Hook Form** with **Zod** validation ensures type-safe form handling and validation across the application.

### Backend Architecture
The backend follows a **REST API** architecture built with **Express.js** and **TypeScript**. The server provides a clean separation between routing, business logic, and data access layers.

**API Design**: RESTful endpoints handle CRUD operations for products, receipts, settings, and licensing. The API includes specialized endpoints for search functionality, low stock alerts, and sales analytics.

**Storage Layer**: A repository pattern is implemented through the `IStorage` interface, allowing for flexible data access strategies. The `DatabaseStorage` class provides the concrete implementation using Drizzle ORM.

**Middleware**: Custom logging middleware tracks API requests and responses for debugging and monitoring purposes.

### Data Storage Solutions
**Database**: **PostgreSQL** serves as the primary database, providing ACID compliance and robust data integrity. The system uses **Neon Database** as the hosted PostgreSQL solution.

**ORM**: **Drizzle ORM** provides type-safe database operations with automatic TypeScript inference. The schema is defined in a shared location for consistency between frontend and backend.

**Migrations**: Database schema changes are managed through Drizzle migrations, ensuring consistent deployments and version control.

**Schema Design**: The database includes tables for products (with barcode support), receipts (with JSON item storage), settings (for store configuration), and licenses (for software activation).

### Authentication and Authorization
**Admin Access**: The system implements a simple password-based authentication for administrative functions. The admin password is configurable through environment variables or constants.

**Session Management**: Session state is managed client-side for the admin interface, with automatic logout and re-authentication flows.

### External Dependencies

**Database Services**:
- **Neon Database**: Serverless PostgreSQL hosting with automatic scaling
- **@neondatabase/serverless**: WebSocket-based database client for serverless environments

**UI Component Libraries**:
- **Radix UI**: Comprehensive collection of unstyled, accessible UI primitives
- **shadcn/ui**: Pre-built component library built on Radix UI with consistent styling
- **Lucide React**: Icon library providing consistent iconography

**Development Tools**:
- **Vite**: Fast build tool and development server with hot module replacement
- **TypeScript**: Static type checking for enhanced developer experience and code reliability
- **Tailwind CSS**: Utility-first CSS framework for rapid UI development
- **ESBuild**: Fast JavaScript bundler for production builds

**Runtime Libraries**:
- **TanStack Query**: Server state management with caching and synchronization
- **React Hook Form**: Performant form library with minimal re-renders
- **Zod**: TypeScript-first schema validation library
- **date-fns**: Comprehensive date utility library
- **Wouter**: Lightweight client-side routing

**Arabic Language Support**:
- **Cairo Font**: Arabic web font for proper text rendering
- **RTL Layout**: Right-to-left layout support throughout the application
- **Arabic Localization**: UI text and formatting optimized for Arabic-speaking users

## Returns and Refunds System

The system includes a comprehensive returns/refunds management system within the operations settings, allowing staff to process item returns and provide customer refunds with full audit trails.

**Key Features**:
- **Archives Management**: Access to all completed sales transactions with detailed views
- **Selective Returns**: Ability to return specific items and quantities from any completed transaction
- **Validation System**: Prevents over-returns by tracking returned quantities per transaction
- **Automatic Inventory Updates**: Returned items are automatically added back to inventory
- **Stock Movement Tracking**: All returns generate incoming stock movement records
- **Return Receipt Printing**: Specialized thermal receipts for return transactions
- **Cash Drawer Integration**: Automatic cash drawer opening for refund processing
- **Audit Trail**: Complete history of all return transactions with reasons and timestamps

**Workflow**:
1. Navigate to Operations Settings → Archives
2. Select completed transaction and click "Return"
3. Choose specific items and quantities to return (with real-time validation)
4. Add optional return reason
5. System calculates refund amount and updates inventory
6. Cash drawer opens automatically for refund processing
7. Optional return receipt printing with transaction details

**Technical Implementation**:
- Returns stored in localStorage with key 'supermarket_returns'
- Cross-validation against original transactions to prevent duplicate returns
- Real-time calculation of available return quantities
- Integration with inventory management and stock movement tracking
- Dedicated return receipt template with Arabic RTL support

## Thermal Receipt Printing

The system includes specialized thermal receipt printing functionality optimized for 80mm thermal printers commonly used in retail environments.

**Key Features**:
- **80mm Width**: Optimized layout for standard thermal receipt printers
- **Monospace Font**: Uses Courier New for proper character alignment
- **Arabic RTL Support**: Right-to-left layout maintained in printed receipts
- **Professional Format**: Includes store info, transaction details, and customer-friendly footer
- **Auto-Print**: Automatically triggers print dialog when receipt is generated
- **Manual Print**: Dedicated print button in cashier interface for reprinting
- **Return Receipts**: Specialized receipts for return transactions with refund details

**Technical Implementation**:
- HTML/CSS-based receipt generation with `@media print` styles
- 40-character line width formatting for consistent thermal printer output
- Helper functions for text alignment (center, left-right spacing, separator lines)
- Automatic window management for print preview and execution
- Compatible with all thermal printers set up as system printers
- Separate templates for sales and return receipts

## Data Backup and Annual Reporting

The system includes comprehensive data management features for business continuity and financial reporting.

**Data Backup System**:
- **Complete Data Export**: Exports all program data including products, orders, settings, stock movements, and returns
- **JSON Format**: Data exported in structured JSON format for easy import/migration
- **Automatic File Naming**: Backup files named with current date for organization
- **One-Click Export**: Simple button in admin panel for instant backup creation
- **Complete Data Coverage**: Includes all localStorage data with metadata

**Annual Sales Reporting**:
- **Yearly Revenue Calculation**: Automatically calculates total sales for current year
- **Completed Orders Only**: Only includes finalized transactions in calculations
- **Real-time Updates**: Sales totals update automatically as new orders are completed
- **Arabic Formatting**: Revenue displayed in Lebanese Pound format with Arabic numerals
- **Date Accuracy**: Uses ISO timestamps (createdAt) for precise date filtering

**Technical Implementation**:
- `exportAllData()` function creates comprehensive JSON backup with metadata
- `calculateAnnualSales()` function with enhanced date handling for Arabic locales
- Enhanced order creation with both display date (Arabic) and ISO timestamp (createdAt)
- Robust error handling for date parsing with fallback logic
- Admin panel integration with dedicated sections for backup and reporting

## Network Synchronization System

The system includes a comprehensive multi-device synchronization capability that allows multiple POS terminals to share data over a local area network (LAN) within the same store environment.

**Key Features**:
- **Multi-Device Support**: Sync products, orders, settings, stock movements, and returns between multiple devices
- **Real-time Synchronization**: Automatic and manual sync options with configurable intervals
- **Conflict Resolution**: Intelligent conflict detection and resolution for data discrepancies
- **Secure Authentication**: Token-based authentication system for secure data transfer
- **Network Discovery**: Automatic detection and listing of connected devices
- **Status Monitoring**: Real-time sync status, connection health, and last sync timestamps
- **Selective Sync**: Options for upload-only, download-only, or bidirectional synchronization

**Security Implementation**:
- **Token-Based Authentication**: Each device requires a shared secret token for sync operations
- **Sensitive Data Protection**: Excludes admin passwords and license keys from sync payload
- **Environment Variables**: Server sync secret stored securely in environment variables
- **Input Validation**: All sync endpoints protected with authentication middleware
- **Data Sanitization**: Automatic removal of sensitive fields before network transmission

**Technical Architecture**:
- **Client-Side**: React-based sync settings interface with real-time status monitoring
- **Server-Side**: Express.js REST API endpoints for data synchronization
- **Authentication**: X-Sync-Token header validation on all protected endpoints
- **Data Format**: JSON-based payload with timestamp and device identification
- **Conflict Detection**: Field-level comparison with user-selectable resolution strategy
- **Auto-Sync**: Configurable timer-based synchronization with idle state checking

**API Endpoints**:
- `/api/health`: Public health check endpoint for connectivity testing
- `/api/sync/upload`: Secure endpoint for uploading local data to central server
- `/api/sync/download`: Secure endpoint for downloading latest data from server  
- `/api/sync/devices`: Secure endpoint for retrieving list of connected devices
- `/api/sync/status`: Secure endpoint for sync statistics and server status

**Setup Process**:
1. **Primary Device Setup**: Configure one device as the central sync server
2. **Token Configuration**: Generate and distribute shared sync token to all devices
3. **Network Configuration**: Set server URL on secondary devices pointing to primary device IP
4. **Sync Settings**: Configure auto-sync intervals and enable synchronization
5. **Testing**: Use built-in connectivity test to verify network communication
6. **Operation**: Automatic sync maintains data consistency across all devices

**Workflow Integration**:
- Admin panel includes dedicated sync management section
- Real-time sync status indicators and device connection monitoring
- Manual sync controls for immediate data synchronization
- Conflict resolution interface for handling data discrepancies
- Comprehensive sync logs and error reporting