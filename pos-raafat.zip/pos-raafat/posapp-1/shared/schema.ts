import { pgTable, serial, varchar, timestamp, text, boolean, integer, decimal, uuid } from 'drizzle-orm/pg-core';
import { relations, sql } from 'drizzle-orm';

// جدول العملاء
export const customers = pgTable('customers', {
  id: serial('id').primaryKey(),
  companyName: varchar('company_name', { length: 255 }).notNull(),
  contactPerson: varchar('contact_person', { length: 255 }).notNull(),
  email: varchar('email', { length: 255 }),
  phone: varchar('phone', { length: 50 }),
  address: text('address'),
  country: varchar('country', { length: 100 }),
  city: varchar('city', { length: 100 }),
  registrationDate: timestamp('registration_date').defaultNow(),
  isActive: boolean('is_active').default(true),
  notes: text('notes'),
});

// جدول أنواع التراخيص
export const licenseTypes = pgTable('license_types', {
  id: serial('id').primaryKey(),
  name: varchar('name', { length: 100 }).notNull(),
  description: text('description'),
  features: text('features'), // JSON string للمميزات
  maxDevices: integer('max_devices').default(1),
  validityDays: integer('validity_days').default(365),
  price: decimal('price', { precision: 10, scale: 2 }),
  currency: varchar('currency', { length: 3 }).default('LBP'),
  isActive: boolean('is_active').default(true),
  createdAt: timestamp('created_at').defaultNow(),
});

// جدول التراخيص
export const licenses = pgTable('licenses', {
  id: serial('id').primaryKey(),
  licenseKey: varchar('license_key', { length: 255 }).notNull().unique(),
  customerId: integer('customer_id').references(() => customers.id),
  licenseTypeId: integer('license_type_id').references(() => licenseTypes.id),
  issueDate: timestamp('issue_date').defaultNow(),
  expiryDate: timestamp('expiry_date').notNull(),
  isActive: boolean('is_active').default(true),
  isRevoked: boolean('is_revoked').default(false),
  maxActivations: integer('max_activations').default(1),
  currentActivations: integer('current_activations').default(0),
  lastActivationDate: timestamp('last_activation_date'),
  revokedDate: timestamp('revoked_date'),
  revokedReason: text('revoked_reason'),
  metadata: text('metadata'), // JSON string للبيانات الإضافية
  createdBy: varchar('created_by', { length: 255 }),
  notes: text('notes'),
});

// جدول تفعيلات التراخيص
export const licenseActivations = pgTable('license_activations', {
  id: serial('id').primaryKey(),
  licenseId: integer('license_id').references(() => licenses.id),
  deviceId: varchar('device_id', { length: 255 }).notNull(),
  deviceName: varchar('device_name', { length: 255 }),
  deviceFingerprint: text('device_fingerprint'),
  ipAddress: varchar('ip_address', { length: 45 }),
  activationDate: timestamp('activation_date').defaultNow(),
  lastHeartbeat: timestamp('last_heartbeat'),
  isActive: boolean('is_active').default(true),
  deactivationDate: timestamp('deactivation_date'),
  userAgent: text('user_agent'),
  osInfo: text('os_info'),
  hardwareInfo: text('hardware_info'),
});

// جدول استخدام التراخيص
export const licenseUsage = pgTable('license_usage', {
  id: serial('id').primaryKey(),
  licenseId: integer('license_id').references(() => licenses.id),
  activationId: integer('activation_id').references(() => licenseActivations.id),
  usageDate: timestamp('usage_date').defaultNow(),
  actionType: varchar('action_type', { length: 50 }), // login, feature_use, transaction, etc.
  featureUsed: varchar('feature_used', { length: 100 }),
  usageCount: integer('usage_count').default(1),
  sessionDuration: integer('session_duration'), // مدة الجلسة بالدقائق
  additionalData: text('additional_data'), // JSON string
});

// جدول دفعات التراخيص
export const licensePayments = pgTable('license_payments', {
  id: serial('id').primaryKey(),
  customerId: integer('customer_id').references(() => customers.id),
  licenseId: integer('license_id').references(() => licenses.id),
  amount: decimal('amount', { precision: 10, scale: 2 }).notNull(),
  currency: varchar('currency', { length: 3 }).default('LBP'),
  paymentMethod: varchar('payment_method', { length: 50 }), // cash, bank_transfer, credit_card
  paymentStatus: varchar('payment_status', { length: 20 }).default('pending'), // pending, completed, failed, refunded
  paymentDate: timestamp('payment_date'),
  transactionId: varchar('transaction_id', { length: 255 }),
  receiptNumber: varchar('receipt_number', { length: 100 }),
  notes: text('notes'),
  createdAt: timestamp('created_at').defaultNow(),
});

// جدول سجل العمليات
export const licenseAuditLog = pgTable('license_audit_log', {
  id: serial('id').primaryKey(),
  licenseId: integer('license_id').references(() => licenses.id),
  action: varchar('action', { length: 100 }).notNull(), // created, activated, deactivated, revoked, renewed
  performedBy: varchar('performed_by', { length: 255 }),
  timestamp: timestamp('timestamp').defaultNow(),
  ipAddress: varchar('ip_address', { length: 45 }),
  userAgent: text('user_agent'),
  oldValues: text('old_values'), // JSON string للقيم القديمة
  newValues: text('new_values'), // JSON string للقيم الجديدة
  notes: text('notes'),
});

// جدول الموظفين
export const employees = pgTable('employees', {
  id: serial('id').primaryKey(),
  name: varchar('name', { length: 255 }).notNull(), // اسم الموظف كما يظهر
  username: varchar('username', { length: 100 }).notNull().unique(), // اسم المستخدم للدخول
  passwordHash: varchar('password_hash', { length: 255 }).notNull(), // كلمة المرور مشفرة
  isActive: boolean('is_active').default(true), // هل الموظف نشط
  createdAt: timestamp('created_at').defaultNow(), // تاريخ الإضافة
  createdBy: varchar('created_by', { length: 255 }), // من أضاف الموظف
  lastLoginAt: timestamp('last_login_at'), // آخر تسجيل دخول
  notes: text('notes'), // ملاحظات إضافية
});

// العلاقات بين الجداول
export const customersRelations = relations(customers, ({ many }) => ({
  licenses: many(licenses),
  payments: many(licensePayments),
}));

export const licenseTypesRelations = relations(licenseTypes, ({ many }) => ({
  licenses: many(licenses),
}));

export const licensesRelations = relations(licenses, ({ one, many }) => ({
  customer: one(customers, {
    fields: [licenses.customerId],
    references: [customers.id],
  }),
  licenseType: one(licenseTypes, {
    fields: [licenses.licenseTypeId],
    references: [licenseTypes.id],
  }),
  activations: many(licenseActivations),
  usageRecords: many(licenseUsage),
  payments: many(licensePayments),
  auditLogs: many(licenseAuditLog),
}));

export const licenseActivationsRelations = relations(licenseActivations, ({ one, many }) => ({
  license: one(licenses, {
    fields: [licenseActivations.licenseId],
    references: [licenses.id],
  }),
  usageRecords: many(licenseUsage),
}));

export const licenseUsageRelations = relations(licenseUsage, ({ one }) => ({
  license: one(licenses, {
    fields: [licenseUsage.licenseId],
    references: [licenses.id],
  }),
  activation: one(licenseActivations, {
    fields: [licenseUsage.activationId],
    references: [licenseActivations.id],
  }),
}));

export const licensePaymentsRelations = relations(licensePayments, ({ one }) => ({
  customer: one(customers, {
    fields: [licensePayments.customerId],
    references: [customers.id],
  }),
  license: one(licenses, {
    fields: [licensePayments.licenseId],
    references: [licenses.id],
  }),
}));

export const licenseAuditLogRelations = relations(licenseAuditLog, ({ one }) => ({
  license: one(licenses, {
    fields: [licenseAuditLog.licenseId],
    references: [licenses.id],
  }),
}));

// أنواع TypeScript
export type Customer = typeof customers.$inferSelect;
export type InsertCustomer = typeof customers.$inferInsert;

export type LicenseType = typeof licenseTypes.$inferSelect;
export type InsertLicenseType = typeof licenseTypes.$inferInsert;

export type License = typeof licenses.$inferSelect;
export type InsertLicense = typeof licenses.$inferInsert;

export type LicenseActivation = typeof licenseActivations.$inferSelect;
export type InsertLicenseActivation = typeof licenseActivations.$inferInsert;

export type LicenseUsage = typeof licenseUsage.$inferSelect;
export type InsertLicenseUsage = typeof licenseUsage.$inferInsert;

export type LicensePayment = typeof licensePayments.$inferSelect;
export type InsertLicensePayment = typeof licensePayments.$inferInsert;

export type LicenseAuditLog = typeof licenseAuditLog.$inferSelect;
export type InsertLicenseAuditLog = typeof licenseAuditLog.$inferInsert;

export type Employee = typeof employees.$inferSelect;
export type InsertEmployee = typeof employees.$inferInsert;